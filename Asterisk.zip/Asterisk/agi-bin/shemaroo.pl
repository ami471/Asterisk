#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {

	my ($number_dialed) = @ARGV;
	my $AGI = new Asterisk::AGI;
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);

	my $default_values = {
		'timeout' => '4000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
                
	};
        my $mem_obj = {
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
		'number_dialed' => $number_dialed,
		'count' => '0',
		'dial_group' => "$value_hash{shadi}->{dial_group}",
		'dial_channel' => "$value_hash{shadi}->{dial_channel}",
		'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
		'callerid_out_1' => "$value_hash{shadi}->{escalate_number}",
                'callerid_out_2' => "$value_hash{shadi}->{escalate_number_2}",
                'callerid_out_3' => "$value_hash{shadi}->{escalate_number_3}",
		'dial_group_sec' => "$value_hash{shadi}->{dial_group_sec}"
	};
	
	my $tablename = 'housie_call';
        my $value = 1;
        my $number = $mem_obj->{'number_dialed'};
	#===================Changes for 10 digit number====
	my $mobileno_length = length($mem_obj->{'number_dialed'});
        if ($mobileno_length > 10)
        {
                my $n = 2;
                $mem_obj->{'number_dialed'} = substr( "$mem_obj->{'number_dialed'}",$n);

        }
	#========================================================
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "update $tablename set status ='ANSWERED' where callerid = '$number' order by callerid_count desc limit 1";
        my $sth = $dbh->prepare($query);
        $sth->execute();
        if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();

	my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $timeout = $mem_obj->{'dial_timeout'};		
	my $function = "__language_selection";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;
}

sub __language_selection{

	my ($config,$default_values,$mem_obj) = @_;
	my $lang = "ivr/ThinkWalnut/Shemaroo";
        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
	return ("__welcome");

}


#===============
sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
	#======Check mobile no has redemmed coupon 7th Nov==========================
	my $tablename = 'comfort_uniqueid';
   	my $coupon_used;
	my $sr_no;
	my $contactno = $mem_obj->{'number_dialed'};
    	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
    	my $query = "select coupon_used,sr_no from $tablename where mobile_no =$contactno";
    	my $sth = $dbh->prepare($query) ;
   	my $ret =$sth->execute();
   	while(my @row = $sth->fetchrow_array())
    	{
       
        	$coupon_used    = $row[0];
		$sr_no          = $row[1];
	}
     	$sth->finish();
    	$dbh->disconnect();
	$mem_obj->{'transaction_id'} = $sr_no;

        if($coupon_used == 1)
	{

		$mem_obj->{'type'} = 3;
	#============SEND RESPONSE====================

         my $url ="http://172.20.120.105/13/sampan/sms_push.php?m=$contactno&tx=$sr_no&t=$mem_obj->{'type'}";
         my $request = new HTTP::Request(POST => $url);
         $request->content_type('application/x-www-form-urlencoded');
         my $ua = LWP::UserAgent->new();
         my $response = $ua->request($request);
      	#==============END============================
	$config->{_cti_obj}->exec("Playback","mobile_used");
	$config->{_cti_obj}->exec("Playback","Thanks_formobile");
	return "exit";

	}
	#========================================================================
	$config->{_cti_obj}->exec("Playback","Welcome");
	my $bg_sound_file = "code_validation";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {

                '1' => '1',

                '2' => '2'
        };
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	if($dtmf ==1)
        {
		return("__enter_unique_code");
	}
	else
	{
		$config->{_cti_obj}->exec("Playback","call_later");
		return "exit";
	}
}
sub __enter_unique_code
{
   my ($config,$default_values,$mem_obj) = @_;
   my $count;
   my $positive_flag =0;
   $mem_obj->{'count'}++;
   my $bg_sound_file = "unique_code";
   my $max_allowed_digit = "6";
   #=========================================================
 
    $default_values->{'timeout_max'} =  "maximum_attempt";
   my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});

    my $tablename = 'comfort_uniqueid';
    my $uniqueid;
    my $coupon_used;
    my $sr_no;
    my $contactno = $mem_obj->{'number_dialed'};
    my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
    my $query = "select unique_id,coupon_used,sr_no from $tablename where unique_id =$dtmf";
    my $sth = $dbh->prepare($query) ;
    my $ret =$sth->execute();
    while(my @row = $sth->fetchrow_array())
    {
        $uniqueid 	= $row[0];
	$coupon_used	= $row[1];
        $sr_no          = $row[2];

    }
    $sth->finish();
    $dbh->disconnect();
    $mem_obj->{'transaction_id'} = $sr_no;
     #====Insert user input dtmf in table 7th November=============================
     $tablename = 'housie_call';
     my $value = 1;
     my $number = $mem_obj->{'number_dialed'};
     $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
     $query = "update $tablename set  entered_code = $dtmf where callerid = '$number' order by callerid_count desc limit 1";
     $sth = $dbh->prepare($query);
    $sth->execute();
    if ($sth->rows())
    {

                $value =  0;

     }
    $sth->finish();
    $dbh->disconnect();
    #====================7th November =============================================
    if($dtmf > 0)
    {
    	$config->{_cti_obj}->exec("Playback","code_entered");
    	$config->{_cti_obj}->exec("SayDigits","$dtmf");
    }
    if($coupon_used == 1)
    {
	$config->{_cti_obj}->exec("Playback","code_used");
	return "exit";

    }
        
    if($dtmf == $uniqueid)
    {

#=======================================================
	$bg_sound_file = "code_valid";
    	$max_allowed_digit = "1";
    	my $hash_table_ref =
    	{

        	'1' => '1',
        	'2' => '2'

    	};
    	my $confirm = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},0,undef,undef,$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);


#====================================================================
	if($confirm == 1)
	{
		 #==========updating comfort uniqueid table=====================
        	 $tablename = 'comfort_uniqueid';
        	 $value = 1;
       	         $number = $mem_obj->{'number_dialed'};
        	 $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        	 $query = "update $tablename set coupon_used = 1,mobile_no = $number where unique_id =$dtmf";
        	 $sth = $dbh->prepare($query);
        	$sth->execute();
        	if ($sth->rows()) {

                $value =  0;

        	}
        	$sth->finish();
        	$dbh->disconnect();
                #=======================================================
		my $bg_sound_file = "mobile_wallet";

		my $max_allowed_digit = "1";

		my $hash_table_ref = {

		'1' => 'Paytm',
		'2' => 'Mobikwik',
		'3' => 'Freecharge',
		'4' => 'MobileRecharge'
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	#================DB OPERATION================================
	my $tablename = 'housie_call';
        my $value = 1;
        my $number = $mem_obj->{'number_dialed'};
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "update housie_call set mobile_wallet = $dtmf where callerid = '$number' order by callerid_count desc limit 1";
        my $sth = $dbh->prepare($query);
        $sth->execute();
        if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();
        #===========================================================
	if($dtmf == 1)
	{
		return("__walletrecharge");
	}
	if($dtmf == 2)
	{
		return("__walletrecharge");
	}
	if($dtmf == 3)
        {
                return("__walletrecharge");
        }
        if($dtmf == 4)
        {
                return("__mobilerecharge");
        }
	}
	else
    	{
        	$count =$mem_obj->{'count'}++;
		if($dtmf > 0)
		{
        		if($count == 1)
        		{

            			return ("__enter_unique_code");
        		}
        		if($count > 1)
        		{
                		$config->{_cti_obj}->exec("Playback","maximum_attempt");
        		}
		}


    	}

	
     }
    else
    {   
	my $dtmf_length = length($dtmf);
        if($dtmf == abs($dtmf))
	{
  		$positive_flag = 1;
	}
	else
	{
		$positive_flag = 0;
	}
        if($positive_flag)
	{
		$config->{_cti_obj}->exec("Playback","invalid_code");
	
     		if($mem_obj->{'count'} == 1)
		{
			return ("__enter_unique_code");
		}
	
        	if( $mem_obj->{'count'} > 1)
                	{
                        	$config->{_cti_obj}->exec("Playback","maximum_attempt");
                	}
	}
   }
    
      #============SEND RESPONSE====================
#        my $AGI = new Asterisk::AGI;
#        my $duration = $AGI->get_variable('CDR(duration)');
#        my $url ="http://172.20.120.105/13/comfort/repurchase/api/get_response.php?u=$mem_obj->{'interaction_id'}&m=$mem_obj->{'number_dialed'}&duration=$duration&response=$dtmf";
#       my $request = new HTTP::Request(POST => $url);
#        $request->content_type('application/x-www-form-urlencoded');
#        my $ua = LWP::UserAgent->new();
#        my $response = $ua->request($request);
      #==============END============================
           
}

sub __mobilerecharge
{
	my ($config,$default_values,$mem_obj) = @_;
	$mem_obj->{'type'} = 2;
	
	#============SEND RESPONSE====================

my $url ="http://172.20.120.105/13/sampan/sms_push.php?m=$mem_obj->{'number_dialed'}&tx=$mem_obj->{'transaction_id'}&t=$mem_obj->{'type'}";
         my $request = new HTTP::Request(POST => $url);
         $request->content_type('application/x-www-form-urlencoded');
         my $ua = LWP::UserAgent->new();
         my $response = $ua->request($request);
        #==============END============================

	$config->{_cti_obj}->exec("Playback","Thanks_code_share_mobile");
	return "exit";
         
	
}


sub __walletrecharge
{
	my ($config,$default_values,$mem_obj) = @_;
	$mem_obj->{'type'} = 1;
	#============SEND RESPONSE====================

         my $url ="http://172.20.120.105/13/sampan/sms_push.php?m=$mem_obj->{'number_dialed'}&tx=$mem_obj->{'transaction_id'}&t=$mem_obj->{'type'}";
         my $request = new HTTP::Request(POST => $url);
         $request->content_type('application/x-www-form-urlencoded');
         my $ua = LWP::UserAgent->new();
         my $response = $ua->request($request);
        #==============END============================
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/Shemaroo/Thanks_code_share_wallet");
	return "exit";
	
}

#===================SMS Sending======================================
sub __post_number {

 my ($config,$mem_obj) = @_;
        my $callerid 	   = $mem_obj->{'callerid'};
        my $uniqueid       = $mem_obj->{'session_id'};
	my $transaction_id = $mem_obj->{'transaction_id'};
	my $type           = $mem_obj->{'type'};
        my $called_no;
        if($mem_obj->{'did'} == 8607)
        {
                 $called_no = 9222216216;
        }
        my $url ="http://172.20.120.105/13/sampan/sms_push.php?m=$callerid&tx=$transaction_id&t=$type";
       # my $url ="http://172.20.120.105/13/api/twd_get_misscall.php?c=$called_no&m=$callerid";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        my $current_time = sprintf("%02d%02d%02d",$hour,$min,$sec);
        if ($response->is_success)
        {
                my $filename = '/var/log/asterisk/report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url and time is $current_time \n";
                close $fh;
          


                       #         return 1;

        }  else {

                my $status_lin = $response->status_code;
                my $filename = '/var/log/asterisk/report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is unsucessful for $url and time is $current_time\n";
                close $fh;

               #  return -1;
        }
        if($type == 1)
	{
		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/Shemaroo/Thanks_code_share_wallet");

	}
	if($type == 2)
        {
                $config->{_cti_obj}->exec("Playback","Thanks_code_share_mobile");

        }
        if($type == 3)
        {
                $config->{_cti_obj}->exec("Playback","call_later");

        }


   return "exit";


}
#====================================================================


sub __failure_case {
       my ($config,$default_values,$mem_obj) = @_;
       return "exit";
}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
