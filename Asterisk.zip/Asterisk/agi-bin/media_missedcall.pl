#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;
use Time::Local;
#use XML::Simple 'XMLin';
# this __dial_out function is dialing out call_center number and hanging up at the last
sub __dial_out {
	
	my ($config,$mem_obj) = @_;
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $dial_group = $mem_obj->{'dial_group'}; 
	my $timeout = $mem_obj->{'dial_timeout'};
	my $dial_out = $mem_obj->{'call_center_no'};
        my $callerid = $mem_obj->{'callerid'};
        my $did	     = "0226121".$mem_obj->{'did'};
	my $weekday;
	my $day_is;
        my $media_vehicle;
	my $media_channel;
	my $series;
	my $circle;
	my $campaign;
        my $flag = 0;
        my $number;
	#=========Changes to 10 digit number
        my $mobileno_length = length($mem_obj->{'callerid'});
        if ($mobileno_length > 10)
        {
                my $n = 2;
                $mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);
		$callerid = $mem_obj->{'callerid'};
	}
	#========To Select Telecom Circle==========================
        $series = substr($callerid, 0, 4);
       # if($series == 1400)
#	{
#		return "exit";
#	}
       my $tablename = 'telecom_circle';
       my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
      my $query = "select circle from $tablename where series =$series";
      my $sth = $dbh->prepare($query) ;
      my $ret =$sth->execute();
      while(my @row = $sth->fetchrow_array())
        {

                $circle   = $row[0];
               
        }
        $sth->finish();
        $dbh->disconnect();
        $mem_obj->{'circle'} = $circle;
        if ($circle eq '') 
        {
		$circle = 'OTHERS';
		$mem_obj->{'circle'} = $circle;

	}
        $campaign = 'IIFL GOLDLOAN';
       #========Media Selection based on DID============
        if($mem_obj->{'did'} == 8653)
        {
		$did = '8108102888';
                $media_vehicle = 'TV_Missed';
		$flag = 1;
	}
	if($mem_obj->{'did'} == 8651)
        {
                $media_vehicle = 'SANDESH';
        }
	if($mem_obj->{'did'} == 8652)
        {
		#$mem_obj->{'did'} = '8108103888';
		$did = '8108103888';
		$media_vehicle = 'RADIO';
		$flag = 1;
        }
#	if($mem_obj->{'did'} == 8616)
 #       {
 #               $did = '8108106555';
 #               $media_vehicle = 'TELIVISION';
  #      #        $flag = 1;
 #       }

	if($mem_obj->{'did'} == 8617)
        {
		$did = '8108102555';
                $media_vehicle = 'PRINT';
	#	$flag = 1;
        }
	
	   if($mem_obj->{'did'} == 8618)
        {
                $did = '8108105222';
                $media_vehicle = 'OUTDOOR';
         #       $flag = 1;
        }

	if($mem_obj->{'did'} == 8654)
        {
                $media_vehicle = 'VIJAY KARNATKA';
        }
	if($mem_obj->{'did'} == 8655)
        {
                $media_vehicle = 'NCD CAMPAIGN';
		$campaign      = 'NCD CAMPAIGN';
        }
	if($mem_obj->{'did'} == 8656)
        {
                $media_vehicle = 'VIJAYWANI';
        }
	if($mem_obj->{'did'} == 8657)
        {
                $media_vehicle = 'EENADU';
        }
	if($mem_obj->{'did'} == 8658)
        {
                $media_vehicle = 'DAILY THANTI';
        }
	if($mem_obj->{'did'} == 8659)
        {
                $media_vehicle = 'DINAKARAN';
        }
 	if($mem_obj->{'did'} == 8660)
        {
                $media_vehicle = 'DIVYA MARATHI';
        }
        if($mem_obj->{'did'} == 8661)
        {
                $media_vehicle = 'LOKMAT';
        }
	if($mem_obj->{'did'} == 8662)
        {
                $media_vehicle = 'DAINIK BHASKAR';
        }
	if($mem_obj->{'did'} == 8663)
        {
                $media_vehicle = 'RAJSTHAN PATRIKA(W)';
        }
	if($mem_obj->{'did'} == 8644)
        {
                $media_vehicle = 'OUTDOOR NORTH';
                $flag = 1;
        }
	if($mem_obj->{'did'} == 8666)
        {
                $media_vehicle = 'OUTDOOR CENTRAL';
        }
	if($mem_obj->{'did'} == 8677)
        {
                $media_vehicle = 'OUTDOOR SOUTH 2';
        }
	if($mem_obj->{'did'} == 8688)
        {
                $media_vehicle = 'OUTDOOR WEST 1';
        }
	if($mem_obj->{'did'} == 8699)
        {
                $media_vehicle = 'OUTDOOR WEST 2';
        }
        if($mem_obj->{'did'} == 8644 || $mem_obj->{'did'} == 8666 || $mem_obj->{'did'} == 8677 || $mem_obj->{'did'} == 8688 || $mem_obj->{'did'} == 8699)
	{
		$media_channel = 'OUTDOOR';
	} 
	else
	{
		$media_channel = 'PRINT';
	}
	#==========Date Time Display============
        my ($sec,$min,$hour,$date,$mon,$year,$wday,$yday,$isdst) = localtime();
        if($wday == 0)
        {
                $weekday = 'SUNDAY';
        }
        elsif($wday == 1)
        {
                $weekday = 'MONDAY';
        }
        elsif($wday == 2)
        {
                $weekday = 'TUESDAY';
        }
        elsif($wday == 3)
        {
                $weekday = 'WEDNESDAY';
        }
        elsif($wday == 4)
        {
                $weekday = 'THURSDAY';
        }
          elsif($wday == 5)
        {
                $weekday = 'FRIDAY';
        }
        else
        {
                $weekday = 'SATURDAY';
        }
        if($wday == 0 || $wday == 6)
        {
                $day_is = "WEEKEND";
        }
        else
        {
                $day_is = "WEEKDAY"
        }
        $year +=1900;
        $mon  +=1;
	my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
        my $current_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
        my $time_display = sprintf("%02d%02d%02d",$hour,$min,$sec);

        if ($time_display >= '210000' && $time_display < '240000')
        {
                $time_now = "NIGHT";
        }
        if ($time_display >= '050000' && $time_display < '120000')
        {
                $time_now = "MORNING";
        }
        if ($time_display >= '120000' && $time_display < '160000')
        {
                $time_now = "AFTERNOON";
        }
        if ($time_display >= '160000' && $time_display < '210000')
        {
                $time_now = "EVENING";
        }
        
        #=======================================
        if($flag == 1)
	{
#		 $number = $mem_obj->{'callerid'};

#		my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
#		my $my_message = "Thank you for your interest. IIFL Loan expert will contact you shortly to understand your requirement. To learn about our loan products, visit iifl.com";
#		my $req = GET "http://roundsms.com/api/sendhttp.php?authkey=ZTIzMTRjZmM3MzN&mobiles=$number&message=$my_message&sender=IIFLRA&type=1&route=2";
#		my $res = $ua->request($req);
#		if ($res->is_success) {
 #       		print $res->content;
  #      	}else{
   #             	print $res->status_line . "\n";
   #             }


	}

	my $tablename = 'mediamissed_calling';
        
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count =0;
        my $query = "INSERT INTO $tablename (mobno,status,did,media_channel,media_vehicle,day,weekday,date,time,Time_Session,campaign,circle) VALUES('$callerid','NOANSWER','$did','$media_channel','$media_vehicle','$weekday','$day_is','$current_date','$current_time','$time_now','$campaign','$circle')";
	my $sth = $dbh->prepare($query) ;
	my $ret =$sth->execute();
        $dbh->disconnect();
 
        
        my $dbh_2 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count_2 =0;
        my $query_2 = "DELETE FROM $tablename WHERE status ='ANSWERED'";
        my $sth_2 = $dbh_2->prepare($query_2) ;
        my $ret_2 =$sth_2->execute();
        $dbh_2->disconnect();
        
	if($flag == 1)
        {
                 $number = $mem_obj->{'callerid'};
                my $circle_region = $mem_obj->{'circle'} ;
                my $did      = "91226121".$mem_obj->{'did'};
		my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=rubic&ivr_nbr=$did&Mobile=$number &call_time=$current_date&circle=$circle";
                my $res = $ua->request($req);
                if ($res->is_success) {
                        print $res->content;
			my $filename = '/var/log/asterisk/report_vatika.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=rubic&ivr_nbr=$did&Mobile=$number &call_time=$current_date&circle=$circle \n";
                close $fh;
                }else{
                        print $res->status_line . "\n";
			my $filename = '/var/log/asterisk/report_vatika.txt';
                	open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                	print $fh "Response is not sucessful for https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=rubic&ivr_nbr=$did&Mobile=$number &call_time=$current_date&circle=$circle \n";
                close $fh;

                }


        }
     
       

	if ($status_var eq "CHANUNAVAIL" or $status_var eq "CONGESTION") {
		$dial_group = $mem_obj->{'dial_group_sec'};
		#my $callerid_out = $mem_obj->{'callerid_out_sec'};
		$config->{_cti_obj}->exec("Set","CALLERID(num)=$callerid_out");	
		#$dial_string = $dial_channel."/".$dial_group."/".$dial_out;
                my $dial_string = "SIP/".$dial_out;
		$status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout");
	}

      return "exit";
	
}

# main function
sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
	$AGI->exec("NoOP","dial_out======$dial_out_num");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI
	};	
	my %value_hash;
	my $file_name = "/uc/config/ini/missed_call.conf";
	read_ini_file($file_name,\%value_hash);
		
	my $mem_obj = {
		'callerid' => $output{'callerid'},
		'did' => $did,
		'session_id' => $output{'uniqueid'},
		#'dial_group' => $value_hash{mahindra_call}->{dial_group},
		#'dial_group_sec' => $value_hash{mahindra_call}->{dial_group_sec},
		#'dial_channel' => $value_hash{mahindra_call}->{dial_channel},
		'dial_timeout' => $value_hash{missed_call}->{dial_timeout},
		'call_center_no' =>$value_hash{missed_call}->{call_center_no},
		#'callerid_out' => $value_hash{mahindra_call}->{callerid_out},
		#'callerid_out_sec' => $value_hash{mahindra_call}->{callerid_out_sec}
		
	};	
	
	my $function = "__dial_out";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}



sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub post_number {

 my ($config,$mem_obj) = @_;
        my $callerid = $mem_obj->{'callerid'};
        my $uniqueid = $mem_obj->{'session_id'};
	my $called_no;
	if($mem_obj->{'did'} == 8607)
	{
		 $called_no = 9222216216;
	}
        if($mem_obj->{'did'} == 8626)
	{
		$called_no = 18002668412;
	}
	if($mem_obj->{'did'} == 8627)
	{
		$called_no = 18002668411;
	}
	if($mem_obj->{'did'} == 8631)
        {
                $called_no = 18001218607;
        }
	if($mem_obj->{'did'} == 8632)
        {
                $called_no = 18001215930;
        }

       # my $url ="http://172.20.120.105/13/wma/api/misscall_api.php?mdn=$callerid";
        my $url ="http://172.20.120.105/13/api/twd_get_misscall.php?c=$called_no&m=$callerid";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        my $current_time = sprintf("%02d%02d%02d",$hour,$min,$sec);
        if ($response->is_success)
        {
                my $filename = '/var/log/asterisk/report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url and time is $current_time \n";
                close $fh;





                                return 1;

        }  else {

                my $status_lin = $response->status_code;
		my $filename = '/var/log/asterisk/report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is unsucessful for $url and time is $current_time\n";
                close $fh;

                 return -1;
        }

   return "exit";
	
       
}

#=============CrayFish=================
sub post_crayfish_detail {

 my ($config,$mem_obj) = @_;
        my $callerid = $mem_obj->{'callerid'};
        my $uniqueid = $mem_obj->{'session_id'};
        my $called_no;
        my $time = time;
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	my $current_time = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year +1900, $mon+1, $mday, $hour, $min, $sec);
        my $url ="https://crayfish.twd.bz/utilities/missedCallDump.php?mdn=$callerid&timestamp=$current_time&src=2";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
         if ($response->is_success)
        {
                my $filename = '/var/log/asterisk/report_crayfish.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url and time is $current_time \n";
                close $fh;





                                return 1;

        }  else {
                my $status_lin = $response->status_code;
                my $filename = '/var/log/asterisk/report_crayfish.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is unsucessful for $url and time is $current_time\n";
                close $fh;

                 return -1;
        }

   return "exit";


}
#============Till here=================

main();
exit;
