#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($number_dialed) = @ARGV;
        my $broadcast_id;
        my $status;
        my $attempt;
        my $level;
        my $language;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&DIALED_NO=$number_dialed");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
	my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};
	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'number_dialed' => $number_dialed,
                'level_count'   => '4',
                'count' => '0'
	};
        #my $contactno = $mem_obj->{'number_dialed'};
         my $tablename = 'missed_calling';
         my $value = 1;
         my $dbh_3 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	 my $count_3 =0;
         my $query_3 = "DELETE FROM $tablename WHERE status ='ANSWERED'";
         my $sth_3 = $dbh_3->prepare($query_3) ;
         my $ret_3 =$sth_3->execute();
         $dbh_3->disconnect();
        
	 my $number = $mem_obj->{'number_dialed'};
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
         my $query = "update $tablename set status ='ANSWERED' where mobno = '$number'";
	 my $sth = $dbh->prepare($query);
	 $sth->execute();
         if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();
        
        my $dbh_2 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count_2 =0;
        my $query_2 = "select broadcast_id,status,attempt,level,language from $tablename where mobno = '$number' ";;
        my $sth_2 = $dbh_2->prepare($query_2) ;
        my $ret_2 =$sth_2->execute();
        while(my @row = $sth_2->fetchrow_array()){

        $broadcast_id = $row[0];
        $status       = $row[1];
        $attempt      = $row[2];
        $level        = $row[3];
        $language     = $row[4];

        }
      #  $AGI->exec("Set","CDR(userfield)=&Uniqueid=$broadcast_id&status= $status&attempt= $attempt");
        $sth_2->finish();
	$dbh_2->disconnect();
        $mem_obj->{'broadcast_id'} = $broadcast_id;
        $mem_obj->{'status'} = $status;
        $mem_obj->{'attempt'} = $attempt;
        $mem_obj->{'level'} = $level;
        $mem_obj->{'language'}= $language;
        $AGI->exec("Set","CDR(userfield)=&Uniqueid=$number_dialed");
	my $function = "__language_selection";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);

	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __language_selection{

	my ($config,$default_values,$mem_obj) = @_;
        my $word;
        my $bg_sound_file = "ivr/ThinkWalnut/paddle_pop/eng/language";
  #      my $tablename = 'missed_calling';
        my $start_level;
   #     my $value = 1;
  #      my $contactno = $mem_obj->{'number_dialed'};
   #     my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
   #     my $query = "select level from $tablename where mobno = '$contactno' ";
   #     my $sth = $dbh->prepare($query) ;
   #     my $ret =$sth->execute();
   #     while(my @row = $sth->fetchrow_array()){

    #    $start_level = $row[0];

     #   }
    #    $dbh->disconnect(); #14/04/16
         #=======================================
       my $url ="http://180.179.103.253/13/paddle_pop/api/get_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'broadcast_id'}&level= 1&status= $mem_obj->{'status'}&attempt= $mem_obj->{'attempt'}&language= $mem_obj->{'language'}";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);

       #=======================================

         $start_level = $mem_obj->{'level'};
        if($start_level > 0)
        {
            $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/paddle_pop/eng/welcome_back");
            

            my $lang_opt = $mem_obj->{'language'};
            if($lang_opt == 1)
            {
                $word = 'hin';
	    }
             if($lang_opt == 2)
            {
                $word = 'eng';
            }

             my $lang = "ivr/ThinkWalnut/paddle_pop/".$word;
             $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");


        }
        else
        {
		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/paddle_pop/eng/Welcome");
        
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => 'hin',
	        '2' => 'eng' 
	};
           
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
        $mem_obj->{'language'} = $dtmf;
        #=======================================
       my $url ="http://180.179.103.253/13/paddle_pop/api/get_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'broadcast_id'}&level= 1&key_pressed= $dtmf&status= $mem_obj->{'status'}&attempt= $mem_obj->{'attempt'}&language= $mem_obj->{'language'}";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);

       #=======================================

	if (exists $hash_table_ref->{$dtmf}) {
		my $lang = "ivr/ThinkWalnut/paddle_pop/".$hash_table_ref->{$dtmf};
                $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
               
	} else {
		my $lang = "ivr/ThinkWalnut/paddle_pop/hin";
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
                $mem_obj->{'language'} = 1;
	}
        }
        if($start_level == 1)
         {
             return("__option_selection");
         }

        if($start_level == 2)
         {
             return("__gender_option");
         }
         if($start_level == 3)
         {
            return("__age_selection");
         }
         if($start_level == 4)
         {
            return("__brand_question");
         }

	return ("__option_selection");

}

sub __option_selection
{
	my ($config,$default_values,$mem_obj) = @_;
        my $bg_sound_file = "option";
        my $max_allowed_digit = "1";
	my $hash_table_ref = {
		'1' => '1',
	        '2' => '2' 
	};
       

	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	
        if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

       }
        #=======================================
       my $url ="http://180.179.103.253/13/paddle_pop/api/get_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'broadcast_id'}&level= 1&key_pressed= $dtmf&status= $mem_obj->{'status'}&attempt= $mem_obj->{'attempt'}&language= $mem_obj->{'language'}";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);

       #=======================================
     
        if($dtmf == 1 || $dtmf == 2)

       {

              return ("__gender_option");

       }
       else
       {
              return ("__gender_option");
       }
}

sub __gender_option
{
	my ($config,$default_values,$mem_obj) = @_;
        $default_values->{'invalid_file'}= "wrong_input";
        $default_values->{'invalid_max'} = "max_attempt";
        $default_values->{'timeout_file'}= "no_key";
        $default_values->{'timeout_max'}=  "no_key";
        my $bg_sound_file = "gender";
        my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => '1',
	        '2' => '2' 
	};
        my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);

 	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

      	 }
        #=======================================
       my $url ="http://180.179.103.253/13/paddle_pop/api/get_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'broadcast_id'}&level= 2&key_pressed= $dtmf&status= $mem_obj->{'status'}&attempt= $mem_obj->{'attempt'}&language= $mem_obj->{'language'}";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);

       #=======================================
  
      
      if($dtmf == 1 || $dtmf == 2)
	{
	    return ("__age_selection");
	}
      
}

sub __age_selection
{
        my ($config,$default_values,$mem_obj) = @_;
        $default_values->{'invalid_file'}= "wrong_input";
        $default_values->{'invalid_max'} = "max_attempt";
        $default_values->{'timeout_file'}= "no_key";
        $default_values->{'timeout_max'}=  "no_key";

	my $bg_sound_file = "age";
        my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => '1',
	       	        '2' => '2', 
			'3' => '3',
                        '4' => '4'
	};
        my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);

 	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

      	 }
         #=======================================
       my $url ="http://180.179.103.253/13/paddle_pop/api/get_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'broadcast_id'}&level= 3&key_pressed= $dtmf&status= $mem_obj->{'status'}&attempt= $mem_obj->{'attempt'}&language= $mem_obj->{'language'}";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);

       #=======================================

      if($dtmf == 1 || $dtmf == 2 || $dtmf == 3 || $dtmf == 4)
	{
	    return ("__brand_question");
	}
   
}

sub __brand_question
{
   	my ($config,$default_values,$mem_obj) = @_;
        $default_values->{'invalid_file'}= "wrong_input";
        $default_values->{'invalid_max'} = "max_attempt";
        $default_values->{'timeout_file'}= "no_key";
        $default_values->{'timeout_max'}=  "no_key";

	my $bg_sound_file = "brand_question";
        my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => '1',
	        	'2' => '2' ,
                        '3' => '3',
			'4' => '4',
                        '5' => '5'
	};
        my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);

 	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

      	 }
        #=======================================
       my $url ="http://180.179.103.253/13/paddle_pop/api/get_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'broadcast_id'}&level= 4&key_pressed= $dtmf&status= $mem_obj->{'status'}&attempt= $mem_obj->{'attempt'}&language= $mem_obj->{'language'}";

        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);

       #=======================================

     if($dtmf == 1 || $dtmf == 2 || $dtmf == 3 || $dtmf == 4 || $dtmf == 5)
	{
	      
 	       return ("__thanks_prompt");
	}

}

sub __thanks_prompt
{
       my ($config,$default_values,$mem_obj) = @_;
       $config->{_cti_obj}->exec("Playback","Thanks");
       return "exit";
}

main();
exit;
