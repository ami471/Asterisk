#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($did) = @ARGV;
        my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
        my (%output) = $AGI->ReadParse();
        my $config = {
                '_cti_obj' => $AGI,
                '_db' => 1
        };
        my %value_hash;
        my $default_values = {
                'timeout' => '3000',
                'timeout_count' => '2',
                'timeout_file' => undef,
                'timeout_max' => undef,
                'invalid_count' => '1',
                'invalid_file' => undef,
                'invalid_max' => undef
        };
        my $mem_obj = {
                'session_id' => $output{'uniqueid'},
                'did' => $did,
                'callerid' => $output{'callerid'},
                'count' => '0'
        };
        
        my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
          		$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
        
       return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        my $tablename = 'society_maintainance';
        my $flat_no;
        my $number;
        my $wing;
        #=====Converting 12 digit number to 10 digits===========
	my $mobileno_length = length($mem_obj->{'callerid'});
        if ($mobileno_length > 10)
        {
                my $n = 2;
                $mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);

        }
	#=======================================================
	my $contact_no = $mem_obj->{'callerid'};

        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select flat_no,amount,wing from $tablename where mobile_no = '$contact_no'";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array()){
        $flat_no          =      $row[0];
        $number           =      $row[1];
        $wing             =      $row[2];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
        $mem_obj->{'flat_no'} = $flat_no;
        $mem_obj->{'number'}  = $number;
	$mem_obj->{'wing'}    = $wing;
	
	if(!$number)
	{
		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/Sorry");
		return "exit";
	}
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/Welcome");
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/flat_no");
	$config->{_cti_obj}->exec("SayDigits","$flat_no");
	if($wing == 1)
	{
        	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/q_wing");
	}
	if($wing == 2)
	{
		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/r_wing");
	}

	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/amount");
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/rupees");
	
	if(length($number) == 8 || length($number) == 9) 
	{
		return("__croreprompt");
	} 
	if(length($number) == 6 || length($number) == 7)
	{
		return("__lakhprompt");

	}
	if(length($number) == 5 || length($number) == 4 ||length($number) == 3 || length($number) == 2 || length($number) == 1)
	{
		$config->{_cti_obj}->exec("SayNumber","$number");
	}
	
	
}

sub __croreprompt
{
		my ($config,$default_values,$mem_obj) = @_;
		my $number = $mem_obj->{'recharge_amount'};
	        if(length($number) == 8)
		{
				
			$digit = substr($number, 0, 1);
			$number = substr($number,1);
			$config->{_cti_obj}->exec("Playback","en/digits/$digit");
			$config->{_cti_obj}->exec("Playback","en/digits/crore");
			if(length($number) == 6 || length($number) == 7)
			{
				if(length($number) == 6) 
				{
        				$digit_1 = substr($number, 0, 1);
        				$number = substr($number,1);
					$config->{_cti_obj}->exec("Playback","en/digits/$digit_1");
                        		$config->{_cti_obj}->exec("Playback","en/digits/lakhs");

        			} 
				else 
				{
        					$digit_1 = substr($number, 0, 2);
        					$number = substr($number,2);
						if($digit_1 >= 20 && $digit_1 < 30)
						{
							$dig2 = substr($digit_1,1);
							$config->{_cti_obj}->exec("Playback","en/digits/20");
							$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
							$config->{_cti_obj}->exec("Playback","en/digits/lakhs");
							$config->{_cti_obj}->exec("SayNumber","$number");

        					}
						if($digit_1 >= 30 && $digit_1 < 40)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/30");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 40 && $digit_1 < 50)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/40");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 50 && $digit_1 < 60)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/50");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 60 && $digit_1 < 70)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/60");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 70 && $digit_1 < 80)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/70");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 80 && $digit_1 < 90)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/80");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 90 && $digit_1 < 100)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/90");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }

				}

			}
		}
		else 
		{
         	
         		$digit = substr($number, 0, 2);
			$dig2 = substr($digit,1);
         		$number = substr($number,2);
			
			if($digit >= 10 && $digit < 20)
			{
				$config->{_cti_obj}->exec("Playback","en/digits/10");
			}
			if($digit >= 20 && $digit < 30)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/20");
                        }
			if($digit >= 30 && $digit < 40)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/30");
                        }
			if($digit >= 40 && $digit < 50)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/40");
                        }
			if($digit >= 50 && $digit < 60)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/50");
                        }
			 if($digit >= 60 && $digit < 70)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/60");
                        }
			 if($digit >= 70 && $digit < 80)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/70");
                        }
			if($digit >= 80 && $digit < 90)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/80");
                        }
			if($digit >= 90 && $digit < 100)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/90");
                        }
			$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
			$config->{_cti_obj}->exec("Playback","en/digits/crore");
			if(length($number) == 6 || length($number) == 7)
			{
				if(length($number) == 6) 
				{
        				$digit_1 = substr($number, 0, 1);
        				$number = substr($number,1);
					$config->{_cti_obj}->exec("Playback","en/digits/$digit_1");
                        		$config->{_cti_obj}->exec("Playback","en/digits/lakhs");

        			} 
				else 
				{
        					$digit_1 = substr($number, 0, 2);
        					$number = substr($number,2);
						if($digit_1 >= 10 && $digit_1 < 20)
                                                {
                                                       # $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$digit_1");
                                                        #$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 20 && $digit_1 < 30)
						{
							$dig2 = substr($digit_1,1);
							$config->{_cti_obj}->exec("Playback","en/digits/20");
							$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
							$config->{_cti_obj}->exec("Playback","en/digits/lakhs");
							$config->{_cti_obj}->exec("SayNumber","$number");

        					}
						if($digit_1 >= 30 && $digit_1 < 40)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/30");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 40 && $digit_1 < 50)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/40");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 50 && $digit_1 < 60)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/50");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 60 && $digit_1 < 70)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/60");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 70 && $digit_1 < 80)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/70");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 80 && $digit_1 < 90)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/80");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 90 && $digit_1 < 100)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/90");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }

				}

			}
		}
}

sub __lakhprompt
{
		my ($config,$default_values,$mem_obj) = @_;
                my $number = $mem_obj->{'recharge_amount'};
		


		if(length($number) == 6) 

		{
					 


        				$digit_1 = substr($number, 0, 1);

        				$number = substr($number,1);

					$config->{_cti_obj}->exec("Playback","en/digits/$digit_1");

                        		$config->{_cti_obj}->exec("Playback","en/digits/lakhs");

					$config->{_cti_obj}->exec("SayNumber","$number");



        	} 

		else 

		{
					$digit_1 = substr($number, 0, 2);
					$number = substr($number,2);
					

					 if($digit_1 >= 10 && $digit_1 < 20)
                                                {
                                                       # $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$digit_1");
                                                        #$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }

					if($digit_1 >= 20 && $digit_1 < 30)

						{

							$dig2 = substr($digit_1,1);

							$config->{_cti_obj}->exec("Playback","en/digits/20");

							$config->{_cti_obj}->exec("Playback","en/digits/$dig2");

							$config->{_cti_obj}->exec("Playback","en/digits/lakhs");

							$config->{_cti_obj}->exec("SayNumber","$number");



        					}

						if($digit_1 >= 30 && $digit_1 < 40)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/30");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						 if($digit_1 >= 40 && $digit_1 < 50)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/40");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						 if($digit_1 >= 50 && $digit_1 < 60)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/50");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						if($digit_1 >= 60 && $digit_1 < 70)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/60");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						 if($digit_1 >= 70 && $digit_1 < 80)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/70");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						 if($digit_1 >= 80 && $digit_1 < 90)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/80");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						if($digit_1 >= 90 && $digit_1 < 100)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/90");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }



        					

		}

}

main();
exit;
