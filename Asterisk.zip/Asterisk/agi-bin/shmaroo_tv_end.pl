#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;


sub __update_status{

	my ($config,$default_values,$mem_obj) = @_;
        my $mobileno_length = length($mem_obj->{'callerid'});
	my $callerid;
	my $key_pressed;
	my $call_start_time;
        my $key_status = 0;
        my $flag_status;
	if ($mobileno_length > 10)
	{
		my $n = 2;
        	$mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);  
        	
	}
	my $customer_no = $mem_obj->{'callerid'};
        my $dial_status = $mem_obj->{'dialed_status'};
       # ========================================================================
	my $value = 1;
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "select callerid,key_pressed,call_start_time from shemaroo_bhakti where callerid = $customer_no order by callerid_count desc limit 1";
	my $sth = $dbh->prepare($query) ;
        my  $ret =$sth->execute();
	while(my @row = $sth->fetchrow_array())
        {
              $callerid         =      $row[0];
              $key_pressed      =      $row[1];
	      $call_start_time  =      $row[2];
	     
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
        if($key_pressed == 1 || $key_pressed == 2)
	{
	   $key_status = 1;
	   $flag_status = "true";
	}
        else
	{
	   $flag_status = "false";
	}		
      #  my $filename = '/var/log/asterisk/test_report.txt';
      #  open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
      #  print $fh "value of flag status=$flag_status,keypressed=$key_pressed  and callTime=$call_start_time \n";
      #  close $fh;

	my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
	 $year +=1900;
        $mon  +=1;
        my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
        my $call_agent_end_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
         my $filename = '/var/log/asterisk/test_report.txt';
        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
        print $fh "value of flag status=$flag_status,keypressed=$key_pressed  and callEndTime=$call_agent_end_time \n";
         close $fh;
	 my $tablename = 'shemaroo_bhakti';
         my $value = 1;
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
         my $query = "update $tablename set call_end_time ='$call_agent_end_time' where callerid = '$customer_no' order by callerid_count desc limit 1";
         my $sth = $dbh->prepare($query);
         $sth->execute();
         if ($sth->rows())
         {
             $value =  0;
         }
         $sth->finish();
         $dbh->disconnect();
	
        my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
        my $req = GET "http://172.20.120.105/17/shemarooTV/quiz/api/registerCall.php?test=$flag_status&p1=$customer_no&call_start_time=$call_start_time&call_end_time=$call_agent_end_time&date=$current_date&keyPress=$key_pressed";
        my $res = $ua->request($req);
	if ($res->is_success) {
                        print $res->content;
			my $filename = '/var/log/asterisk/test_report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for http://172.20.120.105/17/shemarooTV/quiz/api/registerCall.php?test=$flag_status&p1=$customer_no&call_start_time=$call_start_time&call_end_time=$call_agent_end_time&date=$current_date&keyPress=$key_pressed \n";
               close $fh;
                }else{
                        print $res->status_line . "\n";
			my $filename = '/var/log/asterisk/test_report.txt';
                	open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                	print $fh "Response is not sucessful for http://172.20.120.105/17/shemarooTV/quiz/api/registerCall.php?test=$flag_status&p1=$customer_no&call_start_time=$call_start_time&call_end_time=$call_agent_end_time&date=$current_date&keyPress=$key_pressed \n";
                close $fh;

                	}
        return "exit";
     
}




sub main {

	my (${CID},${DIALSTATUS}) = @ARGV;
	my $AGI = new Asterisk::AGI;
        my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'callerid' => ${CID},
		'dialed_status' => ${DIALSTATUS}
	};
		
	my $function = "__update_status";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
