#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;

sub __welcome
{
        my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/Welcome_foodhall");
#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/Welcome_axis");
#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/Welcome_pincode");
	return("__postal_pincode");
}
sub __postal_pincode
{
	my ($config,$default_values,$mem_obj) = @_;
        my $weekday;
	my $time_now;
	my $day_is;
        my $pincode;
	my $division_name;
	my $region_name;
	my $circle_name;
	my $taluka;
	my $district_name;
	my $statename;
	my $zone;
        my $attempt;
	my $short;
        my $noinput_flag = 0;
        my $wronginput_flag = 0;
	$mem_obj->{'count'}++;
        my ($sec,$min,$hour,$date,$mon,$year,$wday,$yday,$isdst) = localtime();
        if($wday == 0)
	{
		$weekday = 'Sun';
	}
	elsif($wday == 1)
	{
		$weekday = 'Mon';
	}
	elsif($wday == 2)
        {
                $weekday = 'Tue';
        }
	elsif($wday == 3)
        {
                $weekday = 'Wed';
        }
	elsif($wday == 4)
        {
                $weekday = 'Thu';
        }
	elsif($wday == 5)
        {
                $weekday = 'Fri';
        }
	else
        {
                $weekday = 'Sat';
        }
        if($wday == 0 || $wday == 6)
        {
		$day_is = "Weekend";
	}
	else
        {
		$day_is = "Weekday"
	}
	$year +=1900;
	$mon  +=1;
#	my $current_date = sprintf("%02d/%02d/%02d",$date,$mon,$year);
	my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
	my $current_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
	my $time_display = sprintf("%02d%02d%02d",$hour,$min,$sec);

	if ($time_display >= '210000' && $time_display < '240000')
	{
		$time_now = "Night";
	}
	if ($time_display >= '050000' && $time_display < '120000')
        {
                $time_now = "Morning";
        }
	if ($time_display >= '120000' && $time_display < '160000')
        {
                $time_now = "Afternoon";
        }
	if ($time_display >= '160000' && $time_display < '210000')
        {
                $time_now = "Evening";
        }
#        if($wronginput_flag)
#	{
#		my $bg_sound_file = "ivr/ThinkWalnut/dasien/gss_invalid_repeat";
#	}	
#	else
#        {
		my $bg_sound_file = "ivr/ThinkWalnut/dasien/enter_pin";
#	}
	
	my $max_allowed_digit = "6";
        my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});    
	if ($dtmf == -3 or $dtmf == -2)
	{
		 $dtmf           = "No Input";
                 $statename      = '===';
                 $zone           = '===';
                 $district_name  = '===';
		 $noinput_flag   = 1; 

	  

	}
	#==================SELECT FROM PINCODE TABLE=========================================
        my $tablename = 'pincode_detail';
        my $value = 1;
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select pincode,division_name,region_name,circle_name,taluka,district_name,statename,zone from $tablename where pincode = $dtmf order by pincode desc limit 1";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
                $pincode          =      $row[0];
                $division_name    =      $row[1];
                $region_name      =      $row[2];
                $circle_name      =      $row[3];
                $taluka           =      $row[4];
                $district_name    =      $row[5];
                $statename        =      $row[6];
                $zone             =      $row[7];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();

#=============================================================================================
	if(!$noinput_flag)
	{
        	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/gss_u_hv_enterd");
        	$config->{_cti_obj}->exec("SayDigits","$dtmf");
	
		$bg_sound_file = "ivr/ThinkWalnut/dasien/gss_stayline"; 
		$max_allowed_digit = "1";	
		my $hash_table_ref = 
		{

			'1' => '1'

		};

		my $confirm = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},0,undef,undef,$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
        
		if ($confirm == 1) 
		{
		    	if($pincode)
        	    	{
			#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/Thanks_iifl");
		#		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/Thanks_axis");
			#	return ("__connectcall");
        	    	}
        	    	else
        	    	{
			 	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/gss_invalid_pin");
				$wronginput_flag =1;
				$count=$mem_obj->{'count'};
                        	if($count == 1)
                        	{

                                	return ("__postal_pincode");
                        	}
				if($count > 1)
				{
                                        $dtmf           = "Invalid";
                                        $statename      = "===";
                                        $zone           = "===";
                                        $district_name  = "===";
                                }



			}
		   
		}
		else
		{ 
			$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/gss_invalid_pin");
			$wronginput_flag = 1;
			$count=$mem_obj->{'count'};
                	if($count == 1)
                	{
				
				return ("__postal_pincode"); 
			}

		}
	}
	my $mobileno_length = length($mem_obj->{'callerid'});
	if ($mobileno_length > 10)
	{
		my $n = 2;
        	$mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);  
        	
	}
	#================INSERT IN CUSTOMER TABLE ===========================================
#	my $tablename = 'customer_detail';
#	my $dbh_1 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
#        my $query_1 = "INSERT INTO $tablename (mobile_no,division_name,date,time,day,Time_Session,statename,zone,city,pincode,campaign,Brand,media_channel,media_vehicle,AdCopy,source,media_code,region_name,circle_name,taluka,weekday) VALUES('$mem_obj->{'callerid'}','$division_name','$current_date','$current_time','$weekday','$time_now','$statename','$zone','$district_name','$dtmf','DAISIN_DEMO','Addcopy','PRINT','Hindu','Ritz','IVR','$mem_obj->{'did'}','$region_name','$circle_name','$taluka','$day_is')";
 #       my $sth_1 = $dbh_1->prepare($query_1) ;
  #      my $ret_1 =$sth_1->execute();
#	$sth_1->finish(); 
 #       $dbh_1->disconnect();
        
	 my $tablename = 'iifl_customer_detail';
        my $dbh_1 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query_1 = "INSERT INTO $tablename (mobile_no,location,date,time,day,Time_Session,zone,pincode,campaign,weekday,media_channel,media_vehicle) VALUES('$mem_obj->{'callerid'}','$district_name','$current_date','$current_time','$weekday','$time_now','$zone','$dtmf','FOODHALL','$day_is','PRINT','FOODHALL')";
        my $sth_1 = $dbh_1->prepare($query_1) ;
        my $ret_1 =$sth_1->execute();
        $sth_1->finish();
        $dbh_1->disconnect();
	#====================================================================================	
	if($pincode)
	{ 
        #	return ("__connectcall");
		return("__connectcall_in_queue");
	}
               

}

sub __connectcall
{
	my ($config,$default_values,$mem_obj) = @_;
#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/dasien/connecting");
	my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $out_no = $mem_obj->{'callerid_out_1'};
	my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};	
	$config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$current_date/$filename,m");
	my $out_no = $mem_obj->{'callerid_out_1'};
	my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
	my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        if ($call_status eq "ANSWER") 
	{

              return "exit";

       }
       if ($call_status eq "BUSY") 
       {

       		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
       		return "exit";
       }
       if ($call_status eq "NOANSWER") 
       {

       		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
       		return "exit";
      }


}

sub __connectcall_in_queue
{
	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Set","CHANNEL(musicclass)=support");
	$config->{_cti_obj}->exec("Queue","support,,,,60");
        return "exit";

}

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$did");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'callerid' => $output{'callerid'},
		'did' => $did,
		'dial_group' => "$value_hash{shadi}->{dial_group}",
                'dial_channel' => "$value_hash{shadi}->{dial_channel}",
                'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
                'callerid_out_1' => "$value_hash{shadi}->{'escalate_number'}",
		'count' => '0'
                 
	};
		
	my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}



sub read_ini_file {

		my ($filename,$hashref) = @_;

		my $tmphashref;

		$tmphashref = Config::INI::Reader->read_file($filename); 

		%{$hashref} = %{$tmphashref};

}



main();
exit;

