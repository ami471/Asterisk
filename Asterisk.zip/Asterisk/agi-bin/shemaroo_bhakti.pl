#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use Time::Local;

sub __question_selection{

	my ($config,$default_values,$mem_obj) = @_;
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/New_Shemaroo_Files/phone_ringing");
	my ($sec,$min,$hour,$date,$mon,$year,$wday,$yday,$isdst) = localtime();
	$year +=1900;
        $mon  +=1;
        my $today_date = sprintf("%02d",$date);
      #  my $current_date = sprintf("%02d%02d%02d",$year,$mon,$date);
	my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
	my $call_start_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
        my $lang = "ivr/ThinkWalnut/New_Shemaroo_Files/hin";
	$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
	$config->{_cti_obj}->exec("Playback","Welcome");
	my $bg_sound_file = "option";
        my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => '1',
	        '2' => '2' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	
        if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

       }
	
	if($mem_obj->{'did'} == 8673)
         {
              
                $mem_obj->{'did'} = '8432843251';

         }
	my $mobileno_length = length($mem_obj->{'callerid'});
	if ($mobileno_length > 10)
	{
		my $n = 2;
        	$mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);  
        	
	}
	
        my $tablename = 'shemaroo_bhakti';
        my $did = $mem_obj->{'did'};
        my $customer_no = $mem_obj->{'callerid'};
       # my $dtmf_input = $dtmf;
       # if($dtmf_input == -3 || $dtmf_input == -2 || $dtmf_input == -1)
       # {
       #		$dtmf_input = 0;
#	}
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "INSERT INTO $tablename (callerid,destination_no, key_pressed,call_start_time,today_date) VALUES('$customer_no','$did','$dtmf','$call_start_time','$current_date')";

	my $sth = $dbh->prepare($query) ;

	my $ret =$sth->execute();

        $dbh->disconnect();
     
        if($dtmf == 1)

       {
	   $config->{_cti_obj}->exec("Playback","Clip_04");
	  # return ("__thanks_particpation");
	   return "exit";


       }
       if($dtmf == 2)
	{
		
	    $config->{_cti_obj}->exec("Playback","Clip_05");
       #     return ("__thanks_particpation");
	    return "exit";

        }
      
	
     
}

sub __drop_call {

        my ($config,$default_values,$mem_obj) = @_;

        return "exit";

}

sub __thanks_particpation
{
	my ($config,$default_values,$mem_obj) = @_;
        $config->{_cti_obj}->exec("Playback","Clip_06");
         return "exit";
}

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$did");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
        my $default_values = {
		'timeout' => '5000',
		'timeout_count' => '2',
		'timeout_file' => 'Clip_02_Final',
		'timeout_max' => 'Clip_03',
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'callerid' => $output{'callerid'},
		'did' => $did
	};
		
	my $function = "__question_selection";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
