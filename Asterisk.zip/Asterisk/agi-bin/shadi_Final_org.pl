#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi_org.conf";
	read_ini_file($file_name,\%value_hash);

	my $default_values = {
		'timeout' => '4000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
                
	};
	
	my ($lead_id,undef) = split(/\./,$output{'uniqueid'});

	my $mem_obj = {
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
		'did' => $did,
		'dial_group' => "$value_hash{shadi}->{dial_group}",
		'dial_channel' => "$value_hash{shadi}->{dial_channel}",
		'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
		'callerid_out_1' => "$value_hash{shadi}->{escalate_number}",
                'callerid_out_2' => "$value_hash{shadi}->{escalate_number_2}",
                'callerid_out_3' => "$value_hash{shadi}->{escalate_number_3}",
		'dial_group_sec' => "$value_hash{shadi}->{dial_group_sec}"
	};
	my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $timeout = $mem_obj->{'dial_timeout'};		
	my $function = "__language_selection";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub __language_selection{

	my ($config,$default_values,$mem_obj) = @_;

	my $bg_sound_file = "ivr/ThinkWalnut/shadi_Final/language";
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/Welcome");
	my $max_allowed_digit = "1";
	
	my $hash_table_ref = {
			'1' => 'eng',
	        '2' => 'hin' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	
	#return "exit" if ($dtmf < 0);
							   
    if (exists $hash_table_ref->{$dtmf}) {
		my $lang = "ivr/ThinkWalnut/shadi_Final/".$hash_table_ref->{$dtmf};
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	} else {
		my $lang = "ivr/ThinkWalnut/shadi_Final/eng";
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	}
	
	return ("__action_on_key_1");

}

sub __action_on_key_1 {

       my ($config,$default_values,$mem_obj) = @_;

       $config->{_cti_obj}->exec("Playback","connecting");
       my $dial_group = $mem_obj->{'dial_group'};
       my $dial_out = $mem_obj->{'callerid_out_1'};
       my $dial_channel = $mem_obj->{'dial_channel'};
       my $timeout = $mem_obj->{'dial_timeout'};
       my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};
       $config->{_cti_obj}->exec("Monitor","wav,$filename,m");
       my $out_no = $mem_obj->{'callerid_out_1'};
       my $dial_string = my $dial_string = $dial_channel."/".$dial_group."/".$out_no;
       my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
       my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
       if ($call_status eq "ANSWER") {

              return "exit";

       }
       if ($call_status eq "BUSY") {

       $config->{_cti_obj}->exec("Playback","not_rechable");
       return "exit";
      }
      if ($call_status eq "NOANSWER") {

       $config->{_cti_obj}->exec("Playback","not_rechable");
       return "exit";
      }


       $config->{_cti_obj}->exec("StopMonitor","");

       $mem_obj->{'last_dialed'} = $out_no;
       return "__failure_case";

}

sub __action_on_key_2 {

       my ($config,$default_values,$mem_obj) = @_;

       $config->{_cti_obj}->exec("Playback","connecting");
       my $dial_group = $mem_obj->{'dial_group'};
       my $dial_out = $mem_obj->{'callerid_out_2'};

       my $dial_channel = $mem_obj->{'dial_channel'};

       my $timeout = $mem_obj->{'dial_timeout'};

       my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};

      $config->{_cti_obj}->exec("Monitor","wav,$filename,m");
      my $out_no = $mem_obj->{'callerid_out_2'};

       my $dial_string = my $dial_string =$dial_channel."/".$dial_group."/".$out_no;

       my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");

       my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");

       if ($call_status eq "ANSWER") {

              return "exit";
	}
      if ($call_status eq "BUSY") {

       $config->{_cti_obj}->exec("Playback","not_rechable");
       return "exit";
      }
         
      if ($call_status eq "NOANSWER") {

       $config->{_cti_obj}->exec("Playback","not_rechable");
       return "exit";
      }

       $config->{_cti_obj}->exec("StopMonitor","");

       $mem_obj->{'last_dialed'} = $out_no;
       return "__failure_case";

}

sub __action_on_key_3 {

       my ($config,$default_values,$mem_obj) = @_;

       $config->{_cti_obj}->exec("Playback","connecting");
       my $dial_group = $mem_obj->{'dial_group'};
       my $dial_out = $mem_obj->{'callerid_out_1'};
       my $dial_channel = $mem_obj->{'dial_channel'};

       my $timeout = $mem_obj->{'dial_timeout'};

       my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};

      $config->{_cti_obj}->exec("Monitor","wav,$filename,m");
      my $out_no = $mem_obj->{'callerid_out_3'};

       my $dial_string = $dial_channel."/".$dial_group."/".$out_no;

       my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");

       my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");

       if ($call_status eq "ANSWER") {

              return "exit";

       }

       if ($call_status eq "BUSY") {

       $config->{_cti_obj}->exec("Playback","not_rechable");
       return "exit";
      }
      if ($call_status eq "NOANSWER") {

       $config->{_cti_obj}->exec("Playback","not_rechable");
       return "exit";
      }


       $config->{_cti_obj}->exec("StopMonitor","");

       $mem_obj->{'last_dialed'} = $out_no;
       return "__failure_case";

}
sub __failure_case {

       my ($config,$default_values,$mem_obj) = @_;


       return "exit";

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
