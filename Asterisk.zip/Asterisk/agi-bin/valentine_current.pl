#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($number_dialed) = @ARGV;
        my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
        my (%output) = $AGI->ReadParse();
        my $config = {
                '_cti_obj' => $AGI,
                '_db' => 1
        };
        my %value_hash;
        my $default_values = {
                'timeout' => '5000',
                'timeout_count' => '2',
                'timeout_file' => undef,
                'timeout_max' => undef,
                'invalid_count' => '2',
                'invalid_file' => undef,
                'invalid_max' => undef
        };
        my $mem_obj = {
                'session_id' => $output{'uniqueid'},
                'did' => $did,
                'number_dialed' => $number_dialed,
                'mobile_no' => '',
                'count' => '0'
        };
        my $tablename = 'valentine_call';
        my $value = 1;
        my $number = $mem_obj->{'number_dialed'};
  #       __logFile("In Main mobile number", $number);
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","amit1234");
        my $query = "update $tablename set status ='ANSWERED' where callerid = '$number'";
        my $sth = $dbh->prepare($query);
        $sth->execute();
        if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();
	my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
            		
			$loop = 0;
	    }
	    $function = $next_action;

	} while ($loop);
        return -1;
}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
	my $tablename = 'valentine_call';
   	my $interaction_id;
        my $registration;
   	my $contactno = $mem_obj->{'number_dialed'};
   	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","amit1234");
   	my $query = "select interaction_id,registration from $tablename where callerid = '$contactno' ";
   	my $sth = $dbh->prepare($query) ;
   	my $ret =$sth->execute();
   	while(my @row = $sth->fetchrow_array())
   	{
        	$interaction_id  =      $row[0];
		$registration    =      $row[1];
   	}
   	$sth->finish();  #24/08/16
   	$dbh->disconnect();
   	$mem_obj->{'interaction_id'} = $interaction_id;
        $mem_obj->{'registration'}   = $registration;
#        my $lang = "ivr/ThinkWalnut/infant";
#        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
        my $bg_sound_file = "ivr/ThinkWalnut/valentine/Prompt_2";
       #========================******For pushing the response****** =============================
        my $url ="http://172.20.120.105/13/sunlight/api/vday_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid=  $mem_obj->{'interaction_id'}&keypress= 0";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
        #====================================================================================

        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/valentine/Prompt_1");
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/valentine/songs");
        my $max_allowed_digit = "1";
	my $hash_table_ref = {
		'1' => '1'
	         
	};
    	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf
	}
        my $number = $mem_obj->{'number_dialed'};
        #========================******For pushing the response****** =============================
      my $url ="http://172.20.120.105/13/sunlight/api/vday_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid=  $mem_obj->{'interaction_id'}&keypress= $dtmf";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
        #====================================================================================
	if($dtmf == 1)
	{
		return ("__valentine_choice");
	}
        
        
}

sub __valentine_choice
{
    my ($config,$default_values,$mem_obj) = @_;
    #================DB OPERATION========================
    my $tablename = 'valentine_call';
    my $count;
    my $value = 1;
    my $contactno = $mem_obj->{'number_dialed'};
    my $interaction_id = $mem_obj->{'interaction_id'};
    my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","amit1234");
    my $query = "select COUNT(*) FROM $tablename where callerid = '$contactno' and status = 'ANSWERED' and sequence = 1 ";
    my $sth = $dbh->prepare($query) ;
    my $ret =$sth->execute();
    while(my @row = $sth->fetchrow_array())
    {
            $count  =      $row[0];
               
    }
    $sth->finish();  
    $dbh->disconnect();
#    if($count > 0)
#   {
#   	$count = $count - $value;
#   }
    #=========================================================
    $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/valentine/Prompt_3");
    $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/valentine/Prompt_4");
    my $number = $mem_obj->{'number_dialed'};
    my $base_path = "/var/lib/asterisk/recordings/mb/$number-$count";
    my $silence = 10;
    my $time_duration = 10;
    my $string = "/var/lib/asterisk/recordings/mb/$number-%d.wav";
    $config->{_cti_obj}->exec("Record","$string,$silence,$time_duration");
    #===================DB OPERATION====================================
    my $dbh_1 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","amit1234");
    my $query_1 = "update $tablename set sequence = 1 where callerid = '$contactno' and interaction_id ='$interaction_id' ";
    my $sth_1 = $dbh_1->prepare($query_1) ;
    my $ret_1 =$sth_1->execute();
    $sth_1->finish();
    $dbh_1->disconnect();
    #==================================================================    
    
    $mem_obj->{'prompt'} = $base_path;
    return ("__enter_mobno");
}

sub __enter_mobno
{
   my ($config,$default_values,$mem_obj) = @_;
   my $bg_sound_file = "enter_mobno";
   my $bg_sound_file = "ivr/ThinkWalnut/valentine/Prompt_5";
   my $max_allowed_digit = "10";
   $default_values->{'invalid_file'}= "ivr/ThinkWalnut/valentine/Prompt_6";
  # $default_values->{'invalid_max'} = "maximum_tr
   $default_values->{'timeout_file'}= "ivr/ThinkWalnut/valentine/Prompt_7";
#   $default_values->{'timeout'}=  25;

   
   my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});
   #========================******For pushing the response****** =============================
   my $url ="http://172.20.120.105/13/sunlight/api/vday_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid=  $mem_obj->{'interaction_id'}&keypress= $dtmf&name= $mem_obj->{'prompt'}";
   my $request = new HTTP::Request(POST => $url  );
   $request->content_type('application/x-www-form-urlencoded');
   my $ua = LWP::UserAgent->new();
   my $response = $ua->request($request);
   #====================================================================================
    $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/valentine/Thank_you");
   return "exit";
}

main();
exit;
