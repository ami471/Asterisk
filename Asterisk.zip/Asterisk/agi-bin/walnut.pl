#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;



sub __language_selection{

	my ($config,$default_values,$mem_obj) = @_;

	my $bg_sound_file = "ivr/ThinkWalnut/option_en_lang";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => 'eng',
	        '2' => 'hin' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	
	 if (exists $hash_table_ref->{$dtmf}) {

		my $lang = "ivr/ThinkWalnut/".$hash_table_ref->{$dtmf};

		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");

		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};

	} else {

		my $lang = "ivr/ThinkWalnut/eng";
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};

	}
	if($dtmf == 1)
	{
		$config->{_cti_obj}->exec("Playback","u_hv_enterd");
         	$config->{_cti_obj}->exec("SayDigits","$dtmf");      
        	
       }
       if($dtmf == 2)

       {

          	$config->{_cti_obj}->exec("Playback","gs_u_hv_enterd");
         	$config->{_cti_obj}->exec("SayDigits","$dtmf");

	}
	return "exit";


}

sub __failure_case {

	my ($config,$default_values,$mem_obj) = @_;
        $config->{_cti_obj}->exec("Playback","gss_thk");
        return "exit";
}

sub __drop_call {

        my ($config,$default_values,$mem_obj) = @_;

        return "exit";

}

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$did");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
	my %value_hash;

	my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'did' => $did
	};
		
	my $function = "__language_selection";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
