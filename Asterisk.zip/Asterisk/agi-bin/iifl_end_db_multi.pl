#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;


sub __update_status{

	my ($config,$default_values,$mem_obj) = @_;
	my $customer_no = $mem_obj->{'callerid'};
        my $dial_status = $mem_obj->{'dialed_status'};
        my $name;
        my $iifl_agent;
	my $location;        
        my $date;            
        my $time;            
        my $day;             
        my $Time_Session;   
        my $zone;             
        my $pincode;         
        my $campaign;        
        my $weekday;          
        my $media_channel;    
        my $media_vehicle;    
        my $status;          
        my $languagekey; 
        my $type;
        my $did;
        my $pincode_enterd = 0;     
        my $pincode_present = 0;
        my $used_count = 0;
	if($dial_status eq "ANSWERED" )
	{
		$dial_status = 'ANSWERED';
	}
        if($dial_status eq "CHANUNAVAIL")
	{
		$dial_status = "BUSY";
	}	
        if($dial_status eq "ANSWER" || $dial_status eq "NOANSWER" || $dial_status eq "BUSY")
	{
		if($dial_status eq "ANSWER")
		{
		    $dial_status = 'ANSWERED';
		}
		my $tablename = 'iifl_customer_detail';
        	my $value = 1;
        	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        	my $query = "update $tablename set status = '$dial_status' where mobile_no = '$customer_no' order by id desc limit 1";
        	my $sth = $dbh->prepare($query);
        	$sth->execute();
        	if ($sth->rows()) 
		{
			$value =  0;
        	}		
        	$sth->finish();
    		$dbh->disconnect();
	}
##===== FOR MULTICONTACT
	my $tablename = 'pincode_count';
        my $value = 1;

        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select count(*),used_count from $tablename where pincode = (select pincode from iifl_customer_detail where mobile_no = $customer_no order by id desc limit 1);";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
                $pincode_present          =      $row[0];
                $used_count               =      $row[1];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
        $mem_obj->{'pincode_present'}     =     $pincode_present;
         my $filename = '/var/log/asterisk/multicontact.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Count = $pincode_present and used count = $used_count \n";
               close $fh;

        if($pincode_present)
        {
                my $value = 1;
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select name,contact_1 from multicontact_pincode where pincode_count = $used_count and  pincode = (select pincode from iifl_customer_detail where mobile_no = $customer_no order by id desc limit 1)";
        my $sth = $dbh->prepare($query) ;
        my  $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
              $name             =      $row[0];
              $iifl_agent       =      $row[1];

        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
 #       my $filename = '/var/log/asterisk/multicontact.txt';
 #               open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
 #               print $fh "Name = $name and IIFL Agent = $iifl_agent \n";
 #              close $fh;


        }
        else
	{
    	my $value = 1;
  	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select name,contact_1 from iifl_pincode where pincode = (select pincode from iifl_customer_detail where mobile_no = $customer_no order by id desc limit 1)";
        my $sth = $dbh->prepare($query) ;
        my  $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
              $name             =      $row[0];
	      $iifl_agent       =      $row[1];

        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
#        my $filename = '/var/log/asterisk/multicontact.txt';
#                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
#                print $fh "Name = $name and IIFL Agent = $iifl_agent \n";
#               close $fh;
        }
        

       # ========================================================================
	my $value = 1;
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "select location,date,time,day,Time_Session,zone,pincode,campaign,weekday,media_channel,media_vehicle,status,languagekey,state,did from iifl_customer_detail where mobile_no = $customer_no order by id desc limit 1";
	my $sth = $dbh->prepare($query) ;
        my  $ret =$sth->execute();
	while(my @row = $sth->fetchrow_array())
        {
              $location         =      $row[0];
              $date             =      $row[1];
	      $time             =      $row[2];
	      $day              =      $row[3];
              $Time_Session     =      $row[4];
              $zone             =      $row[5];
	      $pincode          =      $row[6];
              $campaign         =      $row[7];
              $weekday          =      $row[8];
	      $media_channel    =      $row[9];
              $media_vehicle    =      $row[10];
              $status           =      $row[11];
	      $languagekey      =      $row[12];
	      $state            =      $row[13];
	      $did              =      $row[14];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
	if($media_vehicle eq "PL_CO_CAMPAIGNS")
	{
        	$type = 3;
        }	
	elsif($media_vehicle eq "BL_CO_CAMPAIGNS")
	{	
        	$type = 4;
        }
	elsif($media_vehicle eq "GL_CO_CAMPAIGNS")
	{
        	$type = 5;
        }
	elsif($media_vehicle eq "MISCELLANEOUS_CO_CAMPAIGNS")
	{
        	$type = 6;
        }
	else
	{
        	$type = 1;
        }

        my $filename = '/var/log/asterisk/multicontact.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Name = $name and IIFL Agent = $iifl_agent \n";
               close $fh;

        my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
	my $req = GET "http://www.rubicsolution.in/IIFL/api/iiflCustomerDetails.php?mobile_no=$customer_no&location=$location&date=$date&time=$time&day=$day&Time_Session=$Time_Session&zone=$zone&pincode=$pincode&campaign=$campaign&weekday=$weekday&media_channel=$media_channel&media_vehicle=$media_vehicle&status=$status&languagekey=$languagekey&type=$type&state=$state&did=$did";
	my $res = $ua->request($req);

	#========================================================================       
	if ($dial_status eq "ANSWER" or $dial_status eq "ANSWERED") 
	{
       #=================IIFL Customer====
	my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=8&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$name&spokenTo=$iifl_agent";
                my $res = $ua->request($req);
	#============IIFL Agent==========================
	my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=10&callerNo=$mem_obj->{'callerid'}&toSend=$iifl_agent&name=$mem_obj->{'name'}&spokenTo=$mem_obj->{'callerid'}";
                my $res = $ua->request($req);
       }

	
 	if($languagekey)
        {
              
            $pincode_enterd = 1;  
        }
        if(!$pincode_enterd)
        {
                 my ($sec,$min,$hour,$date,$mon,$year,$wday,$yday,$isdst) = localtime();
		 $year +=1900;
                 $mon  +=1;

                 my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
                # my $did      = $mem_obj->{'did_mobile'};
                 my $customer_no = $mem_obj->{'callerid'};
                 my $media_vehicle = $mem_obj->{'media_vehicle'};
		 my $branch_code   = $mem_obj->{'branch_code'};
                 my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                 my $req = GET "https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=$media_channel&ivr_nbr=$did&Mobile=$customer_no&call_time=$current_date&circle=$location&BranchCode=$branch_code";
                         my $res = $ua->request($req);
                if ($res->is_success) {
                        print $res->content;
                        my $filename = '/var/log/asterisk/media_report_end_jan.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=$media_channel&ivr_nbr=$did&Mobile=$customer_no&call_time=$current_date&circle=$location&BranchCode=$branch_code \n";
               close $fh;
                }else{
                        print $res->status_line . "\n";
                        my $filename = '/var/log/asterisk/media_report_end_jan.txt';
                        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                        print $fh "Response is not sucessful for https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=$media_channel&ivr_nbr=$did&Mobile=$customer_no&call_time=$current_date&circle=$location&BranchCode=$branch_code \n";
                close $fh;

                        }

        }
        return "exit";
     
}




sub main {

	my (${CID},${DIALSTATUS}) = @ARGV;
	my $AGI = new Asterisk::AGI;
        my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'callerid' => ${CID},
		'dialed_status' => ${DIALSTATUS}
	};
		
	my $function = "__update_status";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
