#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;

sub __welcome
{
        my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/cure_hospital/Welcome");
	return("__hospital_location");
}
sub __hospital_location
{
	my ($config,$default_values,$mem_obj) = @_;
        my $bg_sound_file = "ivr/ThinkWalnut/cure_hospital/thane_kolkata";
	my $max_allowed_digit = "1";
        my $hash_table_ref = {
                '1' => '1',
                '2' => '2'
        };
        my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
        if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf
        }
	if($dtmf == 1)
        {
                return ("__thane_hospital");
        }
        if($dtmf == 2)
       	{
                return ("__kolkata_hospital");
       	}

}

sub __thane_hospital
{
	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/cure_hospital/service_thane");
	my $bg_sound_file = "ivr/ThinkWalnut/cure_hospital/hospital_facility";
	 my $max_allowed_digit = "1";
        my $hash_table_ref = {
                '1' => '1',
                '2' => '2',
		'3' => '3',
		'4' => '4',
		'5' => '5'
        };
        my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	$mem_obj->{'digit_pressed'} = $dtmf;

        if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf
        }
	if($dtmf == 1)
	{
		return("__connectcall");		
	}
	if($dtmf == 2)
        {
                return("__connectcall_2");
        }
	if($dtmf == 3)
        {
                return("__connectcall_3");
        }
	if($dtmf == 4)
        {
                return("__connectcall_4");
        }
	if($dtmf == 5)
        {
                return("__connectcall_5");
        }


}

sub __kolkata_hospital
{
	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/cure_hospital/service_kolkata");
	my $bg_sound_file = "ivr/ThinkWalnut/cure_hospital/hospital_facility";
	 my $max_allowed_digit = "1";
        my $hash_table_ref = {
                '1' => '1',
                '2' => '2',
		'3' => '3',
                '4' => '4',
                '5' => '5'

        };
        my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	$mem_obj->{'digit_pressed'} = $dtmf;

        if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf
        }
	if($dtmf == 1)
        {
                return("__connectcall");
        }
        if($dtmf == 2)
        {
                return("__connectcall_2");
        }
        if($dtmf == 3)
        {
                return("__connectcall_3");
        }
        if($dtmf == 4)
        {
                return("__connectcall_4");
        }
        if($dtmf == 5)
        {
                return("__connectcall_5");
        }





}


sub __connectcall
{
	my ($config,$default_values,$mem_obj) = @_;
#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/connecting");
	my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
        my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};	
	$config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$current_date/$filename,m");
	my $out_no = $mem_obj->{'callerid_out_1'};
	my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
	my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        if ($call_status eq "ANSWER") 
	{

              return "exit";

       }
       if ($call_status eq "BUSY") 
       {

       		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
       		return "exit";
       }
       if ($call_status eq "NOANSWER") 
       {

       		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
       		return "exit";
      }


}

sub __connectcall_2
{
        my ($config,$default_values,$mem_obj) = @_;
#       $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/connecting");
        my $dial_group = $mem_obj->{'dial_group'};
        my $dial_channel = $mem_obj->{'dial_channel'};
        my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};
        $config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$current_date/$filename,m");
        my $out_no = $mem_obj->{'callerid_out_2'};
        my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
        my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
        my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        if ($call_status eq "ANSWER")
        {
         
	  return "exit";
	}
       if ($call_status eq "BUSY")
       {

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                return "exit";
       }
       if ($call_status eq "NOANSWER")
       {

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                return "exit";
      }


}

sub __connectcall_3
{
        my ($config,$default_values,$mem_obj) = @_;
#       $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/connecting");
        my $dial_group = $mem_obj->{'dial_group'};
        my $dial_channel = $mem_obj->{'dial_channel'};
        my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};
        $config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$current_date/$filename,m");
        my $out_no = $mem_obj->{'callerid_out_3'};
        my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
        my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
        my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        if ($call_status eq "ANSWER")
        {
         
	  return "exit";
	}
       if ($call_status eq "BUSY")
       {

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                return "exit";
       }
       if ($call_status eq "NOANSWER")
       {

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                return "exit";
      }


}

sub __connectcall_4
{
        my ($config,$default_values,$mem_obj) = @_;
#       $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/connecting");
        my $dial_group = $mem_obj->{'dial_group'};
        my $dial_channel = $mem_obj->{'dial_channel'};
        my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};
        $config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$current_date/$filename,m");
        my $out_no = $mem_obj->{'callerid_out_4'};
        my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
        my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
        my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        if ($call_status eq "ANSWER")
        {

          return "exit";
        }
       if ($call_status eq "BUSY")
       {

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                return "exit";
       }
       if ($call_status eq "NOANSWER")
       {

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                return "exit";
      }


}

sub __connectcall_5
{
        my ($config,$default_values,$mem_obj) = @_;
#       $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/connecting");
        my $dial_group = $mem_obj->{'dial_group'};
        my $dial_channel = $mem_obj->{'dial_channel'};
        my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};
        $config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$current_date/$filename,m");
        my $out_no = $mem_obj->{'callerid_out_5'};
        my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
        my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
        my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        if ($call_status eq "ANSWER")
        {

          return "exit";
        }
       if ($call_status eq "BUSY")
       {

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                return "exit";
       }
       if ($call_status eq "NOANSWER")
       {

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                return "exit";
      }


}


sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$did");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'callerid' => $output{'callerid'},
		'did' => $did,
		'dial_group' => "$value_hash{shadi}->{dial_group}",
                'dial_channel' => "$value_hash{shadi}->{dial_channel}",
                'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
                'callerid_out_1' => "$value_hash{shadi}->{'escalate_number'}",
		'callerid_out_2' => "$value_hash{shadi}->{'escalate_number_2'}",
		'callerid_out_3' => "$value_hash{shadi}->{'escalate_number_3'}",
		'callerid_out_4' => "$value_hash{shadi}->{'escalate_number_4'}",
		'callerid_out_5' => "$value_hash{shadi}->{'escalate_number_5'}",
		'count' => '0'
                 
	};
		
	my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}



sub read_ini_file {

		my ($filename,$hashref) = @_;

		my $tmphashref;

		$tmphashref = Config::INI::Reader->read_file($filename); 

		%{$hashref} = %{$tmphashref};

}



main();
exit;

