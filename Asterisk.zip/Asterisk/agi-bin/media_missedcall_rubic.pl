#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;
use Time::Local;
#use XML::Simple 'XMLin';
# this __dial_out function is dialing out call_center number and hanging up at the last
sub __dial_out {
	
	my ($config,$mem_obj) = @_;
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $dial_group = $mem_obj->{'dial_group'}; 
	my $timeout = $mem_obj->{'dial_timeout'};
	my $dial_out = $mem_obj->{'call_center_no'};
        my $callerid = $mem_obj->{'callerid'};
        my $did	     = "0226121".$mem_obj->{'did'};
        my $weekday;
	my $day_is;
        my $media_vehicle;
	my $media_channel;
	my $series;
	my $series_idea;
	my $circle;
	my $campaign;
        my $flag = 0;
        my $number;
	#=========Changes to 10 digit number
        my $mobileno_length = length($mem_obj->{'callerid'});
        if ($mobileno_length > 10)
        {
                my $n = 2;
                $mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);
		$callerid = $mem_obj->{'callerid'};
	}
	#========To Select Telecom Circle==========================
        $series      = substr($callerid, 0, 4);
	$series_idea = substr($callerid, 0, 3);

        if($series_idea == 140)
        {
                return "exit";
        }
       my $tablename = 'telecom_circle';
       my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
      my $query = "select circle from $tablename where series =$series";
      my $sth = $dbh->prepare($query) ;
      my $ret =$sth->execute();
      while(my @row = $sth->fetchrow_array())
        {

                $circle   = $row[0];
               
        }
        $sth->finish();
        $dbh->disconnect();
        $mem_obj->{'circle'} = $circle;
        if ($circle eq '') 
        {
		$circle = 'OTHERS';
		$mem_obj->{'circle'} = $circle;

	}
        $campaign = 'IIFL GOLDLOAN';
       #========Media Selection based on DID============
        if($mem_obj->{'did'} == 8616)
        {
		$did = '8108102888';
                $media_vehicle = 'TV_MISSED';
		$media_channel = 'TELEVISION';
		$flag = 1;
        }
	if($mem_obj->{'did'} == 8652)
        {
		#$mem_obj->{'did'} = '8108103888';
		$did    = '8108103888';
		$media_vehicle = 'RADIO';
		$media_channel = 'RADIO';
		$flag = 1;
        }
	if($mem_obj->{'did'} == 8617)
        {
		$did = '8108102555';
                $media_vehicle = 'PRINT';
		$media_channel = 'PRINT';
		$flag = 1;
        }
	if($mem_obj->{'did'} == 8623)
        {
               $did    = '6391119111';
                $media_vehicle = 'BTL_MISSED';
                $media_channel = 'BTL';
                $flag = 1;
        }
	if($mem_obj->{'did'} == 8673)
        {
               $did    = '8691911111';
                $media_vehicle = 'OUTDOOR_MISSED';
                $media_channel = 'OUTDOOR';
                $flag = 1;
        }
	if($mem_obj->{'did'} == 8686)
        {
               $did    = '8652433344';
                $media_vehicle = 'PL_CO_Campaigns';
                $media_channel = 'MISSED_EMAIL_SMS';
                $flag = 1;
        }
	if($mem_obj->{'did'} == 8665)
        {
               $did    = '8652407000';
                $media_vehicle = 'BL_CO_Campaigns';
                $media_channel = 'MISSED_EMAIL_SMS';
                $flag = 1;
        }
	if($mem_obj->{'did'} == 8670)
        {
               $did    = '8652404000';
                $media_vehicle = 'GL';
                $media_channel = 'GL_CO_Campaigns';
                $flag = 1;
        }
	if($mem_obj->{'did'} == 8672)
        {
               $did    = '8652433444';
                $media_vehicle = 'Miscellaneous_CO_Campaigns';
                $media_channel = 'MISSED_EMAIL_SMS';
                $flag = 1;
        }
	if($mem_obj->{'did'} == 8698)
        {
               $did    = '8828836111';
                $media_vehicle = 'IIFL_EQUITY';
                $media_channel = 'MISSED_EMAIL_SMS';
                $flag = 1;
        }
	 if($mem_obj->{'did'} == 8628)
        {
               $did    = '8828836333';
                $media_vehicle = 'IIFL_MUTUAL_FUND';
                $media_channel = 'MISSED_EMAIL_SMS';
                $flag = 1;
        }


        if($mem_obj->{'did'} == 8635)
        {
               $did    = '8108105222';
                $media_vehicle = 'NCD Tranche2';
                $media_channel = 'NCD Tranche2';
                $flag = 1;
        }
	
	if($mem_obj->{'did'} == 8688)
        {
               $did    = '9009070907';
                $media_vehicle = 'KalNirnay';
                $media_channel = 'KalNirnay';
                $flag = 1;
        }

	
  
	#==========Date Time Display============
        my ($sec,$min,$hour,$date,$mon,$year,$wday,$yday,$isdst) = localtime();
        if($wday == 0)
        {
                $weekday = 'SUNDAY';
        }
        elsif($wday == 1)
        {
                $weekday = 'MONDAY';
        }
        elsif($wday == 2)
        {
                $weekday = 'TUESDAY';
        }
        elsif($wday == 3)
        {
                $weekday = 'WEDNESDAY';
        }
        elsif($wday == 4)
        {
                $weekday = 'THURSDAY';
        }
          elsif($wday == 5)
        {
                $weekday = 'FRIDAY';
        }
        else
        {
                $weekday = 'SATURDAY';
        }
        if($wday == 0 || $wday == 6)
        {
                $day_is = "WEEKEND";
        }
        else
        {
                $day_is = "WEEKDAY"
        }
        $year +=1900;
        $mon  +=1;
	my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
        my $current_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
        my $time_display = sprintf("%02d%02d%02d",$hour,$min,$sec);

        if ($time_display >= '210000' && $time_display < '240000')
        {
                $time_now = "NIGHT";
        }
        if ($time_display >= '050000' && $time_display < '120000')
        {
                $time_now = "MORNING";
        }
        if ($time_display >= '120000' && $time_display < '160000')
        {
                $time_now = "AFTERNOON";
        }
        if ($time_display >= '160000' && $time_display < '210000')
        {
                $time_now = "EVENING";
        }
        
        #=======================================
   	my $tablename = 'mediamissed_calling';
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count =0;
        my $query = "INSERT INTO $tablename (mobno,status,did,media_channel,media_vehicle,day,weekday,date,time,Time_Session,campaign,circle) VALUES('$callerid','NOANSWER','$did','$media_channel','$media_vehicle','$weekday','$day_is','$current_date','$current_time','$time_now','$campaign','$circle')";
	my $sth = $dbh->prepare($query) ;
	my $ret =$sth->execute();
        $dbh->disconnect();
 
        
        my $dbh_2 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count_2 =0;
        my $query_2 = "DELETE FROM $tablename WHERE status ='ANSWERED'";
        my $sth_2 = $dbh_2->prepare($query_2) ;
        my $ret_2 =$sth_2->execute();
        $dbh_2->disconnect();
        
	if($flag == 1)
        {
                 $number = $mem_obj->{'callerid'};
                my $circle_region = $mem_obj->{'circle'} ;
                my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/pushMisscall.php?dispnumber=$did&caller_id=$number&end_time=$current_time&circle_id=$circle_region";
                my $res = $ua->request($req);
                if ($res->is_success) {
                        print $res->content;
			my $filename = '/var/log/asterisk/report_vatika.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for http://rubicsolution.in/IIFL/api/pushMisscall.php?dispnumber=$did&caller_id=$number&end_time=$current_time&circle_id=$circle_region\n";
                close $fh;
                }else{
                        print $res->status_line . "\n";
			my $filename = '/var/log/asterisk/report_vatika.txt';
                	open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                	print $fh "Response is not sucessful for http://rubicsolution.in/IIFL/api/pushMisscall.php?dispnumber=$did&caller_id=$number&end_time=$current_time&circle_id=$circle_region \n";
                close $fh;

                }


        }
     
       

	if ($status_var eq "CHANUNAVAIL" or $status_var eq "CONGESTION") {
		$dial_group = $mem_obj->{'dial_group_sec'};
		#my $callerid_out = $mem_obj->{'callerid_out_sec'};
		$config->{_cti_obj}->exec("Set","CALLERID(num)=$callerid_out");	
		#$dial_string = $dial_channel."/".$dial_group."/".$dial_out;
                my $dial_string = "SIP/".$dial_out;
		$status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout");
	}

      return "exit";
	
}

# main function
sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
	$AGI->exec("NoOP","dial_out======$dial_out_num");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI
	};	
	my %value_hash;
	my $file_name = "/uc/config/ini/missed_call.conf";
	read_ini_file($file_name,\%value_hash);
		
	my $mem_obj = {
		'callerid' => $output{'callerid'},
		'did' => $did,
		'session_id' => $output{'uniqueid'},
		#'dial_group' => $value_hash{mahindra_call}->{dial_group},
		#'dial_group_sec' => $value_hash{mahindra_call}->{dial_group_sec},
		#'dial_channel' => $value_hash{mahindra_call}->{dial_channel},
		'dial_timeout' => $value_hash{missed_call}->{dial_timeout},
		'call_center_no' =>$value_hash{missed_call}->{call_center_no},
		#'callerid_out' => $value_hash{mahindra_call}->{callerid_out},
		#'callerid_out_sec' => $value_hash{mahindra_call}->{callerid_out_sec}
		
	};	
	
	my $function = "__dial_out";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}



sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub post_number {

 my ($config,$mem_obj) = @_;
        my $callerid = $mem_obj->{'callerid'};
        my $uniqueid = $mem_obj->{'session_id'};
	my $called_no;
	if($mem_obj->{'did'} == 8607)
	{
		 $called_no = 9222216216;
	}
        if($mem_obj->{'did'} == 8626)
	{
		$called_no = 18002668412;
	}
	if($mem_obj->{'did'} == 8627)
	{
		$called_no = 18002668411;
	}
	if($mem_obj->{'did'} == 8631)
        {
                $called_no = 18001218607;
        }
	if($mem_obj->{'did'} == 8632)
        {
                $called_no = 18001215930;
        }

       # my $url ="http://172.20.120.105/13/wma/api/misscall_api.php?mdn=$callerid";
        my $url ="http://172.20.120.105/13/api/twd_get_misscall.php?c=$called_no&m=$callerid";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        my $current_time = sprintf("%02d%02d%02d",$hour,$min,$sec);
        if ($response->is_success)
        {
                my $filename = '/var/log/asterisk/report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url and time is $current_time \n";
                close $fh;





                                return 1;

        }  else {

                my $status_lin = $response->status_code;
		my $filename = '/var/log/asterisk/report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is unsucessful for $url and time is $current_time\n";
                close $fh;

                 return -1;
        }

   return "exit";
	
       
}

#=============CrayFish=================
sub post_crayfish_detail {

 my ($config,$mem_obj) = @_;
        my $callerid = $mem_obj->{'callerid'};
        my $uniqueid = $mem_obj->{'session_id'};
        my $called_no;
        my $time = time;
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	my $current_time = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year +1900, $mon+1, $mday, $hour, $min, $sec);
        my $url ="https://crayfish.twd.bz/utilities/missedCallDump.php?mdn=$callerid&timestamp=$current_time&src=2";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
         if ($response->is_success)
        {
                my $filename = '/var/log/asterisk/report_crayfish.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url and time is $current_time \n";
                close $fh;





                                return 1;

        }  else {
                my $status_lin = $response->status_code;
                my $filename = '/var/log/asterisk/report_crayfish.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is unsucessful for $url and time is $current_time\n";
                close $fh;

                 return -1;
        }

   return "exit";


}
#============Till here=================

main();
exit;
