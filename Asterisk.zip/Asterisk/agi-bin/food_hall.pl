#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;
use Time::Local;
sub __welcome
{
        my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/IIFL_Campaign/Welcome");
	return("__pincode_based_selection");
}

sub __pincode_based_selection
{
	my ($config,$default_values,$mem_obj) = @_;
	if($mem_obj->{'did'} == 8676)
        {
                $media_vehicle = 'DAINIK BHASKAR(NORTH)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
        if($mem_obj->{'did'} == 8677)
        {
                $media_vehicle = 'RAJSTHAN PATRIKA(NORTH)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
        if($mem_obj->{'did'} == 8674)
        {
                $media_vehicle = 'AMAR UJALA';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	if($mem_obj->{'did'} == 8675)
        {
                $media_vehicle = 'DAINIK JAGARAN(NORTH)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	if($mem_obj->{'did'} == 8650)
        {
                $media_vehicle = 'DIVYA BHASKAR';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_central");
        }
	if($mem_obj->{'did'} == 8651)
        {
                $media_vehicle = 'SANDESH';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_central");
        }
	if($mem_obj->{'did'} == 8654)
        {
                $media_vehicle = 'VIJAY KARNATKA';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_south_1");
        }
	if($mem_obj->{'did'} == 8656)
        {
                $media_vehicle = 'VIJAYAWANI';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_south_1");
        }
	if($mem_obj->{'did'} == 8657)
        {
                $media_vehicle = 'EENADU';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_south_1");
        }
	if($mem_obj->{'did'} == 8658)
        {
                $media_vehicle = 'DAILY THANTI';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_south_2");
        }
	if($mem_obj->{'did'} == 8659)
        {
                $media_vehicle = 'DINAKARAN';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_south_2");
        }
	if($mem_obj->{'did'} == 8660)
        {
                $media_vehicle = 'DIVYA MARATHI';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_west");
        }
	if($mem_obj->{'did'} == 8661)
        {
                $media_vehicle = 'LOKMAT';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_west");
        }
	if($mem_obj->{'did'} == 8699)
	{
		$media_vehicle = 'SAKAL';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_west");
	}
	if($mem_obj->{'did'} == 8690)
        {
                $media_vehicle = 'DAINIK BHASKAR JBL(WEST1)';
                $mem_obj->{'media_vehicle'} = $media_vehicle;
                return("__language_selection_west");
        }

	if($mem_obj->{'did'} == 8662)
        {

                $media_vehicle = 'DAINIK BHASKAR(WEST2)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	if($mem_obj->{'did'} == 8663)
        {
                $media_vehicle = 'RAJASTHAN PATRIKA(WEST2)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	if($mem_obj->{'did'} == 8678)
        {
                $media_vehicle = 'DAINIK BHASKAR(JBL)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	if($mem_obj->{'did'} == 8679)
        {
                $media_vehicle = 'DAINIK JAGARAN(WEST2)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	if($mem_obj->{'did'} == 8666)
        {
                $media_vehicle = 'BTL';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	if($mem_obj->{'did'} == 8664)
        {
                $media_vehicle = 'OUTDOOR(CENTRAL)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_central");
        }
	if($mem_obj->{'did'} == 8686)
        {
                $media_vehicle = 'OUTDOOR(NORTH)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	if($mem_obj->{'did'} == 8665)
        {
                $media_vehicle = 'OUTDOOR(SOUTH1)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_south_1");
        }
	if($mem_obj->{'did'} == 8687)
        {
                $media_vehicle = 'TV_CAMPAIGN';
                $mem_obj->{'media_vehicle'} = $media_vehicle;
                return("__language_selection_south_1");
        }

	if($mem_obj->{'did'} == 8668)
        {
                $media_vehicle = 'OUTDOOR(SOUTH2)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_south_2");
        }
	if($mem_obj->{'did'} == 8670)
        {
                $media_vehicle = 'OUTDOOR(WEST1)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_west");
        }
	if($mem_obj->{'did'} == 8672)
        {
                $media_vehicle = 'OUTDOOR(WEST2)';
		$mem_obj->{'media_vehicle'} = $media_vehicle;
		return("__language_selection_north");
        }
	 if($mem_obj->{'did'} == 8693)
        {
                $media_vehicle = 'FOODHALL';
                $mem_obj->{'media_vehicle'} = $media_vehicle;
                return("__language_selection_foodhall");
        }


}

sub __language_selection_north{

	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/IIFL_Campaign/Welcome");

	my $bg_sound_file = "ivr/ThinkWalnut/IIFL_Campaign/language_north";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => 'hin',
	        	'2' => 'eng' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	 if (exists $hash_table_ref->{$dtmf}) {
		my $lang = "ivr/ThinkWalnut/IIFL_Campaign/".$hash_table_ref->{$dtmf};
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	} else {
		my $lang = "ivr/ThinkWalnut/IIFL/hin";
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	}
	
	return ("__postal_pincode");

}

sub __language_selection_foodhall{

        my ($config,$default_values,$mem_obj) = @_;
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/IIFL_Campaign/Welcome");

        
                my $lang = "ivr/ThinkWalnut/IIFL/eng";
                $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
                $mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
        

        return ("__postal_pincode");

}


sub __language_selection_south_1{

	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/IIFL_Campaign/Welcome");
	my $bg_sound_file = "ivr/ThinkWalnut/IIFL_Campaign/language_South_1";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => 'telgu',
			'2' => 'kannad',
	        	'3' => 'eng' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	 if (exists $hash_table_ref->{$dtmf}) {
		my $lang = "ivr/ThinkWalnut/IIFL_Campaign/".$hash_table_ref->{$dtmf};
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	} else {
		my $lang = "ivr/ThinkWalnut/IIFL/eng";
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	}
	
	return ("__postal_pincode");

}

sub __language_selection_south_2{

	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/IIFL_Campaign/Welcome");
	my $bg_sound_file = "ivr/ThinkWalnut/IIFL_Campaign/language_South2";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => 'tamil',
			'2' => 'malyalam',
	        	'3' => 'eng' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	 if (exists $hash_table_ref->{$dtmf}) {
		my $lang = "ivr/ThinkWalnut/IIFL_Campaign/".$hash_table_ref->{$dtmf};
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	} else {
		my $lang = "ivr/ThinkWalnut/IIFL/eng";
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	}
	
	return ("__postal_pincode");

}

sub __language_selection_central{

	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/IIFL_Campaign/Welcome");

	my $bg_sound_file = "ivr/ThinkWalnut/IIFL_Campaign/language_central";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => 'gujrati',
			'2' => 'hin',
	        	'3' => 'eng' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	 if (exists $hash_table_ref->{$dtmf}) {
		my $lang = "ivr/ThinkWalnut/IIFL_Campaign/".$hash_table_ref->{$dtmf};
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	} else {
		my $lang = "ivr/ThinkWalnut/IIFL/gujrati";
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	}
	
	return ("__postal_pincode");

}

sub __language_selection_west{

	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/IIFL_Campaign/Welcome");
	my $bg_sound_file = "ivr/ThinkWalnut/IIFL_Campaign/language_marathi";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => 'marathi',
			'2' => 'hin',
	        	'3' => 'eng' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	 if (exists $hash_table_ref->{$dtmf}) {
		my $lang = "ivr/ThinkWalnut/IIFL_Campaign/".$hash_table_ref->{$dtmf};
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	} else {
		my $lang = "ivr/ThinkWalnut/IIFL/marathi";
		$config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
		$mem_obj->{'lang'} = $hash_table_ref->{$dtmf};
	}
	
	return ("__postal_pincode");

}


sub __postal_pincode
{
	my ($config,$default_values,$mem_obj) = @_;
        my $weekday;
	my $time_now;
	my $day_is;
        my $pincode;
	my $country_pincode;
	my $contact_1;
	my $contact_2;
	my $name;
        my $location;
        my $zone;
	my $state;
	my $email_id;
	my $emp_code;
        my $branch_name;
	my $branch_code;
	my $attempt;
	my $short;
        my $noinput_flag = 0;
        my $wronginput_flag = 0;
        my $media_vehicle;
        my $media_channel = 'PRINT';
	$mem_obj->{'count'}++;
        my ($sec,$min,$hour,$date,$mon,$year,$wday,$yday,$isdst) = localtime();
        if($wday == 0)
	{
		$weekday = 'Sun';
	}
	elsif($wday == 1)
	{
		$weekday = 'Mon';
	}
	elsif($wday == 2)
        {
                $weekday = 'Tue';
        }
	elsif($wday == 3)
        {
                $weekday = 'Wed';
        }
	elsif($wday == 4)
        {
                $weekday = 'Thu';
        }
	elsif($wday == 5)
        {
                $weekday = 'Fri';
        }
	else
        {
                $weekday = 'Sat';
        }
        if($wday == 0 || $wday == 6)
        {
		$day_is = "Weekend";
	}
	else
        {
		$day_is = "Weekday"
	}
	$year +=1900;
	$mon  +=1;
	my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
	my $current_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
	my $time_display = sprintf("%02d%02d%02d",$hour,$min,$sec);
	$mem_obj->{'current_time'}  = $current_time;
	if ($time_display >= '210000' && $time_display < '240000')
	{
		$time_now = "Night";
	}
	if ($time_display >= '050000' && $time_display < '120000')
        {
                $time_now = "Morning";
        }
	if ($time_display >= '120000' && $time_display < '160000')
        {
                $time_now = "Afternoon";
        }
	if ($time_display >= '160000' && $time_display < '210000')
        {
                $time_now = "Evening";
        }
	my $bg_sound_file = "enter_pincode";
        my $max_allowed_digit = "6";
        my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});    
	if ($dtmf == -3 or $dtmf == -2)
	{
		 $dtmf           = "No Input";
                 $noinput_flag   = 1; 
	}
	#==================SELECT FROM PINCODE TABLE=========================================
        my $tablename = 'iifl_pincode';
        my $value = 1;
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select pincode,contact_1,name,location,email_id,emp_code,state,branch_name,branch_code from $tablename where pincode = $dtmf order by pincode desc limit 1";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
                $pincode          =      $row[0];
                $contact_1        =      $row[1];
                $name      	  =      $row[2];
		$location         =      $row[3];
		$email_id         =      $row[4];
                $emp_code         =      $row[5];
                $state            =      $row[6];
                $branch_name      =      $row[7];
	        $branch_code      =      $row[8];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
	$mem_obj->{'pincode'}     = 	$pincode;
	$mem_obj->{'contact_1'}   =     $contact_1;
        $mem_obj->{'name'}        =     $name;
	$mem_obj->{'location'}    =     $location;
#==================================INDIA PINCODE===========================================================
	my $tablename = 'pincode_detail';
        my $value = 1;
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select pincode from $tablename where pincode = $dtmf order by pincode desc limit 1";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
                $country_pincode          =      $row[0];
                
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();


#============================================================================================================
	if(!$noinput_flag)
	{
        	
        
		
		if($pincode)
        	{
			
			

                	

        	}
        	else
        	{      
			
			#=====INVALID ENTRY TO ZOHO==================
		
			#===============
 
			if($country_pincode)
			{
			#	$ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                	#	$req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=9&time=$current_time&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$mem_obj->{'name'}&spokenTo=$mem_obj->{'contact_1'}";
                 	#	$res = $ua->request($req);

				$config->{_cti_obj}->exec("Playback","sorry_callback");
				return "exit";

			}
			
			if($count < 1)
			{
				$config->{_cti_obj}->exec("Playback","invalid_pincode");
			}
			$wronginput_flag =1;
			$count=$mem_obj->{'count'};
                        if($count == 1)
                        {

                               return ("__postal_pincode");
                        }
			if($count > 1)
			{
                              #          $dtmf           = "Invalid";
                                        $statename      = "===";
                                        $zone           = "===";
                                        $location  	= "===";
				$config->{_cti_obj}->exec("Playback","maximum_attempt");
				my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=5&time=$current_time&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$mem_obj->{'name'}&spokenTo=$mem_obj->{'contact_1'}";
                my $res = $ua->request($req);
				

                        }



		}
		   
		
		
	}
	my $mobileno_length = length($mem_obj->{'callerid'});
	if ($mobileno_length > 10)
	{
		my $n = 2;
        	$mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);  
        	
	}
	
#================INSERT IN CUSTOMER TABLE ===========================================
        $media_vehicle =  $mem_obj->{'media_vehicle'};
	my $tablename = 'iifl_customer_detail';
	my $dbh_1 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query_1 = "INSERT INTO $tablename (mobile_no,location,date,time,day,Time_Session,zone,pincode,campaign,weekday,media_channel,media_vehicle) VALUES('$mem_obj->{'callerid'}','$location','$current_date','$current_time','$weekday','$time_now','NORTH','$dtmf','IIFL','$day_is','PRINT','$media_vehicle')";
        my $sth_1 = $dbh_1->prepare($query_1) ;
        my $ret_1 =$sth_1->execute();
	$sth_1->finish(); 
        $dbh_1->disconnect();

	#====================================================================================	
	if($pincode)
	{ 
        #	return ("__connectcall");
		return("__connectcall_in_queue");
	}
               

}

sub __connectcall
{
	my ($config,$default_values,$mem_obj) = @_;
	my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        $year +=1900;
        $mon  +=1;
        my $current_date = sprintf("%03d%02d%02d",$year,$mon,$date);
        my $customer_no = $mem_obj->{'callerid'};
        my $current_time = $mem_obj->{'current_time'};
        my $name = $mem_obj->{'name'};
        my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $out_no = $mem_obj->{'contact_1'};
	my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "iifl-".$mem_obj->{callerid}."-".$mem_obj->{contact_1};	
	$config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$year/$mon/$date/$filename,m");
	my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
#	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout");
	my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        $config->{_cti_obj}->exec("NoOp","===$call_status");
        if ($call_status eq "ANSWER") 
	{
	      my $tablename = 'iifl_customer_detail';
              my $value = 1;
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "update $tablename set status ='ANSWERED' where mobile_no = '$customer_no' order by id desc limit 1";
              my $sth = $dbh->prepare($query);
              $sth->execute();
              if ($sth->rows()) {

                $value =  0;
		}
        	$sth->finish();
        	$dbh->disconnect();
	        return "exit";

        }
       $config->{_cti_obj}->exec("StopMonitor","");
       if ($call_status eq "BUSY") 
       {
	      my $tablename = 'iifl_customer_detail';
              my $value = 1;
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "update $tablename set status ='BUSY' where mobile_no = '$customer_no' order by id desc limit 1";
              my $sth = $dbh->prepare($query);
              $sth->execute();
              if ($sth->rows()) {

                $value =  0;
                }
                $sth->finish();
                $dbh->disconnect();
               #=============Message to IIFL Agent=============================
                my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=1&time=$current_time&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'contact_1'}&name=$mem_obj->{'name'}&spokenTo=$mem_obj->{'contact_1'}";
                my $res = $ua->request($req);
	        #=============Message to IIFL Customer=============================
		$ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=7&time=$current_time&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$mem_obj->{'name'}&spokenTo=$mem_obj->{'contact_1'}";
                 $res = $ua->request($req);



       		$config->{_cti_obj}->exec("Playback","sorry_callback");
       		return "exit";
       }
       if ($call_status eq "NOANSWER") 
       {
	      my $tablename = 'iifl_customer_detail';
              my $value = 1;
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "update $tablename set status ='NOANSWER' where mobile_no = '$customer_no' order by id desc limit 1";
              my $sth = $dbh->prepare($query);
              $sth->execute();
              if ($sth->rows()) {

                $value =  0;
                }
                $sth->finish();
                $dbh->disconnect();
        #=============Message to IIFL Agent=============================
		my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=1&time=$current_time&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'contact_1'}&name=$mem_obj->{'name'}&spokenTo=$mem_obj->{'contact_1'}";
                my $res = $ua->request($req);
         #===========Message to Customer=======================================
		 $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
		 $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=7&time=$current_time&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$mem_obj->{'name'}&spokenTo=$mem_obj->{'contact_1'}";
                 $res = $ua->request($req);




       		$config->{_cti_obj}->exec("Playback","sorry_callback");
       		return "exit";
      }


}

sub __connectcall_in_queue
{
	my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Set","CHANNEL(musicclass)=support");
	$config->{_cti_obj}->exec("Queue","support,,,,60");
        return "exit";

}

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$did");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);
        my $default_values = {
		'timeout' => '5000',
		'timeout_count' => '3',
		'timeout_file' =>  'no_input',
		'timeout_max' => 'no_input_max',
		'invalid_count' => '2',
		'invalid_file' => 'maximum_attempt',
		'invalid_max' => undef
	};

	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'callerid' => $output{'callerid'},
		'did' => $did,
		'dial_group' => "$value_hash{shadi}->{dial_group}",
                'dial_channel' => "$value_hash{shadi}->{dial_channel}",
                'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
                'callerid_out_1' => "$value_hash{shadi}->{'escalate_number'}",
		'count' => '0'
                 
	};
		
	my $function = "__pincode_based_selection";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}



sub read_ini_file {

		my ($filename,$hashref) = @_;

		my $tmphashref;

		$tmphashref = Config::INI::Reader->read_file($filename); 

		%{$hashref} = %{$tmphashref};

}



main();
exit;

