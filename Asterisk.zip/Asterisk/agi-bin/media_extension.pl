#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;
use Time::Local;

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);

	my $default_values = {
		'timeout' => '4000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
                
	};
	
	my ($lead_id,undef) = split(/\./,$output{'uniqueid'});

	my $mem_obj = {
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
		'did' => $did,
		'dial_group' => "$value_hash{shadi}->{dial_group}",
		'dial_channel' => "$value_hash{shadi}->{dial_channel}",
		'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
		'callerid_out_1' => "07666844433",
                'callerid_out_2' => "8369854211",
                'callerid_out_3' => "$value_hash{shadi}->{'escalate_number_3'}",
		'dial_group_sec' => "$value_hash{shadi}->{dial_group_sec}"
	};
	my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $timeout = $mem_obj->{'dial_timeout'};		
	my $function = "__time_evaluate";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub __time_evaluate
{
	my ($config,$default_values,$mem_obj) = @_;
	my $weekday;
        my $day_is;
	my $zone;
	my $time_now;
	my $media_channel;
        my $lead_source;
	my $series_idea;
	my ($sec,$min,$hour,$date,$mon,$year,$wday,$yday,$isdst) = localtime();
	if($wday == 0)
        {
                $weekday = 'Sun';
        }
        elsif($wday == 1)
        {
                $weekday = 'Mon';
        }
        elsif($wday == 2)
        {
                $weekday = 'Tue';
        }
        elsif($wday == 3)
        {
                $weekday = 'Wed';
        }
        elsif($wday == 4)
        {
                $weekday = 'Thu';
        }
        elsif($wday == 5)
        {
                $weekday = 'Fri';
        }
        else
        {
                $weekday = 'Sat';
        }
        $weekday = uc $weekday;
        if($wday == 0 || $wday == 6)
        {
                $day_is = "Weekend";
        }
        else
        {
                $day_is = "Weekday"
        }
         $day_is = uc $day_is;
	 $year +=1900;
         $mon  +=1;
         my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
         my $current_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
         my $call_start_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
	 my $time_display = sprintf("%02d%02d%02d",$hour,$min,$sec);
        if ($time_display >= '210000' && $time_display < '235959')
        {
                $time_now = "NIGHT";
        }
	if ($time_display > '000000' && $time_display < '040000')
        {
                $time_now = "NIGHT";
        }

        if ($time_display >= '040000' && $time_display < '120000')
        {
                $time_now = "MORNING";
        }
        if ($time_display >= '120000' && $time_display < '160000')
        {
                $time_now = "AFTERNOON";
        }
        if ($time_display >= '160000' && $time_display < '210000')
        {
                $time_now = "EVENING";
        }
	my $mobileno_length = length($mem_obj->{'callerid'});
        if ($mobileno_length > 10)
	{
		my $n = 2;
        	$mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);  
        	
	}	
	my $callerid = $mem_obj->{'callerid'};
	$series_idea = substr($callerid, 0, 2);
        if($series_idea == 14)
        {
                return "exit";
        }
	my $tablename = 'media_extension_detail';
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count =0;
	my $query = "INSERT INTO $tablename (mobile_no,date,time,day,Time_Session,campaign,weekday,call_start_time) VALUES('$callerid','$current_date','$current_time','$weekday','$time_now','IIFL SECURITY','$day_is','$call_start_time')";
         my $sth = $dbh->prepare($query) ;
         my $ret =$sth->execute();
         $dbh->disconnect();
	return("__extension_based_selection");

}


sub __extension_based_selection {

	my ($config,$default_values,$mem_obj) = @_;
        my $extension;
        my $mobile_no;
        my $lang = "ivr/ThinkWalnut/call_demo";
        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
        $config->{_cti_obj}->exec("Playback","Welcome");
	my $bg_sound_file = "option_new";
        my $max_allowed_digit = "4";
        my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});    
	$mem_obj->{'dtmf'} = $dtmf;
       if($dtmf < 0)
       {
       
              $config->{_cti_obj}->exec("Playback","max_attempt");
              return ("exit");# if option other than 1,2 & 3 is pressed
       }
         my $tablename = 'media_extension';
        my $value = 1;
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select extension,mobile_no from $tablename where extension = $dtmf order by id desc limit 1";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
                $extension          =      $row[0];
                $mobile_no          =      $row[1];
                

        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
	$mem_obj->{'extension'}     = 	$extension;
	$mem_obj->{'mobile_no'}   =     $mobile_no;
       
       if($mobile_no)
	{ 
        	return("__connectcall");
	}

     return "exit";

}

sub __connectcall
{
	my ($config,$default_values,$mem_obj) = @_;
	my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
	my $customer_no = $mem_obj->{'callerid'};
        my $agent_extension_no = $mem_obj->{'extension'};
        my $agent_mobile_no = $mem_obj->{'mobile_no'};
        $year +=1900;
        $mon  +=1;
        my $current_date = sprintf("%03d%02d%02d",$year,$mon,$date);
	my $call_agent_start_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
	my $tablename = 'media_extension_detail';
        my $value = 1;
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "update $tablename set call_agent_start_time ='$call_agent_start_time',customer_code = '$agent_extension_no',agent_number='$agent_mobile_no' where mobile_no = '$customer_no' order by id desc limit 1";
#	my $filename = '/var/log/asterisk/media_report_nov.txt';
#        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
#        print $fh "The query is $query" 
        my $sth = $dbh->prepare($query);
        $sth->execute();
        if ($sth->rows()) {

             $value =  0;
              }
         $sth->finish();
         $dbh->disconnect();
 #           my $filename = '/var/log/asterisk/test_report.txt';
 #       open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
 #       print $fh "The query is $query \n";
 #       close $fh;

       # my $customer_no = $mem_obj->{'callerid'};
        my $current_time = $mem_obj->{'current_time'};
        my $name = $mem_obj->{'name'};
        my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $out_no = $mem_obj->{'mobile_no'};
	my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "iifl-".$mem_obj->{callerid}."-".$mem_obj->{contact_1}."-".$mem_obj->{'did_mobile'};	
	$config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$year/$mon/$date/$filename,m");
	my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
#	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout");
	my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        $config->{_cti_obj}->exec("NoOp","===$call_status");
        if ($call_status eq "ANSWER") 
	{
	      my $tablename = 'media_extension_detail';
              my $value = 1;
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "update $tablename set status ='ANSWERED',agent_number = '$out_no' where mobile_no = '$customer_no' order by id desc limit 1";
              my $sth = $dbh->prepare($query);
              $sth->execute();
              if ($sth->rows()) {

                $value =  0;
		}
        	$sth->finish();
        	$dbh->disconnect();
	        return "exit";

        }
       $config->{_cti_obj}->exec("StopMonitor","");
       if ($call_status eq "BUSY") 
       {
	      #generating Random Number===
	      print "Content-type: text/html\n\n";
	      my @Chars = ('1'..'9');
	      my $Length = 4;
	      my $Number = '';
	      for (1..$Length) {
		$Number .= $Chars[int rand @Chars];
		}
	      print $Number;
	      my $tablename = 'media_extension_detail';
              my $value = 1;
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "update $tablename set status ='BUSY',customer_code = '$Number',agent_number = '$out_no' where mobile_no = '$customer_no' order by id desc limit 1";
              my $sth = $dbh->prepare($query);
              $sth->execute();
              if ($sth->rows()) {

                $value =  0;
                }
                $sth->finish();
                $dbh->disconnect();
	        return "exit";
       }
       if ($call_status eq "NOANSWER") 
       {
	      #generating Random Number===
	      print "Content-type: text/html\n\n";
	      my @Chars = ('1'..'9');
	      my $Length = 4;
	      my $Number = '';
	      for (1..$Length) {
		$Number .= $Chars[int rand @Chars];
		}
	      print $Number;
	      my $tablename = 'media_extension_detail';
              my $value = 1;
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "update $tablename set status ='NOANSWER',customer_code = '$Number',agent_number = '$out_no' where mobile_no = '$customer_no' order by id desc limit 1";
              my $sth = $dbh->prepare($query);
              $sth->execute();
              if ($sth->rows()) {

                $value =  0;
                }
                $sth->finish();
                $dbh->disconnect();
       		return "exit";
      }

     return 1;
}

sub __failure_case {

       my ($config,$default_values,$mem_obj) = @_;


       return "exit";

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
