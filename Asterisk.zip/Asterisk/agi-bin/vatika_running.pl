#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {

	my ($number_dialed) = @ARGV;
	my $AGI = new Asterisk::AGI;
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);

	my $default_values = {
		'timeout' => '4000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
                
	};
        my $mem_obj = {
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
		'number_dialed' => $number_dialed,
		'count' => '0',
		'dial_group' => "$value_hash{shadi}->{dial_group}",
		'dial_channel' => "$value_hash{shadi}->{dial_channel}",
		'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
		'callerid_out_1' => "$value_hash{shadi}->{escalate_number}",
                'callerid_out_2' => "$value_hash{shadi}->{escalate_number_2}",
                'callerid_out_3' => "$value_hash{shadi}->{escalate_number_3}",
		'dial_group_sec' => "$value_hash{shadi}->{dial_group_sec}"
	};
	
	my $tablename = 'click_to_call';
        my $value = 1;
        my $number = $mem_obj->{'number_dialed'};
	#===================Changes for 10 digit number====
	my $mobileno_length = length($mem_obj->{'number_dialed'});
        if ($mobileno_length > 10)
        {
                my $n = 2;
                $mem_obj->{'number_dialed'} = substr( "$mem_obj->{'number_dialed'}",$n);

        }
	#========================================================
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "update $tablename set status ='ANSWERED' where callerid = '$number' order by callerid_count desc limit 1";
        my $sth = $dbh->prepare($query);
        $sth->execute();
        if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();

	my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $timeout = $mem_obj->{'dial_timeout'};		
	my $function = "__welcome";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;
}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        my $tablename = 'vatika_maintainance';
        my $mobile_no;
        my $number;
	my $meter_no;
        my $campaign_name;
        #=====Converting 12 digit number to 10 digits===========
#	my $mobileno_length = length($mem_obj->{'callerid'});
#       if ($mobileno_length > 10)
#        {
#                my $n = 2;
#                $mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);

#        }
	#=======================================================
	my $contact_no = $mem_obj->{'number_dialed'};

        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select mobile_no,amount,meter_no,campaign_name from $tablename where mobile_no = '$contact_no'";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array()){
        $mobile_no          =      $row[0];
        $number             =      $row[1];
	$meter_no           =      $row[2];
	$campaign_name      =      $row[3];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
        $mem_obj->{'mobile_no'} 	= $mobile_no;
        $mem_obj->{'number'}    	= $number;
	$mem_obj->{'meter_no'}  	= $meter_no;
	$mem_obj->{'campaign_name'}	= $campaign_name;
	
	if(!$mobile_no)
	{
		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/Sorry");
		return "exit";
	}
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/Welcome_new");
#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/Welcome_cut");
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/rupees");
	
	if(length($number) == 8 || length($number) == 9) 
	{
		return("__croreprompt");
	} 
	if(length($number) == 6 || length($number) == 7)
	{
		return("__lakhprompt");

	}
	if(length($number) == 5 || length($number) == 4 ||length($number) == 3 || length($number) == 2 || length($number) == 1)
	{
		$config->{_cti_obj}->exec("SayNumber","$number");
		my $meter_no =$mem_obj->{'meter_no'};
		if($campaign_name == 1)
		{
    			$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no");
		}
		if($campaign_name == 2)
		{
    			$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no_jaipur");
		}
		if($campaign_name == 3)
		{
    			$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no_ambala");
		}
		$config->{_cti_obj}->exec("SayDigits","$meter_no");
	#	return("__connectcall_in_queue");
		return("__connectcall");
	}
	
	
}

sub __croreprompt
{
		my ($config,$default_values,$mem_obj) = @_;
		my $number = $mem_obj->{'number'};
		my $meter_no =$mem_obj->{'meter_no'};
		my $campaign_name =$mem_obj->{'campaign_name'};
	        if(length($number) == 8)
		{
				
			$digit = substr($number, 0, 1);
			$number = substr($number,1);
			$config->{_cti_obj}->exec("Playback","en/digits/$digit");
			$config->{_cti_obj}->exec("Playback","en/digits/crore");
			if(length($number) == 6 || length($number) == 7)
			{
				if(length($number) == 6) 
				{
        				$digit_1 = substr($number, 0, 1);
        				$number = substr($number,1);
					$config->{_cti_obj}->exec("Playback","en/digits/$digit_1");
                        		$config->{_cti_obj}->exec("Playback","en/digits/lakhs");

        			} 
				else 
				{
        					$digit_1 = substr($number, 0, 2);
        					$number = substr($number,2);
						if($digit_1 >= 20 && $digit_1 < 30)
						{
							$dig2 = substr($digit_1,1);
							$config->{_cti_obj}->exec("Playback","en/digits/20");
							$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
							$config->{_cti_obj}->exec("Playback","en/digits/lakhs");
							$config->{_cti_obj}->exec("SayNumber","$number");

        					}
						if($digit_1 >= 30 && $digit_1 < 40)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/30");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 40 && $digit_1 < 50)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/40");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 50 && $digit_1 < 60)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/50");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 60 && $digit_1 < 70)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/60");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 70 && $digit_1 < 80)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/70");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 80 && $digit_1 < 90)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/80");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 90 && $digit_1 < 100)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/90");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }

				}

			}
		}
		else 
		{
         	
         		$digit = substr($number, 0, 2);
			$dig2 = substr($digit,1);
         		$number = substr($number,2);
			
			if($digit >= 10 && $digit < 20)
			{
				$config->{_cti_obj}->exec("Playback","en/digits/10");
			}
			if($digit >= 20 && $digit < 30)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/20");
                        }
			if($digit >= 30 && $digit < 40)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/30");
                        }
			if($digit >= 40 && $digit < 50)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/40");
                        }
			if($digit >= 50 && $digit < 60)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/50");
                        }
			 if($digit >= 60 && $digit < 70)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/60");
                        }
			 if($digit >= 70 && $digit < 80)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/70");
                        }
			if($digit >= 80 && $digit < 90)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/80");
                        }
			if($digit >= 90 && $digit < 100)
                        {
                                $config->{_cti_obj}->exec("Playback","en/digits/90");
                        }
			$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
			$config->{_cti_obj}->exec("Playback","en/digits/crore");
			if(length($number) == 6 || length($number) == 7)
			{
				if(length($number) == 6) 
				{
        				$digit_1 = substr($number, 0, 1);
        				$number = substr($number,1);
					$config->{_cti_obj}->exec("Playback","en/digits/$digit_1");
                        		$config->{_cti_obj}->exec("Playback","en/digits/lakhs");

        			} 
				else 
				{
        					$digit_1 = substr($number, 0, 2);
        					$number = substr($number,2);
						if($digit_1 >= 10 && $digit_1 < 20)
                                                {
                                                       # $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$digit_1");
                                                        #$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 20 && $digit_1 < 30)
						{
							$dig2 = substr($digit_1,1);
							$config->{_cti_obj}->exec("Playback","en/digits/20");
							$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
							$config->{_cti_obj}->exec("Playback","en/digits/lakhs");
							$config->{_cti_obj}->exec("SayNumber","$number");

        					}
						if($digit_1 >= 30 && $digit_1 < 40)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/30");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 40 && $digit_1 < 50)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/40");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 50 && $digit_1 < 60)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/50");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 60 && $digit_1 < 70)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/60");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 70 && $digit_1 < 80)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/70");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						 if($digit_1 >= 80 && $digit_1 < 90)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/80");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }
						if($digit_1 >= 90 && $digit_1 < 100)
                                                {
                                                        $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/90");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }

				}

			}
		}
#$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no");
	if($campaign_name == 1)
	{
    		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no");
	}
	if($campaign_name == 2)
	{
    		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no_jaipur");
	}
	if($campaign_name == 3)
	{
    		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no_ambala");
	}
$config->{_cti_obj}->exec("SayDigits","$meter_no");
# return("__connectcall_in_queue");
return("__connectcall");
}

sub __lakhprompt
{
		my ($config,$default_values,$mem_obj) = @_;
                my $number = $mem_obj->{'number'};
		my $meter_no =$mem_obj->{'meter_no'};
		my $campaign_name =$mem_obj->{'campaign_name'};
		
		if(length($number) == 6) 

		{
					 


        				$digit_1 = substr($number, 0, 1);

        				$number = substr($number,1);

					$config->{_cti_obj}->exec("Playback","en/digits/$digit_1");

                        		$config->{_cti_obj}->exec("Playback","en/digits/lakhs");

					$config->{_cti_obj}->exec("SayNumber","$number");



        	} 

		else 

		{
					$digit_1 = substr($number, 0, 2);
					$number = substr($number,2);
					

					 if($digit_1 >= 10 && $digit_1 < 20)
                                                {
                                                       # $dig2 = substr($digit_1,1);
                                                        $config->{_cti_obj}->exec("Playback","en/digits/$digit_1");
                                                        #$config->{_cti_obj}->exec("Playback","en/digits/$dig2");
                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");
                                                        $config->{_cti_obj}->exec("SayNumber","$number");

                                                }

					if($digit_1 >= 20 && $digit_1 < 30)

						{

							$dig2 = substr($digit_1,1);

							$config->{_cti_obj}->exec("Playback","en/digits/20");

							$config->{_cti_obj}->exec("Playback","en/digits/$dig2");

							$config->{_cti_obj}->exec("Playback","en/digits/lakhs");

							$config->{_cti_obj}->exec("SayNumber","$number");



        					}

						if($digit_1 >= 30 && $digit_1 < 40)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/30");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						 if($digit_1 >= 40 && $digit_1 < 50)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/40");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						 if($digit_1 >= 50 && $digit_1 < 60)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/50");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						if($digit_1 >= 60 && $digit_1 < 70)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/60");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						 if($digit_1 >= 70 && $digit_1 < 80)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/70");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						 if($digit_1 >= 80 && $digit_1 < 90)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/80");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }

						if($digit_1 >= 90 && $digit_1 < 100)

                                                {

                                                        $dig2 = substr($digit_1,1);

                                                        $config->{_cti_obj}->exec("Playback","en/digits/90");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/$dig2");

                                                        $config->{_cti_obj}->exec("Playback","en/digits/lakhs");

                                                        $config->{_cti_obj}->exec("SayNumber","$number");



                                                }



        					

		}
        my $filename = '/var/log/asterisk/report_vatika.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for campaignid = $campaign_name\n";
                close $fh;
		
#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no_jaipur");
	if($campaign_name == 1)
	{
    		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no");
	}
	if($campaign_name == 2)
	{
    		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no_jaipur");
	}
	if($campaign_name == 3)
	{
    		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/meter_no_ambala");
	}

        $config->{_cti_obj}->exec("SayDigits","$meter_no");
#	return("__connectcall_in_queue");
	return("__connectcall");

}

sub __connectcall_in_queue
{
        my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/calling_no");
	my $bg_sound_file = "ivr/ThinkWalnut/vatika/Transfer_call";
	my $max_allowed_digit = "1";
	 my $hash_table_ref = {

                '1' => '1'

                
        };
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	 if($dtmf == 1)
	 {
        	$config->{_cti_obj}->exec("Set","CHANNEL(musicclass)=support");
        	$config->{_cti_obj}->exec("Queue","support,,,,60");
	 }
        return "exit";

}

#=====================
sub __connectcall
{
        my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/calling_no");
#	my $bg_sound_file = "ivr/ThinkWalnut/vatika/Transfer_call";
	my $bg_sound_file = "ivr/ThinkWalnut/vatika/Transfer_call_Final";
        my $max_allowed_digit = "1";
         my $hash_table_ref = {

                '1' => '1',
		'2' => '2'


        };
        my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
          if($dtmf < 0)
	  {
		$dtmf = 0;
	  }
	#==================DB OPERATION=======================================
	my $tablename = 'click_to_call';
	my $value = 1;
        my $number = $mem_obj->{'number_dialed'};
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "update click_to_call set key_pressed = $dtmf where callerid = '$number' order by callerid_count desc limit 1 ";
	my $sth = $dbh->prepare($query);
	$sth->execute();
	if($sth->rows()){
		$value =0;
	}
	$sth->finish();
	$dbh->disconnect();
	#=====================================================================
        if($dtmf == 1)
	{
        	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/Thank_You");
        	my $dial_group = $mem_obj->{'dial_group'};
       		my $dial_channel = $mem_obj->{'dial_channel'};
        	my $out_no = $mem_obj->{'callerid_out_1'};
        	my $timeout = $mem_obj->{'dial_timeout'};
        	my $filename = "gss-".$mem_obj->{callerid}."-".$mem_obj->{session_id};
        	$config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$current_date/$filename,m");
        	my $out_no = $mem_obj->{'callerid_out_1'};
        	my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
        	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
        	my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        	if ($call_status eq "ANSWER")
        	{

              		return "exit";
		}
       		if ($call_status eq "BUSY")
       		{
			$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
                	return "exit";
       		}
       		if ($call_status eq "NOANSWER")
       		{

                	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/shadi_Final/eng/not_rechable");
	     	#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/TulsiVihar/Sorry");
                	return "exit";
      		}
      }
      if($dtmf == 2)
      {
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/vatika/Thank_You");
      }


}

#=======================
main();
exit;
