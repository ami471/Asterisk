#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($number_dialed) = @ARGV;
        my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
        my (%output) = $AGI->ReadParse();
        my $config = {
                '_cti_obj' => $AGI,
                '_db' => 1
        };
        my %value_hash;
        my $default_values = {
                'timeout' => '3000',
                'timeout_count' => '2',
                'timeout_file' => undef,
                'timeout_max' => undef,
                'invalid_count' => '2',
                'invalid_file' => undef,
                'invalid_max' => undef
        };
        my $mem_obj = {
                'session_id' => $output{'uniqueid'},
                'number_dialed' => $number_dialed,
                'mobile_no' => '',
                'count' => '0'
        };
        my $tablename = 'housie_call';
        my $value = 1;
        my $number = $mem_obj->{'number_dialed'};
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        my $uniqueid = sprintf("%02d%02d%02d%02d",$date,$hour,$min,$sec);    
        $mem_obj->{'$uniqueid'} = $uniqueid; 
        __logFile("In Main Function", $number,$uniqueid);
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "update $tablename set status ='ANSWERED' where callerid = '$number'";
        my $sth = $dbh->prepare($query);
        $sth->execute();
        if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();
	my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
            		
			$loop = 0;
	    }
	    $function = $next_action;

	} while ($loop);
        return -1;
}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        my $number = $mem_obj->{'number_dialed'};
        my $uniqueid =   $mem_obj->{'$uniqueid'};
        __logFile("In Welcome section", $number, $uniqueid);
	my $tablename = 'housie_call';
   	my $interaction_id;
        my $registration;
   	my $contactno = $mem_obj->{'number_dialed'};
   	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
   	my $query = "select interaction_id,registration from $tablename where callerid = '$contactno' order by callerid_count desc limit 1";
   	my $sth = $dbh->prepare($query) ;
   	my $ret =$sth->execute();
   	while(my @row = $sth->fetchrow_array())
   	{
        	$interaction_id  =      $row[0];
		$registration    =      $row[1];
   	}
   	$sth->finish();  #24/08/16
   	$dbh->disconnect();
   	$mem_obj->{'interaction_id'} = $interaction_id;
        $mem_obj->{'registration'}   = $registration;
        my $lang = "ivr/ThinkWalnut/infant";
        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
       #==========================================================
       
        my $registration = $mem_obj->{'registration'};
        if($registration == 2)
	{
		my $bg_sound_file_dtmf = "Lifebuoy_dtmf";
		my $max_allowed_digit = "1";
        	my $hash_table_ref = {
                '1' => '1'
                };
		 my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file_dtmf,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
        	if (exists $hash_table_ref->{$dtmf}) {

              		$mem_obj->{'menu_option'} = $dtmf
        	}
                
                #========================******For pushing the response****** =============================
        	$url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid=  $mem_obj->{'interaction_id'}&keypress= $dtmf&section = 'Reg_2'&asterisk_id=  $mem_obj->{'session_id'}";
        	$request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	$ua = LWP::UserAgent->new();
         	$response = $ua->request($request);
        	#====================================================================================
        	__logFile("The URL with registration input is $url", $number, $uniqueid);
	}
	else
	{
		 $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/registration_muft");
		
	}
	
       #============================================================
        my $bg_sound_file = "selection";
       #========================******For pushing the response****** =============================
  my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid=  $mem_obj->{'interaction_id'}&keypress= 0&asterisk_id=  $mem_obj->{'session_id'}";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
        #====================================================================================
        __logFile("The URL processed is $url", $number, $uniqueid);
#        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/registration_muft");
        __logFile("The prompt played is registration_muft", $number, $uniqueid);
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
		'1' => '1',
	        '2' => '2' 
	};
    	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf
	}
#        my $number = $mem_obj->{'number_dialed'};
        if($dtmf == 1)
	{
		#========================******For pushing the response****** =============================
              my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'interaction_id'}&keypress= '1~$dtmf'&section = 'P'&asterisk_id=  $mem_obj->{'session_id'}";
              my $request = new HTTP::Request(POST => $url  );
              $request->content_type('application/x-www-form-urlencoded');
              my $ua = LWP::UserAgent->new();
              my $response = $ua->request($request);
            	#====================================================================================
		 __logFile("In pregnant section the URL with dtmf input is $url", $number, $uniqueid);

		 if( $mem_obj->{'registration'} == 1)
                {
                        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/Thank_You_Rs_10_2_Month_Schedule_converted");
                         $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/sign_off_2");
                }
                else
                {
                        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/Thank_You_2_Month");
                        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/sign_off_2");

                }
		return ("exit");

	}
	if($dtmf == 2)
	{
		#========================******For pushing the response****** =============================
              my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'interaction_id'}&keypress= '2~$dtmf'&section = 'C'&asterisk_id=  $mem_obj->{'session_id'}";
              my $request = new HTTP::Request(POST => $url  );
              $request->content_type('application/x-www-form-urlencoded');
              my $ua = LWP::UserAgent->new();
              my $response = $ua->request($request);
            #====================================================================================
	      __logFile("In child section the URL with dtmf input is $url", $number, $uniqueid);

	       if( $mem_obj->{'registration'} == 1)
               {
                   $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/Thank_You_Rs_10_Month_Schedule_converted");
                    $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/sign_off_1");
               }
               else
               {
                        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/Thank_You_1_Month");
                         $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/sign_off_1");
               }
	      return ("exit");
	}
	
	
}
sub __logFile
{      
	my($text,$number,$uniqueid) = @_;
	my $num = $number;
        my $folder;
	my $unique = $uniqueid; 
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        $year +=1900;
        $mon  +=1;
	my $current_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
#====================================================================
        $folder=  sprintf("%02d%02d%03d",$date,$mon,$year);
        my $current_date = sprintf("%02d",$date);
        my $dirname = "/var/log/asterisk/lifebouy/$folder";
        if(-e $dirname)
        {
              #print("DIRECTORY EXIST");
        }
       	else
        {
               
              mkdir $dirname;
        }

        
	
#=====================================================================
        my $file_time = sprintf("%02d%02d%02d%02d%02d%03d",$hour,$min,$sec,$date,$mon,$year);
        my $filename = "twdlog-".$num."-".$unique."-".$file_time;
        my $file = "/var/log/asterisk/lifebouy/$folder/$filename.log";
        open(FILE,'>>',$file) or die "Could not open file";
	say FILE "$current_time:$text";
	close FILE;
}
main();
exit;
