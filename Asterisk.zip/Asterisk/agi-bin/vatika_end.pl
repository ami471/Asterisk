#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;


sub __update_endtime{

	my ($config,$default_values,$mem_obj) = @_;
	my $tablename = 'click_to_call';
        my $value = 1;
        my $number_dialled = $mem_obj->{'number_dialled'};
      
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count =0;

        my $query = "update click_to_call set end_time = NOW() where callerid = $number_dialled  order by callerid_count desc limit 1;";

	my $sth = $dbh->prepare($query) ;

	my $ret =$sth->execute();

        $dbh->disconnect();
        #==================For API Response==============
        my $tablename = 'click_to_call';
        my $value = 1;
        my $name ;
	my $time_diff;
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "SELECT TIME_TO_SEC(TIMEDIFF(end_time,start_time)) from click_to_call where callerid = $number_dialled order by callerid_count desc limit 1";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
                $time_diff               = $row[0];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
	#=============FOR VATIKA MAINTAINANCE TABLE==========================
	my $tablename = 'vatika_maintainance';
        my $name;
        my $mobile_no;
        my $number;
        my $meter_no;
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select name,mobile_no,amount,meter_no from $tablename where mobile_no = '$number_dialled'";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array()){
	$name               =      $row[0];
        $mobile_no          =      $row[1];
        $number             =      $row[2];
        $meter_no           =      $row[3];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
	$mem_obj->{'name'}      = $name;
        $mem_obj->{'mobile_no'} = $mobile_no;
        $mem_obj->{'number'}    = $number;
        $mem_obj->{'meter_no'}  = $meter_no;


       #============SEND RESPONSE====================
         if($time_diff < 15)
	 {
         	my $url ="http://172.20.120.105/13/api/vatika_sms_push.php?mdn=$mobile_no&name=$name&amount=$number&meter=$meter_no&type=4";
         	my $request = new HTTP::Request(POST => $url);
         	$request->content_type('application/x-www-form-urlencoded');
         	my $ua = LWP::UserAgent->new();
         	my $response = $ua->request($request);
         	my $filename = '/var/log/asterisk/report_crayfish.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url \n";
                close $fh;
	}	
	#================================================
        return "exit";
     
}




sub main {

	my ($number_dialled) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialled");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'number_dialled' => $number_dialled
	};
		
	my $function = "__update_endtime";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
