#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;


sub __update_status{

	my ($config,$default_values,$mem_obj) = @_;
        my $mobileno_length = length($mem_obj->{'callerid'});
	if ($mobileno_length > 10)
	{
		my $n = 2;
        	$mem_obj->{'callerid'} = substr( "$mem_obj->{'callerid'}",$n);  
        	
	}
	my $customer_no = $mem_obj->{'callerid'};
        my $dial_status = $mem_obj->{'dialed_status'};
        my $name;
        my $iifl_agent;
	my $location;        
        my $date;            
        my $time;            
        my $day;             
        my $Time_Session;   
        my $zone;             
        my $pincode;         
        my $campaign;        
        my $weekday;          
        my $media_channel;    
        my $media_vehicle;    
        my $status;          
        my $languagekey; 
        my $type;
        my $did;
        my $branch_code;
	my $call_start_time;
	my $call_agent_start_time;
	my $call_agent_end_time;
        my $pincode_enterd = 0;     
        my $pincode_present = 0;
        my $used_count = 0;
        my $max_count = 0;
        my $pincode_count = 0;
        my $pincode = 0;
        my $dial_status_zoho;
        my $customer_code;
        my $agent_number;
	if($dial_status eq "ANSWERED" )
	{
		$dial_status = 'ANSWERED';
	}
        if($dial_status eq "CHANUNAVAIL")
	{
		$dial_status = "BUSY";
	}	
        if($dial_status eq "ANSWER" || $dial_status eq "NOANSWER" || $dial_status eq "BUSY")
	{
	      print "Content-type: text/html\n\n";
	      my @Chars = ('1'..'9');
	      my $Length = 4;
	      my $Number = '';
	      for (1..$Length) {
		$Number .= $Chars[int rand @Chars];
		}
	      print $Number;
		if($dial_status eq "ANSWER")
		{
		    $dial_status = 'ANSWERED';
		    $dial_status_zoho = 'BR-Call Connected';
		}
                if($dial_status eq "NOANSWER")
                {
                    $dial_status_zoho = 'BR-Not rechable';
                }
                if($dial_status eq "BUSY")
                {
                    $dial_status_zoho = 'BR-Not Rechable';
                }

		my $tablename = 'digitalmedia_customer_detail';
        	my $value = 1;
        	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        	my $query = "update $tablename set status = '$dial_status' where mobile_no = '$customer_no' order by id desc limit 1";
        	my $sth = $dbh->prepare($query);
        	$sth->execute();
        	if ($sth->rows()) 
		{
			$value =  0;
        	}		
        	$sth->finish();
    		$dbh->disconnect();
	}

	my $value = 1;
  	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select name,contact_1 from iifl_pincode where pincode = (select pincode from digitalmedia_customer_detail where mobile_no = $customer_no order by id desc limit 1)";
        my $sth = $dbh->prepare($query) ;
        my  $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
              $name             =      $row[0];
	      $iifl_agent       =      $row[1];

        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();

        
        

       # ========================================================================
	my $value = 1;
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "select location,date,time,day,Time_Session,zone,pincode,campaign,weekday,media_channel,media_vehicle,status,state,did,branch_code,customer_code from  digitalmedia_customer_detail where mobile_no = $customer_no order by id desc limit 1";
	my $sth = $dbh->prepare($query) ;
        my  $ret =$sth->execute();
	while(my @row = $sth->fetchrow_array())
        {
              $location         =      $row[0];
              $date             =      $row[1];
	      $time             =      $row[2];
	      $day              =      $row[3];
              $Time_Session     =      $row[4];
              $zone             =      $row[5];
	      $pincode          =      $row[6];
              $campaign         =      $row[7];
              $weekday          =      $row[8];
	      $media_channel    =      $row[9];
              $media_vehicle    =      $row[10];
              $status           =      $row[11];
	      $state            =      $row[12];
	      $did              =      $row[13];
              $branch_code      =      $row[14];
              $customer_code    =      $row[15];
              $agent_number     =      $row[16];
	     
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
	$type = 1;
       

 



	#========================================================================       
	if ($dial_status eq "ANSWER" or $dial_status eq "ANSWERED") 
	{
       #=================IIFL Customer====
	my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_digital_ivr_pushmsg.php?type=8&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$name&spokenTo= $iifl_agent &customer_code=$customer_code";
                my $res = $ua->request($req);
	#============IIFL Agent==========================
	my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_digital_ivr_pushmsg.php?type=10&callerNo=$mem_obj->{'callerid'}&toSend=$iifl_agent&name=$name&spokenTo=$mem_obj->{'callerid'}&customer_code=$customer_code";
                my $res = $ua->request($req);
       }
      
       if($dial_status eq "NOANSWER" or $dial_status eq "BUSY")
       {   
		       
		my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
          	$year +=1900;
        	$mon  +=1;
        	my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
        	my $call_agent_end_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);

       		my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_digital_ivr_pushmsg.php?type=1&time=$call_agent_end_time&callerNo=$mem_obj->{'callerid'}&toSend=$iifl_agent&name=$name&spokenTo=$mem_obj->{'callerid'}&customer_code=$customer_code";
                my $res = $ua->request($req);

               my $filename = '/var/log/asterisk/digitmedia_notconnect.txt';
               open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
               print $fh "Response for Agent is http://rubicsolution.in/IIFL/api/iifl_digital_ivr_pushmsg.php?type=1&time=$call_agent_end_time&callerNo=$mem_obj->{'callerid'}&toSend=$iifl_agent&name=$name&spokenTo=$mem_obj->{'callerid'}&customer_code=$customer_code\n";

		my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_digital_ivr_pushmsg.php?type=7&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$name&spokenTo=$iifl_agent&customer_code=$customer_code";
                my $res = $ua->request($req);
                 my $filename = '/var/log/asterisk/digitmedia_notconnect.txt';
        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
        print $fh "Response for Customer is http://rubicsolution.in/IIFL/api/iifl_digital_ivr_pushmsg.php?type=7&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$name&spokenTo=$iifl_agent&customer_code=$customer_code\n";

                
  


       }       
       

	

	 my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
	  $year +=1900;
        $mon  +=1;
        my $current_date = sprintf("%04d-%02d-%02d",$year,$mon,$date);
        my $call_agent_end_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);

	 my $tablename = 'digitalmedia_customer_detail';
         my $value = 1;
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
         my $query = "update $tablename set call_agent_end_time ='$call_agent_end_time' where mobile_no = '$customer_no' order by id desc limit 1";
         my $sth = $dbh->prepare($query);
         $sth->execute();
         if ($sth->rows())
         {
             $value =  0;
         }
         $sth->finish();
         $dbh->disconnect();
     

        my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
        my $req = GET "http://www.rubicsolution.in/IIFL/api/iiflDigitalCustomerDetails.php?mobile_no=$customer_no&location=$location&date=$current_date&time=$time&day=$day&Time_Session=$Time_Session&zone=$zone&pincode=$pincode&campaign=$campaign&weekday=$weekday&media_channel=$media_channel&media_vehicle=$media_vehicle&status=$status&type=$type&state=$state&did=$did&endTimestamp= $call_agent_end_time";
        my $res = $ua->request($req);
      
        my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );

	my $req = GET "https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=$media_channel&ivr_nbr=$did&Mobile=$customer_no&call_time=$current_date&circle=$location&BranchCode=$branch_code";
        my $res = $ua->request($req);
         my $filename = '/var/log/asterisk/digital_media_zoho.txt';
          open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
             print $fh "Response is sucessful for https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=$media_channel&ivr_nbr=$did&Mobile=$customer_no&call_time=$current_date&circle=$location&BranchCode=$branch_code \n";
             close $fh;
  

        if ($res->is_success) {
             print $res->content;
             my $filename = '/var/log/asterisk/digital_media_zoho.txt';
             open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
             print $fh "Response is sucessful for https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=$media_channel&ivr_nbr=$did&Mobile=$customer_no&call_time=$current_date&circle=$location&BranchCode=$branch_code \n";
             close $fh;
        }else{
                        print $res->status_line . "\n";
                        my $filename = '/var/log/asterisk/digital_media_zoho.txt';
                        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                        print $fh "Response is not sucessful for https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=$media_channel&ivr_nbr=$did&Mobile=$customer_no&call_time=$current_date&circle=$location&BranchCode=$branch_code \n";
                close $fh;

                        }

        return "exit";
     
}




sub main {

	my (${CID},${DIALSTATUS}) = @ARGV;
	my $AGI = new Asterisk::AGI;
        my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'callerid' => ${CID},
		'dialed_status' => ${DIALSTATUS}
	};
		
	my $function = "__update_status";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
