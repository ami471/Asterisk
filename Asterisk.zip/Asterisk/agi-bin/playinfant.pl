#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($number_dialed) = @ARGV;
        my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
        my (%output) = $AGI->ReadParse();
        my $config = {
                '_cti_obj' => $AGI,
                '_db' => 1
        };
        my %value_hash;
        my $default_values = {
                'timeout' => '3000',
                'timeout_count' => '2',
                'timeout_file' => undef,
                'timeout_max' => undef,
                'invalid_count' => '2',
                'invalid_file' => undef,
                'invalid_max' => undef
        };
        my $mem_obj = {
                'session_id' => $output{'uniqueid'},
                'did' => $did,
                'number_dialed' => $number_dialed,
                'count' => '0'
        };
         my $tablename = 'campaign_hul';
         my $value = 1;
         my $number = $mem_obj->{'number_dialed'};
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
         my $query = "update $tablename set status = 1 where mobno = '$number'";
         my $sth = $dbh->prepare($query);
         $sth->execute();
         if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();

	my $function = "__promptplay";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
            		
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
        
       return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __promptplay
{
	my ($config,$default_values,$mem_obj) = @_;
        my $lang = "ivr/ThinkWalnut/infant";
        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
        my $bg_sound_file ;
        my $tablename = 'campaign_hul';
        my $value = 1;
        my $function;
	my $dialled_number = $mem_obj->{'number_dialed'};
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "select file_name from $tablename where mobno = '$dialled_number' ";
	my $sth = $dbh->prepare($query);
	$sth->execute();
	while(my @row = $sth->fetchrow_array()){

    	    $bg_sound_file = $row[0];

         }

        $sth->finish();

        $dbh->disconnect();
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/$bg_sound_file");
	
}

main();
exit;
