#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($number_dialed) = @ARGV;
        my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
        my (%output) = $AGI->ReadParse();
        my $config = {
                '_cti_obj' => $AGI,
                '_db' => 1
        };
        my %value_hash;
        my $default_values = {
                'timeout' => '3000',
                'timeout_count' => '2',
                'timeout_file' => undef,
                'timeout_max' => undef,
                'invalid_count' => '1',
                'invalid_file' => undef,
                'invalid_max' => undef
        };
        my $mem_obj = {
                'session_id' => $output{'uniqueid'},
                'did' => $did,
                'number_dialed' => $number_dialed,
                'count' => '0'
        };
         my $tablename = 'lifebuoy_call';
         my $value = 1;
         my $number = $mem_obj->{'number_dialed'};
  #       __logFile("In Main mobile number", $number);
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","amit1234");
         my $query = "update $tablename set status ='ANSWERED' where callerid = '$number'";
         my $sth = $dbh->prepare($query);
         $sth->execute();
         if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();

	my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
          		$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
        
       return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        my $tablename = 'lifebuoy_call';
        my $callerid;
        my $prompt_id;
        my $unique_id;
        my $contactno = $mem_obj->{'number_dialed'};
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","amit1234");
        my $query = "select callerid,prompt_id,unique_id from $tablename where callerid = '$contactno' ";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array()){
        $callerid         =      $row[0];
        $prompt_id        =      $row[1];
        $unique_id         =      $row[2];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
        $mem_obj->{'prompt_id'} = $prompt_id;
        $mem_obj->{'unique_id'} = $unique_id;
        if ($prompt_id eq "NM_1")
        {               
		my $AGI = new Asterisk::AGI;	
                  
                 $duration = $AGI->get_variable('CDR(duration)');
                 my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)'); 
                 $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
                 $request = new HTTP::Request(POST => $url  );
                 $request->content_type('application/x-www-form-urlencoded');
                 $ua = LWP::UserAgent->new();
                 $response = $ua->request($request);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_1");

	}
	
	if ($prompt_id eq "NM_2")
        {
		#========================******For pushing the response****** =============================
         	my $AGI = new Asterisk::AGI;
         	my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
        	my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
        	my $request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	my $ua = LWP::UserAgent->new();
        	my $response = $ua->request($request);
        	#====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_2");
        }
	if ($prompt_id eq "NM_3")
	{
		#========================******For pushing the response****** =============================
         	my $AGI = new Asterisk::AGI;
         	my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
        	my $request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	my $ua = LWP::UserAgent->new();
        	my $response = $ua->request($request);
        	#====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_3");
        }
	if ($prompt_id eq "NM_4")
        {
		#========================******For pushing the response****** =============================
         	my $AGI = new Asterisk::AGI;
         	my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

        	my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
        	my $request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	my $ua = LWP::UserAgent->new();
        	my $response = $ua->request($request);
        	#====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_4");
        }
	if ($prompt_id eq "NM_5")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
		my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_5");
        }
	if ($prompt_id eq "NM_6")
        {
         	#========================******For pushing the response****** =============================
         	my $AGI = new Asterisk::AGI;
         	my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
        	my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
        	my $request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	my $ua = LWP::UserAgent->new();
        	my $response = $ua->request($request);
        	#====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_6");
                
        }
	if ($prompt_id eq "NM_7")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_7");
        }
	if ($prompt_id eq "NM_8")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
		my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_8");
        }
	if ($prompt_id eq "NM_9")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_9");
        }
	if ($prompt_id eq "NM_10")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_10");
        }
	if ($prompt_id eq "NM_11")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
		my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_11");
        }
	if ($prompt_id eq "NM_12")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
		my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_12");
        }
	if ($prompt_id eq "NM_13")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_13");
        }
	if ($prompt_id eq "NM_14")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_14");
        }
	if ($prompt_id eq "NM_15")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_15");
        }
	if ($prompt_id eq "NM_16")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_16");
        }
	if ($prompt_id eq "GM_1")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_1");
        }
	 if ($prompt_id eq "GM_2")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_2");
        }
	 if ($prompt_id eq "GM_3")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_3");
        }
	 if ($prompt_id eq "GM_4")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_4");
        }
	 if ($prompt_id eq "GM_5")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_5");
        }
	 if ($prompt_id eq "GM_6")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_6");
        }
	 if ($prompt_id eq "GM_7")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_7");
        }
	 if ($prompt_id eq "GM_8")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_8");
        }
	 if ($prompt_id eq "GM_9")
        {
		 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_9");
        }
	
	if ($prompt_id eq "RM_A")
        {
                 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_A");
        }
	
	if ($prompt_id eq "RM_B")
        {
                 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                 my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_B");
        }
	
	  if ($prompt_id eq "RM_C")
        {
                 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_C");
        }
	
	  if ($prompt_id eq "RM_D")
        {
                 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_D");
        }
	
	  if ($prompt_id eq "RM_E")
        {
                 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
		my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_E");
        }
	
	if ($prompt_id eq "RM_F")
        {
                 #========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
	        my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $asterisk_uniqueid";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================

               # $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_F");
                my $bg_sound_file = "ivr/ThinkWalnut/lifebuoy/RM_F";
                my $max_allowed_digit = "1";
            #    my $hash_table_ref = {

	#			'1' => 'ok'

	#	};
		my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	
		
		#========================******For pushing the response****** =============================
                my $AGI = new Asterisk::AGI;
                my $duration = $AGI->get_variable('CDR(duration)');
                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&duration= $duration&key_press=$dtmf";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
		

                
		
                
      }

	 
}

main();
exit;
