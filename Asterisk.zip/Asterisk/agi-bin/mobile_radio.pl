#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;

sub main {
	my ($number_dialed) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
	my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '1',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '3',
		'invalid_file' => undef,
		'invalid_max' => undef
	};
	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'did' => $did,
		'number_dialed' => $number_dialed,
                'count' => '0'
	};
         my $tablename = 'missed_calling';
	 my $value = 1;
	 my $number = $mem_obj->{'number_dialed'};
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
         my $query = "update $tablename set status ='ANSWERED' where mobno = '$number'";
	 my $sth = $dbh->prepare($query);
	 $sth->execute();
         if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();
	my $function = "__mobile_radio_welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __mobile_radio_welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/Veer_Zara/Welcome");
        return ("__song_1");
}

sub __song_1
{
	my ($config,$default_values,$mem_obj) = @_;
	my $count = 5000;
        my $rewind = 4;
        my $forward = 6;
        my $stop   = 8;
        my $pause  = 5;
        my $start  =2;
        my $bg_sound_file = "ivr/ThinkWalnut/Veer_Zara/Aisa-Des-Hai-Mera_SongsMp3";
        $config->{_cti_obj}->exec("ControlPlayback","$bg_sound_file,$count,$forward,$rewind,$stop,$pause,$start");
	my $call_status = $config->{_cti_obj}->get_variable("CPLAYBACKSTATUS");
        if ($call_status eq "USERSTOPPED") 
	{

		return ("__song_2");

	}
               
}

sub __song_2
{
	my ($config,$default_values,$mem_obj) = @_;
	my $count = 5000;
        my $rewind = 4;
        my $forward = 6;
        my $stop   = 8;
        my $pause  = 5;
        my $start  =2;
        my $bg_sound_file = "ivr/ThinkWalnut/Veer_Zara/Jaanam-Dekh-Lo-Milt-Gayi_SongsMp3";
	$config->{_cti_obj}->exec("ControlPlayback","$bg_sound_file,$count,$forward,$rewind,$stop,$pause,$start");
        my $call_status = $config->{_cti_obj}->get_variable("CPLAYBACKSTATUS");
        if ($call_status eq "USERSTOPPED")
        {

                return ("__song_3");

        }

}

sub __song_3
{
        my ($config,$default_values,$mem_obj) = @_;
        my $count = 5000;
        my $rewind = 4;
        my $forward = 6;
        my $stop   = 8;
        my $pause  = 5;
        my $start  =2;
        my $bg_sound_file = "ivr/ThinkWalnut/Veer_Zara/Ye-Hum-Aa-Gaye-Hain-Kahan_SongsMp3";
        $config->{_cti_obj}->exec("ControlPlayback","$bg_sound_file,$count,$forward,$rewind,$stop,$pause,$start");
        my $call_status = $config->{_cti_obj}->get_variable("CPLAYBACKSTATUS");
        if ($call_status eq "USERSTOPPED")
        {

                return ("__song_4");
	}
}

sub __song_4
{
        my ($config,$default_values,$mem_obj) = @_;
        my $count = 5000;
        my $rewind = 4;
        my $forward = 6;
        my $stop   = 8;
        my $pause  = 5;
        my $start  =2;
        my $bg_sound_file = "ivr/ThinkWalnut/Veer_Zara/O_Mere_Dil_Ke_Chain_IndiaMp3";
        $config->{_cti_obj}->exec("ControlPlayback","$bg_sound_file,$count,$forward,$rewind,$stop,$pause,$start");
        my $call_status = $config->{_cti_obj}->get_variable("CPLAYBACKSTATUS");
        if ($call_status eq "USERSTOPPED")
        {

                return ("exit");
        }
}

main();
exit;
