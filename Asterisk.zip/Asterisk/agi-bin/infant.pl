#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($number_dialed) = @ARGV;
        my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
        my (%output) = $AGI->ReadParse();
        my $config = {
                '_cti_obj' => $AGI,
                '_db' => 1
        };
        my %value_hash;
        my $default_values = {
                'timeout' => '3000',
                'timeout_count' => '2',
                'timeout_file' => undef,
                'timeout_max' => undef,
                'invalid_count' => '2',
                'invalid_file' => undef,
                'invalid_max' => undef
        };
        my $mem_obj = {
                'session_id' => $output{'uniqueid'},
                'did' => $did,
                'number_dialed' => $number_dialed,
                'count' => '0'
        };
         my $tablename = 'missed_calling';
         my $value = 1;
         my $number = $mem_obj->{'number_dialed'};
  #       __logFile("In Main mobile number", $number);
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
         my $query = "update $tablename set status ='ANSWERED' where mobno = '$number'";
         my $sth = $dbh->prepare($query);
         $sth->execute();
         if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();

	my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
            		
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
        
       return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        my $lang = "ivr/ThinkWalnut/infant";
        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
        my $bg_sound_file = "1";
       
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/mb_rec-5");
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
		'1' => '1',
	        '2' => '2' 
	};
    	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf
	}
           my $number = $mem_obj->{'number_dialed'};
      #  __logFile("In Welcome Section and key pressed ",$number);
        if($dtmf == 1)
	{
		return ("__pregnant");
	}
       if($dtmf == 2)
       {
		return ("__child");
       }
}

sub __pregnant
{
	my ($config,$default_values,$mem_obj) = @_;
	my $bg_sound_file = "11";
        #=========================================================
        $default_values->{'invalid_file'}= "invalid_input";
	$default_values->{'invalid_max'} = "max_attempt";
	$default_values->{'timeout_file'}= "no_input";
	$default_values->{'timeout_max'}=  "no_input";
	#==========================================================
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
		'1' => '1',
	        '2' => '2' 
	};
        
	 my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);


 	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

      	 }
     if($dtmf == 1 || $dtmf == 2)
	{
	     #======================********For Database Insertion*************** ===========================
              my $AGI = new Asterisk::AGI;
              my $cdr_billsec = $AGI->get_variable('CDR(billsec)');
              my $start_time = $AGI->get_variable('CDR(start)');
              my $callerid = $mem_obj->{'number_dialed'};
              my $tablename = 'mobile_reg';
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "INSERT INTO $tablename (mobno,section) VALUES('$callerid','1~$cdr_billsec')";
              my $sth = $dbh->prepare($query) ;
              my $ret =$sth->execute();
              $dbh->disconnect();
            #========================******For pushing the response****** =============================
            #  my $url ="http://180.179.103.253/13/paddle_pop/api/get_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'broadcast_id'}&level= 1&status= $mem_obj->{'status'}&attempt= $mem_obj->{'attempt'}&language= $mem_obj->{'language'}";
	     # my $request = new HTTP::Request(POST => $url  );
	     # $request->content_type('application/x-www-form-urlencoded');
	     # my $ua = LWP::UserAgent->new();
             # my $response = $ua->request($request);  
           #====================================================================================
             $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/111");
             return ("exit");
	}
     
}
sub __child
{

	my ($config,$default_values,$mem_obj) = @_;
	my $bg_sound_file = "12";
       #=========================================================
        $default_values->{'invalid_file'}= "invalid_input";
	$default_values->{'invalid_max'} = "max_attempt";
	$default_values->{'timeout_file'}= "invalid_input";
	$default_values->{'timeout_max'}=  "invalid_input";
        #==========================================================

        my $max_allowed_digit = "1";
	my $hash_table_ref = {
		'1' => '1',
	        '2' => '2' 
	};
         my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);


 	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

      	 }
     if($dtmf == 1 || $dtmf == 2)
	{
            #==============================================================
              my $AGI = new Asterisk::AGI;
              my $cdr_billsec = $AGI->get_variable('CDR(billsec)');
              my $callerid = $mem_obj->{'number_dialed'};
              my $tablename = 'mobile_reg';
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "INSERT INTO $tablename (mobno,section) VALUES('$callerid','2~$dtmf~$cdr_billsec')";
              my $sth = $dbh->prepare($query) ;
              my $ret =$sth->execute();
              $dbh->disconnect();
            #=================================================================
	    $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/infant/121_122");
 	    return ("exit");
	}
      
}
sub __logFile
{      

       my($text,$number) = @_;
       my $number = $number;
       my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
       my $current_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
       my $file = "uc/config/ini/log_$number.txt";
       open(FILE,'>>',$file) or die "Could not open file";
       say FILE "$current_time:$text";
       close FILE;
}

main();
exit;
