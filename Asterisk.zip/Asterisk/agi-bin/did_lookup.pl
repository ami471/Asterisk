#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};
use Asterisk::AGI;
use Config::INI::Reader;

my ($did,$callerid) = @ARGV;
my $AGI = Asterisk::AGI->new();
my $exten = "_x.";
my $priority = 1;
my %output = $AGI->ReadParse();
$AGI->exec("Set","CDR(userfield)=&IN_DID=$did");
my $filename = '/uc/config/ini/did_info.ini';
my $result = Config::INI::Reader->read_file($filename);

if (exists $result->{ivr}->{$did} && $result->{ivr}->{$did} !~ /^$/) {

	$context = $result->{ivr}->{$did};
} 
$AGI->exec("Goto","$context,$exten,$priority");

exit;
