#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;


sub __update_status{

	my ($config,$default_values,$mem_obj) = @_;
	my $customer_no = $mem_obj->{'callerid'};
        my $dial_status = $mem_obj->{'dialed_status'};
        my $name;
        my $iifl_agent;
	if($dial_status eq "ANSWERED" )
	{
		$dial_status = 'ANSWER';
	}
        if($dial_status eq "CHANUNAVAIL")
	{
		$dial_status = "BUSY";
	}	
        if($dial_status eq "ANSWER" || $dial_status eq "NOANSWER" || $dial_status eq "BUSY")
	{
		my $tablename = 'iifl_customer_detail';
        	my $value = 1;
        	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        	my $query = "update $tablename set status = '$dial_status' where mobile_no = '$customer_no' order by id desc limit 1";
        	my $sth = $dbh->prepare($query);
        	$sth->execute();
        	if ($sth->rows()) 
		{
			$value =  0;
        	}		
        	$sth->finish();
    		$dbh->disconnect();
	}
     #   $media_vehicle =  $mem_obj->{'media_vehicle'};
     #   my $tablename = 'iifl_customer_detail';
     #   my $dbh_1 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
     #   my $query_1 = "INSERT INTO $tablename (mobile_no,location,date,time,day,Time_Session,zone,pincode,campaign,weekday,media_channel,media_vehicle,status) VALUES('$mem_obj->{'callerid'}','$mem_obj->{'location'}','$mem_obj->{'current_date'}','$mem_obj->{'current_time'}','$mem_obj->{'weekday'} ','$mem_obj->{'time_now'}','$mem_obj->{'zone'}','$mem_obj->{'dtmf'}','IIFL','$mem_obj->{'day_is'} ','PRINT','$mem_obj->{'media_vehicle'}',$dial_status)";
      #  my $sth_1 = $dbh_1->prepare($query_1) ;
      #  my $ret_1 =$sth_1->execute();
      #  $sth_1->finish();
      #  $dbh_1->disconnect();


	       my $value = 1;
  
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select name,contact_1 from iifl_pincode where pincode = (select pincode from iifl_customer_detail where mobile_no = $customer_no order by id desc limit 1)";
        my $sth = $dbh->prepare($query) ;
        my  $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
              $name             =      $row[0];
	      $iifl_agent       =      $row[1];

        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
	if ($dial_status eq "ANSWER" or $dial_status eq "ANSWERED") 
	{
       #=================IIFL Customer====
	my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=8&callerNo=$mem_obj->{'callerid'}&toSend=$mem_obj->{'callerid'}&name=$name&spokenTo=$iifl_agent";
                my $res = $ua->request($req);
	#============IIFL Agent==========================
	my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0}, );
                my $req = GET "http://rubicsolution.in/IIFL/api/iifl_ivr_pushmsg.php?type=10&callerNo=$mem_obj->{'callerid'}&toSend=$iifl_agent&name=$mem_obj->{'name'}&spokenTo=$mem_obj->{'callerid'}";
                my $res = $ua->request($req);
       }
        return "exit";
     
}




sub main {

	my (${CID},${DIALSTATUS}) = @ARGV;
	my $AGI = new Asterisk::AGI;
        my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'callerid' => ${CID},
		'dialed_status' => ${DIALSTATUS}
	};
		
	my $function = "__update_status";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
