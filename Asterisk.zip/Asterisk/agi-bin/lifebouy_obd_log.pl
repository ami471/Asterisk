#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($number_dialed) = @ARGV;
        my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
        my (%output) = $AGI->ReadParse();
        my $config = {
                '_cti_obj' => $AGI,
                '_db' => 1
        };
        my %value_hash;
        my $default_values = {
                'timeout' => '3000',
                'timeout_count' => '2',
                'timeout_file' => undef,
                'timeout_max' => undef,
                'invalid_count' => '1',
                'invalid_file' => undef,
                'invalid_max' => undef
        };
        my $mem_obj = {
                'session_id' => $output{'uniqueid'},
                'number_dialed' => $number_dialed,
                'count' => '0'
        };
         my $tablename = 'lifebuoy_call';
         my $value = 1;
         my $number = $mem_obj->{'number_dialed'};
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        my $uniqueid = sprintf("%02d%02d%02d%02d",$date,$hour,$min,$sec);
        $mem_obj->{'$uniqueid'} = $uniqueid;
        __logFile("In Main Function", $number,$uniqueid);

  #       __logFile("In Main mobile number", $number);
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
         my $query = "update $tablename set status ='ANSWERED' where callerid = '$number'";
         my $sth = $dbh->prepare($query);
         $sth->execute();
         if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();

#	my $function = "__welcome";
        my $function = "__time_check";

	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
          		$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
        
       return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __time_check 
{

	my ($config,$default_values,$mem_obj) = @_;
	my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
	my $current_time = sprintf("%02d%02d%02d",$hour,$min,$sec);
	if ($current_time >= '220000') 
	{
		return "exit";
	}
       if ($current_time >= '000000' && $current_time < '060000')
        {
                return "exit";
        }

	return "__welcome";
}

sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        my $number = $mem_obj->{'number_dialed'};
        my $uniqueid =   $mem_obj->{'$uniqueid'};
        __logFile("In Welcome section", $number, $uniqueid);
        my $tablename = 'lifebuoy_call';
        my $callerid;
        my $prompt_id;
        my $unique_id;
        my $contactno = $mem_obj->{'number_dialed'};
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select callerid,prompt_id,unique_id from $tablename where callerid = '$contactno' ";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array()){
        $callerid         =      $row[0];
        $prompt_id        =      $row[1];
        $unique_id         =      $row[2];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
        $mem_obj->{'prompt_id'} = $prompt_id;
        $mem_obj->{'unique_id'} = $unique_id;
        if ($prompt_id eq "NM_1")
        {               
		#my $AGI = new Asterisk::AGI;	
                  
                # $duration = $AGI->get_variable('CDR(duration)');
                # my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)'); 
                 $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $mem_obj->{'session_id'}";
                 $request = new HTTP::Request(POST => $url  );
                 $request->content_type('application/x-www-form-urlencoded');
                 $ua = LWP::UserAgent->new();
                 $response = $ua->request($request);
                 __logFile("Prompt NM_1 started", $number, $uniqueid);
                 $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_1");
                 $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
                  __logFile("Prompt NM_1 completed", $number, $uniqueid);

	}
	
	if ($prompt_id eq "NM_2")
        {
		#========================******For pushing the response****** =============================
         #	my $AGI = new Asterisk::AGI;
         #	my $duration = $AGI->get_variable('CDR(duration)');
         #       my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
        	my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $mem_obj->{'session_id'}";
        	my $request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	my $ua = LWP::UserAgent->new();
        	my $response = $ua->request($request);
        	#====================================================================================
                __logFile("Prompt NM_2 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_2");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
                __logFile("Prompt NM_2 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_3")
	{
		#========================******For pushing the response****** =============================
         #	my $AGI = new Asterisk::AGI;
         #	my $duration = $AGI->get_variable('CDR(duration)');
         #       my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $mem_obj->{'session_id'}";
        	my $request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	my $ua = LWP::UserAgent->new();
        	my $response = $ua->request($request);
        	#====================================================================================
                  __logFile("Prompt NM_3 started", $number, $uniqueid);
                 $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_3");
                 $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
		 __logFile("Prompt NM_3 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_4")
        {
		#========================******For pushing the response****** =============================
       #  	my $AGI = new Asterisk::AGI;
       #  	my $duration = $AGI->get_variable('CDR(duration)');
       #         my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

        	my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
        	my $request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	my $ua = LWP::UserAgent->new();
        	my $response = $ua->request($request);
        	#====================================================================================
                __logFile("Prompt NM_4 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_4");
                 $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
		__logFile("Prompt NM_4 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_5")
        {
		 #========================******For pushing the response****** =============================
            #    my $AGI = new Asterisk::AGI;
            #    my $duration = $AGI->get_variable('CDR(duration)');
            #    my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
		my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
		__logFile("Prompt NM_5 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_5");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
                __logFile("Prompt NM_5 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_6")
        {
         	#========================******For pushing the response****** =============================
        # 	my $AGI = new Asterisk::AGI;
        # 	my $duration = $AGI->get_variable('CDR(duration)');
        #        my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
        	my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
        	my $request = new HTTP::Request(POST => $url  );
        	$request->content_type('application/x-www-form-urlencoded');
        	my $ua = LWP::UserAgent->new();
        	my $response = $ua->request($request);
        	#====================================================================================
                __logFile("Prompt NM_6 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_6");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
		__logFile("Prompt NM_6 completed", $number, $uniqueid);

                
        }
	if ($prompt_id eq "NM_7")
        {
		 #========================******For pushing the response****** =============================
             #   my $AGI = new Asterisk::AGI;
             #   my $duration = $AGI->get_variable('CDR(duration)');
             #   my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt NM_7 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_7");
		$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
		 __logFile("Prompt NM_7 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_8")
        {
		 #========================******For pushing the response****** =============================
             #   my $AGI = new Asterisk::AGI;
             #   my $duration = $AGI->get_variable('CDR(duration)');
             #   my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
		my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt NM_8 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_8");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
		__logFile("Prompt NM_8 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_9")
        {
		 #========================******For pushing the response****** =============================
             #   my $AGI = new Asterisk::AGI;
             #   my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt NM_9 started", $number, $uniqueid);

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_9");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
		__logFile("Prompt NM_9 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_10")
        {
		 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
              #  my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt NM_10 started", $number, $uniqueid);

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_10");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
                __logFile("Prompt NM_10 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_11")
        {
		 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
              #  my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
		my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt NM_11 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_11");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
                __logFile("Prompt NM_11 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_12")
        {
		 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
		my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt NM_12 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_12");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
               __logFile("Prompt NM_12 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_13")
        {
		 #========================******For pushing the response****** =============================
            #    my $AGI = new Asterisk::AGI;
            #    my $duration = $AGI->get_variable('CDR(duration)');
            #    my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt NM_13 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_13");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
                __logFile("Prompt NM_13 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_14")
        {
		 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                  __logFile("Prompt NM_14 started", $number, $uniqueid);

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_14");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
                __logFile("Prompt NM_14 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_15")
        {
		 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');
                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                  __logFile("Prompt NM_15 started", $number, $uniqueid);

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_15");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");
		__logFile("Prompt NM_15 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "NM_16")
        {
		 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                  __logFile("Prompt NM_16 started", $number, $uniqueid);


                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/NM_16");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_NM");

                 __logFile("Prompt NM_16 completed", $number, $uniqueid);

        }
	if ($prompt_id eq "GM_1")
        {
		 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
              #  my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt GM_1 started", $number, $uniqueid);

                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_1");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");

                 __logFile("Prompt GM_1 completed", $number, $uniqueid);

        }
	 if ($prompt_id eq "GM_2")
        {
		 #========================******For pushing the response****** =============================
            #    my $AGI = new Asterisk::AGI;
            #    my $duration = $AGI->get_variable('CDR(duration)');
            #    my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                 __logFile("Prompt GM_2 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_2");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");

		 __logFile("Prompt GM_2 completed", $number, $uniqueid);

        }
	 if ($prompt_id eq "GM_3")
        {
		 #========================******For pushing the response****** =============================
           #     my $AGI = new Asterisk::AGI;
           #     my $duration = $AGI->get_variable('CDR(duration)');
           #     my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt GM_3 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_3");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");
                __logFile("Prompt GM_3 completed", $number, $uniqueid);

        }
	 if ($prompt_id eq "GM_4")
        {
		 #========================******For pushing the response****** =============================
       #         my $AGI = new Asterisk::AGI;
       #         my $duration = $AGI->get_variable('CDR(duration)');
       #         my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt GM_4 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_4");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");
                __logFile("Prompt GM_4 completed", $number, $uniqueid);

        }
	 if ($prompt_id eq "GM_5")
        {
		 #========================******For pushing the response****** =============================
             #   my $AGI = new Asterisk::AGI;
             #   my $duration = $AGI->get_variable('CDR(duration)');
             #   my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                 __logFile("Prompt GM_5 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_5");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");
                __logFile("Prompt GM_5 completed", $number, $uniqueid);

        }
	 if ($prompt_id eq "GM_6")
        {
		 #========================******For pushing the response****** =============================
             #   my $AGI = new Asterisk::AGI;
             #   my $duration = $AGI->get_variable('CDR(duration)');
             #   my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt GM_6 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_6");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");
                __logFile("Prompt GM_6 completed", $number, $uniqueid);

        }
	 if ($prompt_id eq "GM_7")
        {
		 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt GM_7 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_7");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");
                __logFile("Prompt GM_7 completed", $number, $uniqueid);

        }
	 if ($prompt_id eq "GM_8")
        {
		 #========================******For pushing the response****** =============================
         #       my $AGI = new Asterisk::AGI;
         #       my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt GM_8 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_8");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");
                __logFile("Prompt GM_8 completed", $number, $uniqueid);

        }
	 if ($prompt_id eq "GM_9")
        {
		 #========================******For pushing the response****** =============================
           #     my $AGI = new Asterisk::AGI;
           #     my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt GM_9 started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/GM_9");
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/SIGN_OFF_GM");
                __logFile("Prompt GM_9 completed", $number, $uniqueid);

        }
	
	if ($prompt_id eq "RM_A")
        {
                 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                __logFile("Prompt RM_A started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_A");
                 __logFile("Prompt RM_A completed", $number, $uniqueid);

        }
	
	if ($prompt_id eq "RM_B")
        {
                 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
              #   my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                 __logFile("Prompt RM_B started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_B");
                 __logFile("Prompt RM_B completed", $number, $uniqueid);

        }
	
	  if ($prompt_id eq "RM_C")
        {
                 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
              #  my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                 __logFile("Prompt RM_C started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_C");
                 __logFile("Prompt RM_C completed", $number, $uniqueid);

        }
	
	  if ($prompt_id eq "RM_D")
        {
                 #========================******For pushing the response****** =============================
             #   my $AGI = new Asterisk::AGI;
             #   my $duration = $AGI->get_variable('CDR(duration)');
	#	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                 __logFile("Prompt RM_D started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_D");
                 __logFile("Prompt RM_D completed", $number, $uniqueid);

        }
	
	  if ($prompt_id eq "RM_E")
        {
                 #========================******For pushing the response****** =============================
           #     my $AGI = new Asterisk::AGI;
           #     my $duration = $AGI->get_variable('CDR(duration)');
	   #	my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                 __logFile("Prompt RM_E started", $number, $uniqueid);
                $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/lifebuoy/RM_E");
                 __logFile("Prompt RM_E completed", $number, $uniqueid);

        }
	
	if ($prompt_id eq "RM_F")
        {
                 #========================******For pushing the response****** =============================
              #  my $AGI = new Asterisk::AGI;
              #  my $duration = $AGI->get_variable('CDR(duration)');
	      #  my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                 __logFile("Prompt RM_F started", $number, $uniqueid);
                my $bg_sound_file = "ivr/ThinkWalnut/lifebuoy/RM_F";
                my $max_allowed_digit = "1";
                my $hash_table_ref = {

                                '1' => 'ok'

                };

                my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	
		 __logFile("Prompt RM_F completed", $number, $uniqueid);

		#========================******For pushing the response****** =============================
               # my $AGI = new Asterisk::AGI;
               #  $duration = $AGI->get_variable('CDR(duration)');
            $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&key_press=$dtmf&asterisk_uniqueid= $mem_obj->{'session_id'}";
               $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                $ua = LWP::UserAgent->new();
                $response = $ua->request($request);
                #====================================================================================
		

                
		
                
      }
             
      if ($prompt_id eq "GM_PLEDGE")
       {
                 #========================******For pushing the response****** =============================
               # my $AGI = new Asterisk::AGI;
               # my $duration = $AGI->get_variable('CDR(duration)');
               # my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)');

                my $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid= $mem_obj->{'session_id'}";
                my $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                my $ua = LWP::UserAgent->new();
                my $response = $ua->request($request);
                #====================================================================================
                 __logFile("Prompt GM_PLEDGE started", $number, $uniqueid);
                my $bg_sound_file = "ivr/ThinkWalnut/lifebuoy/GM_PLEDGE";
                my $max_allowed_digit = "1";
                my $hash_table_ref = {

				'1' => 'ok'

		};
           
                my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);

                __logFile("Prompt GM_PLEDGE completed", $number, $uniqueid);

                #========================******For pushing the response****** =============================
               # my $AGI = new Asterisk::AGI;
                # $duration = $AGI->get_variable('CDR(duration)');
              $url ="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&key_press=$dtmf&asterisk_uniqueid= $mem_obj->{'session_id'}";
                 $request = new HTTP::Request(POST => $url  );
                $request->content_type('application/x-www-form-urlencoded');
                $ua = LWP::UserAgent->new();
                 $response = $ua->request($request);
                #====================================================================================





      }



	 
}

#=======================================

sub __logFile
{
        my($text,$number,$uniqueid) = @_;
        my $num = $number;
        my $folder;
        my $unique = $uniqueid;
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        $year +=1900;
        $mon  +=1;
        my $current_time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
        #====================================================================
        $folder=  sprintf("%02d%02d%03d",$date,$mon,$year);
        my $current_date = sprintf("%02d",$date);
        my $dirname = "/var/log/asterisk/lifebouy_obd/$folder";
        if(-e $dirname)
        {
                
        }
        else
        {
               
           mkdir $dirname;
        }


        
#=====================================================================

        my $file_time = sprintf("%02d%02d%02d%02d%02d%03d",$hour,$min,$sec,$date,$mon,$year);
        my $filename = "twdoutboundlog-".$num."-".$unique."-".$file_time;
        my $file = "/var/log/asterisk/lifebouy_obd/$folder/$filename.log";
        open(FILE,'>>',$file) or die "Could not open file";
        say FILE "$current_time:$text";
        close FILE;
}

main();
exit;
