#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;
use Time::Local;
sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);

	my $default_values = {
		'timeout' => '4000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
                
	};
	
	my ($lead_id,undef) = split(/\./,$output{'uniqueid'});

	my $mem_obj = {
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
		'did' => $did,
		'dial_group' => "$value_hash{shadi}->{dial_group}",
		'dial_channel' => "$value_hash{shadi}->{dial_channel}",
		'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
		'callerid_out_1' => "07666844433",
                'callerid_out_2' => "8369854211",
                'callerid_out_3' => "$value_hash{shadi}->{'escalate_number_3'}",
		'dial_group_sec' => "$value_hash{shadi}->{dial_group_sec}"
	};
	my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $timeout = $mem_obj->{'dial_timeout'};		
	my $function = "__main_menu";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub __main_menu {

	my ($config,$default_values,$mem_obj) = @_;
        my $lang = "ivr/ThinkWalnut/call_demo";
        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
        $config->{_cti_obj}->exec("Playback","Rajendra");


}





sub __failure_case {

       my ($config,$default_values,$mem_obj) = @_;


       return "exit";

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
