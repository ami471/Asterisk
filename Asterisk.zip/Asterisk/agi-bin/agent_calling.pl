#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;
use Time::Local;

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);

	my $default_values = {
		'timeout' => '4000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
                
	};
	
	my ($lead_id,undef) = split(/\./,$output{'uniqueid'});

	my $mem_obj = {
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
		'did' => $did,
		'dial_group' => "$value_hash{shadi}->{dial_group}",
		'dial_channel' => "$value_hash{shadi}->{dial_channel}",
		'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
		'callerid_out_1' => "$value_hash{shadi}->{'escalate_number'}",
                'count' => '0'
	};
	my $function = "__language_selection";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub __language_selection{

        my ($config,$default_values,$mem_obj) = @_;
        my $lang = "ivr/ThinkWalnut/IIFL_Campaign/eng";
        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
        return ("__action_on_key_1");

}



sub __action_on_key_1 {

       my ($config,$default_values,$mem_obj) = @_;
       $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/IIFL_Campaign/Welcome");
       my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
       $year +=1900;
       $mon  +=1;
       my $current_date = sprintf("%03d%02d%02d",$year,$mon,$date);
       my $bg_sound_file = "enter_pincode";
       my $max_allowed_digit = "4";
       my $mobile_no;
       my $agent_number;
       my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});    
	$mem_obj->{'dtmf'} = $dtmf;
#	 my $filename = '/var/log/asterisk/test_report.txt';
#        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
#        print $fh "The dtmf input is = $dtmf \n";
#        close $fh;

         my $tablename = 'digitalmedia_customer_detail';
        my $value = 1;
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query = "select mobile_no, agent_number from $tablename where customer_code = $dtmf order by id desc limit 1";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array())
        {
                $mobile_no          =      $row[0];
                $agent_number        =      $row[1];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
	$mem_obj->{'contact_1'} =  $mobile_no;
	$mem_obj->{'agent_no'}  =  $agent_number;
#	my $filename = '/var/log/asterisk/test_report.txt';
#        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
#        print $fh "The query is $query \n";
#        close $fh;
       return ("__connectcall");
       

}

sub __connectcall
{
	my ($config,$default_values,$mem_obj) = @_;
	my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        $year +=1900;
        $mon  +=1;
        my $current_date = sprintf("%03d%02d%02d",$year,$mon,$date);
     #   my $customer_no = $mem_obj->{'callerid'};
        my $current_time = $mem_obj->{'current_time'};
   #    my $name = $mem_obj->{'name'};
        my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $out_no = $mem_obj->{'contact_1'};
	my $timeout = $mem_obj->{'dial_timeout'};
        my $filename = "iifl-".$mem_obj->{callerid}."-".$mem_obj->{contact_1}."-".$mem_obj->{'did_mobile'};	
	$config->{_cti_obj}->exec("Monitor","wav,/var/lib/asterisk/recordings/$year/$mon/$date/$filename,m");
	my $dial_string =$dial_channel."/".$dial_group."/".$out_no;
	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout,gm[gss]");
#	my $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout");
	my $call_status = $config->{_cti_obj}->get_variable("DIALSTATUS");
        $config->{_cti_obj}->exec("NoOp","===$call_status");
        if ($call_status eq "ANSWER") 
	{
	      my $tablename = 'iifl_customer_detail';
              my $value = 1;
              my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
              my $query = "update $tablename set status ='ANSWERED' where mobile_no = '$customer_no' order by id desc limit 1";
              my $sth = $dbh->prepare($query);
              $sth->execute();
              if ($sth->rows()) {

                $value =  0;
		}
        	$sth->finish();
        	$dbh->disconnect();
	        return "exit";

        }
       $config->{_cti_obj}->exec("StopMonitor","");
       if ($call_status eq "BUSY") 
       {
	     
       		return "exit";
       }
       if ($call_status eq "NOANSWER") 
       {
	     
       		return "exit";
      }


}


sub __failure_case {

       my ($config,$default_values,$mem_obj) = @_;


       return "exit";

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
