#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use Time::Local;

# this __dial_out function is dialing out call_center number and hanging up at the last
sub __dial_out {
	
	my ($config,$mem_obj) = @_;
        my $dial_channel = $mem_obj->{'dial_channel'};
	my $dial_group = $mem_obj->{'dial_group'}; 
	my $timeout = $mem_obj->{'dial_timeout'};
	my $dial_out = $mem_obj->{'call_center_no'};
        my $callerid = $mem_obj->{'callerid'};
        
        my $tablename = 'housie_call';
        my $dbh_3 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $query_3 = "select * from $tablename where callerid = '$callerid'";
	my $sth_3 = $dbh_3->prepare($query_3);
	$sth_3->execute();
	if ($sth_3->rows())
	 {
	 
               
               my $dbh_3 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
               my $query_3 = "UPDATE $tablename SET ModifiedTime = NOW(), attempt =0, status = 'NOANSWER' WHERE callerid = '$callerid'";
               $sth_3 = $dbh_3->prepare($query_3);
               $sth_3->execute();
               $dbh_3->disconnect();
	 }
        else
        {
        	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        	my $query = "INSERT INTO $tablename (callerid,status) VALUES('$callerid','NOANSWER')";
		my $sth = $dbh->prepare($query) ;
		my $ret =$sth->execute();
        	$dbh->disconnect();
        }
		my $timeout = 20000;
                $dial_out = 2262323202;
     		my $dial_string = "SIP/tatasip/".$dial_out;
                $status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout");


       if ($status_var eq "CHANUNAVAIL" or $status_var eq "CONGESTION")  #23Aug
        {
		$dial_group = $mem_obj->{'dial_group_sec'};
		$config->{_cti_obj}->exec("Set","CALLERID(num)=$callerid_out");	
	#	my $dial_string = $dial_channel."/".$dial_group."/".$dial_out;
               my $dial_string = "SIP/".$dial_out;
		$status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout");
	}
	return "exit";
}

# main function
sub main {

	my ($dial_out_num) = @ARGV;
        my %count;
	my $AGI = new Asterisk::AGI;
	$AGI->exec("NoOP","dial_out======$dial_out_num");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI
	};	
	my %value_hash;
	my $file_name = "/uc/config/ini/missed_call.conf";
	read_ini_file($file_name,\%value_hash);
	my $mem_obj = {
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
		'dial_timeout' => $value_hash{missed_call}->{dial_timeout},
		'call_center_no' => $dial_out_num,                            #$value_hash{missed_call}->{call_center_no},
                'callerno'       => 0
                
 
	};	
	my $function = "__dial_out";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;
}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
          
}

main();
exit;
