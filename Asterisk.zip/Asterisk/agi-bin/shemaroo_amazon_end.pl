#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request::Common;
use LWP::UserAgent;


sub __update_status{

	my ($config,$default_values,$mem_obj) = @_;
	my $customer_no = $mem_obj->{'callerid'};
        my $dial_status = $mem_obj->{'dialed_status'};
        my $name;
        my $iifl_agent;
	my $location;        
        my $date;            
        my $time;            
        my $day;             
        my $Time_Session;   
        my $zone;             
        my $pincode;         
        my $campaign;        
        my $weekday;          
        my $media_channel;    
        my $media_vehicle;    
        my $status;          
        my $languagekey; 
        my $type;
        my $did;
        my $pincode_enterd = 0;     
	if($dial_status eq "ANSWERED" )
	{
		$dial_status = 'ANSWERED';
	}
        if($dial_status eq "CHANUNAVAIL")
	{
		$dial_status = "BUSY";
	}	
        if($dial_status eq "ANSWER" || $dial_status eq "NOANSWER" || $dial_status eq "BUSY")
	{
		if($dial_status eq "ANSWER")
		{
		    $dial_status = 'ANSWERED';
		}
		my $tablename = 'shemaroo_amazon';
        	my $value = 1;
        	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        	my $query = "update $tablename set dial_status = '$dial_status' where callerid = '$customer_no' order by id desc limit 1";
        	my $sth = $dbh->prepare($query);
        	$sth->execute();
        	if ($sth->rows()) 
		{
			$value =  0;
        	}		
        	$sth->finish();
    		$dbh->disconnect();
	}
    	
   return "exit";
     
}




sub main {

	my (${CID},${DIALSTATUS}) = @ARGV;
	my $AGI = new Asterisk::AGI;
        my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'callerid' => ${number_dialed},
		'dialed_status' => ${DIALSTATUS}
	};
		
	my $function = "__update_status";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
