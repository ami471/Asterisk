#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;

sub __welcome
{
        my ($config,$default_values,$mem_obj) = @_;
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/Aditya_Birla/Welcome");
	return("__sales_feedback");
}
sub __sales_feedback
{
	my ($config,$default_values,$mem_obj) = @_;
	my $bg_sound_file = "ivr/ThinkWalnut/Aditya_Birla/ease_of_use";
   	my $max_allowed_digit = "1";
	my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});
	return("__customer_feedback");
}

sub __customer_feedback
{
	my ($config,$default_values,$mem_obj) = @_;
	my $bg_sound_file = "ivr/ThinkWalnut/Aditya_Birla/customer_service";
        my $max_allowed_digit = "1";
        my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});
        return("__pricing");

}

sub __pricing
{
	 my ($config,$default_values,$mem_obj) = @_;
        my $bg_sound_file = "ivr/ThinkWalnut/Aditya_Birla/pricing";
        my $max_allowed_digit = "1";
        my $dtmf = Ivr::DialPlanApi::apps_background_length($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'});
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/Aditya_Birla/Thank_You");
	return "exit";
}



sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$did");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'callerid' => $output{'callerid'},
		'did' => $did,
		'dial_group' => "$value_hash{shadi}->{dial_group}",
                'dial_channel' => "$value_hash{shadi}->{dial_channel}",
                'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
                'callerid_out_1' => "$value_hash{shadi}->{'escalate_number'}",
		'count' => '0'
                 
	};
		
	my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}



sub read_ini_file {

		my ($filename,$hashref) = @_;

		my $tmphashref;

		$tmphashref = Config::INI::Reader->read_file($filename); 

		%{$hashref} = %{$tmphashref};

}



main();
exit;

