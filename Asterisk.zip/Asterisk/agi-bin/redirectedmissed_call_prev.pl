#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
};

use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;
use Time::Local;
#use XML::Simple 'XMLin';
# this __dial_out function is dialing out call_center number and hanging up at the last
sub __dial_out {
	
	my ($config,$mem_obj) = @_;
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $dial_group = $mem_obj->{'dial_group'}; 
	my $timeout = $mem_obj->{'dial_timeout'};
	my $dial_out = $mem_obj->{'call_center_no'};
        my $callerid = $mem_obj->{'callerid'};
        my $did	     = "0226121".$mem_obj->{'did'};

	my $tablename = 'redirectedmissed_calling';
        
	my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count =0;
        my $query = "INSERT INTO $tablename (mobno,status,did) VALUES('$callerid','NOANSWER','$did')";
	my $sth = $dbh->prepare($query) ;
	my $ret =$sth->execute();
        $dbh->disconnect();
 
        
        my $dbh_2 = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
        my $count_2 =0;
        my $query_2 = "DELETE FROM $tablename WHERE status ='ANSWERED'";
        my $sth_2 = $dbh_2->prepare($query_2) ;
        my $ret_2 =$sth_2->execute();
        $dbh_2->disconnect();
       
       

	if ($status_var eq "CHANUNAVAIL" or $status_var eq "CONGESTION") {
		$dial_group = $mem_obj->{'dial_group_sec'};
		#my $callerid_out = $mem_obj->{'callerid_out_sec'};
		$config->{_cti_obj}->exec("Set","CALLERID(num)=$callerid_out");	
		#$dial_string = $dial_channel."/".$dial_group."/".$dial_out;
                my $dial_string = "SIP/".$dial_out;
		$status = $config->{_cti_obj}->exec("Dial","$dial_string,$timeout");
	}
#	return "exit";
	if($mem_obj->{'did'} == 8607)
	{
		return "post_number";
	}
	if($mem_obj->{'did'} == 8625)
        {
           #     return "post_crayfish_detail";
		 my $filename = '/var/log/asterisk/report_crayfish.txt';
                        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                        print $fh "Inside crayfish and did is $mem_obj->{'did'} \n";
                        close $fh;
		my $time = time;
        	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
        	my $current_time = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year +1900, $mon+1, $mday, $hour, $min, $sec);

         	#============SEND RESPONSE====================
		my $url ="http://172.20.120.140/39/crayfish/utilities/missedCallDump.php?mdn=$callerid&timestamp=$current_time&src=2";
         	my $request = new HTTP::Request(POST => $url);
         	$request->content_type('application/x-www-form-urlencoded');
         	my $ua = LWP::UserAgent->new();
         	my $response = $ua->request($request);
		 $filename = '/var/log/asterisk/report_crayfish.txt';
                        open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                        print $fh "Response for $url is $response \n";
                        close $fh;
                        

		if ($response->is_success)
        	{
                	my $filename = '/var/log/asterisk/report_crayfish.txt';
                	open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                	print $fh "Response is sucessful for $url and time is $current_time \n";
                	close $fh;
			return 1;
		}  
		else 
		{
                	my $status_lin = $response->status_code;
                	my $filename = '/var/log/asterisk/report_crayfish.txt';
                	open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                	print $fh "Response is unsucessful for $url and time is $current_time\n";
                	close $fh;
			return -1;
        	}

		#==============END============================
        }

	else
	{
		return "exit";
	}
}

# main function
sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
	$AGI->exec("NoOP","dial_out======$dial_out_num");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI
	};	
	my %value_hash;
	my $file_name = "/uc/config/ini/missed_call.conf";
	read_ini_file($file_name,\%value_hash);
		
	my $mem_obj = {
		'callerid' => $output{'callerid'},
		'did' => $did,
		'session_id' => $output{'uniqueid'},
		#'dial_group' => $value_hash{mahindra_call}->{dial_group},
		#'dial_group_sec' => $value_hash{mahindra_call}->{dial_group_sec},
		#'dial_channel' => $value_hash{mahindra_call}->{dial_channel},
		'dial_timeout' => $value_hash{missed_call}->{dial_timeout},
		'call_center_no' =>$value_hash{missed_call}->{call_center_no},
		#'callerid_out' => $value_hash{mahindra_call}->{callerid_out},
		#'callerid_out_sec' => $value_hash{mahindra_call}->{callerid_out_sec}
		
	};	
	
	my $function = "__dial_out";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}



sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub post_number {

 my ($config,$mem_obj) = @_;
        my $callerid = $mem_obj->{'callerid'};
        my $uniqueid = $mem_obj->{'session_id'};
	my $called_no;
	if($mem_obj->{'did'} == 8607)
	{
		 $called_no = 9222216216;
	}
       # my $url ="http://172.20.120.105/13/wma/api/misscall_api.php?mdn=$callerid";
        my $url ="http://172.20.120.105/13/api/twd_get_misscall.php?c=$called_no&m=$callerid";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        my $current_time = sprintf("%02d%02d%02d",$hour,$min,$sec);
        if ($response->is_success)
        {
                my $filename = '/var/log/asterisk/report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url and time is $current_time \n";
                close $fh;





                                return 1;

        }  else {

                my $status_lin = $response->status_code;
		my $filename = '/var/log/asterisk/report.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is unsucessful for $url and time is $current_time\n";
                close $fh;

                 return -1;
        }

   return "exit";
	
       
}

#=============CrayFish=================
sub post_crayfish_detail {

 my ($config,$mem_obj) = @_;
        my $callerid = $mem_obj->{'callerid'};
        my $uniqueid = $mem_obj->{'session_id'};
        my $called_no;
        my $time = time;
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
	my $current_time = sprintf("%04d-%02d-%02d %02d:%02d:%02d", $year +1900, $mon+1, $mday, $hour, $min, $sec);
        my $url ="https://crayfish.twd.bz/utilities/missedCallDump.php?mdn=$callerid&timestamp=$current_time&src=2";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
         if ($response->is_success)
        {
                my $filename = '/var/log/asterisk/report_crayfish.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url and time is $current_time \n";
                close $fh;





                                return 1;

        }  else {
                my $status_lin = $response->status_code;
                my $filename = '/var/log/asterisk/report_crayfish.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is unsucessful for $url and time is $current_time\n";
                close $fh;

                 return -1;
        }

   return "exit";


}
#============Till here=================

main();
exit;
