#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;


sub __tea_selection{

	my ($config,$default_values,$mem_obj) = @_;

	my $bg_sound_file = "ivr/ThinkWalnut/taza/2_Opt-Out_Prompt_Option_HUL";
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/taza/1_Welcome(1)");
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => '1',
	        '2' => '2' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);
	
        if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

       }
      #   my $tablename = 'cdr';
      #  my $did = $mem_obj->{'did'};
      #  my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","root");

      #  my $query = "INSERT INTO $tablename (src,status) VALUES('$did')";

#	my $sth = $dbh->prepare($query) ;

#	my $ret =$sth->execute();

#        $dbh->disconnect();
     
        if($dtmf == 1)

       {

              return ("__gender_verification");

       }
       if($dtmf == 2)
	{

              return ("__gender_verification");
        }
       else
	{
		return ("__tea_selection");
	}
     
}

sub __failure_case {

	my ($config,$default_values,$mem_obj) = @_;
        $config->{_cti_obj}->exec("Playback","gss_thk");
        return "exit";
}

sub __drop_call {

        my ($config,$default_values,$mem_obj) = @_;

        return "exit";

}

sub __gender_verification
{
	my ($config,$default_values,$mem_obj) = @_;
	my $bg_sound_file = "ivr/ThinkWalnut/taza/3_GenderQuestion";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => '1',
	        '2' => '2' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);

 	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

      	 }
     if($dtmf == 1)
	{

              return ("__gender_male");
        }
       if($dtmf == 2)
	{

              return ("__gender_female");
	}
       else
	{
		return ("__invalid_option");
	}
}

sub __gender_male
{
	my ($config,$default_values,$mem_obj) = @_;
	my $bg_sound_file = "ivr/ThinkWalnut/taza/4_Brand_ProfilingQuestion";
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => '1',
	        	'2' => '2',
			'3' => '3',
			'4' => '4' 
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);

 	if (exists $hash_table_ref->{$dtmf}) 
	{

              $mem_obj->{'menu_option'} = $dtmf
	}
	 
	if($dtmf == 1)
	{
	    return ("__tea_aagni");
	}
}

sub __tea_aagni
{
	my ($config,$default_values,$mem_obj) = @_;
	my $bg_sound_file = "ivr/ThinkWalnut/taza/7_AnswerOptions_week_1";
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/taza/5_PreRoll");
 	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/taza/6_Riddle_Week1");  
	my $max_allowed_digit = "1";
	my $hash_table_ref = {
			'1' => '1',
	        	'2' => '2',
			'3' => '3'
			
	};
	my $dtmf = Ivr::DialPlanApi::apps_background_hash($config->{_cti_obj},$bg_sound_file,$max_allowed_digit,$default_values->{'timeout'},$default_values->{'timeout_count'},$default_values->{'timeout_file'},$default_values->{'timeout_max'},$default_values->{'invalid_count'},$default_values->{'invalid_file'},$default_values->{'invalid_max'},$hash_table_ref);

 	if (exists $hash_table_ref->{$dtmf}) {

              $mem_obj->{'menu_option'} = $dtmf

      	 }
	 
	 return ("__thanks_particpation");
}

sub __thanks_particpation
{
	my ($config,$default_values,$mem_obj) = @_;
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/taza/8_Closing_Prompt");
         return "exit";
}

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$did");
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
	my %value_hash;
        my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};

	my $mem_obj = {
		'session_id' => $output{'uniqueid'},
		'did' => $did
	};
		
	my $function = "__tea_selection";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

main();
exit;
