#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;

sub auto_disconnect {
        my ($config,$default_values,$mem_obj) = @_;
       # return 1 if(ref $config ne "Generic::Config");   
       # my $file = $mem_obj->{'time_disconnect'};
       # $config->{_ctiobj}->set_autohangup($file);
        $config->{_ctiobj}->hangup();                       
        return "__outbound_call";
  }

sub __outbound_call
{
  my ($config,$default_values,$mem_obj) = @_;
  my $chan 	= $mem_obj->{'chan'};
  my $channel   = $mem_obj->{'channel'};
  my $context   = $mem_obj->{'context'};
  my $extension = $mem_obj->{'extension'};
  my $priority  = $mem_obj->{'priority'};
#  my $callerid  = $mem_obj->{'callerid'};
  my $callerid  = 1001;
  my $string    = $chan."/".$callerid;
  my $status = $config->{_cti_obj}->exec("Originate","$string,$channel,$context,$extension,$priority");
  return "exit";
}

sub main {

	my ($did) = @ARGV;
	my $AGI = new Asterisk::AGI;
       my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
        my %value_hash;
	my $file_name = "/uc/config/ini/outboundivr.conf";
	read_ini_file($file_name,\%value_hash);

	my $default_values = {
		'timeout' => '3000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
	};
	
	my $mem_obj = {
	
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
                'did' => $did,
                'chan' => "$value_hash{outboundivr}->{chan}",
                'channel' => "$value_hash{outboundivr}->{channel}",
		'context' => "$value_hash{outboundivr}->{context}",
                'extension' => "$value_hash{outboundivr}->{extension}",
                'priority' => "$value_hash{outboundivr}->{priority}",
                'time_disconnect' => '10'
	};

	my $function = "__outbound_call";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;

}
sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}
main();
exit;
