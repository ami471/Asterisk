#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {
	my ($number_dialed) = @ARGV;
        my $AGI = new Asterisk::AGI;
        $AGI->exec("Set","CDR(userfield)=&IN_DID=$number_dialed");
        my (%output) = $AGI->ReadParse();
        my $config = {
                '_cti_obj' => $AGI,
                '_db' => 1
        };
        my %value_hash;
        my $default_values = {
                'timeout' => '3000',
                'timeout_count' => '2',
                'timeout_file' => undef,
                'timeout_max' => undef,
                'invalid_count' => '1',
                'invalid_file' => undef,
                'invalid_max' => undef
        };
        my $mem_obj = {
                'session_id' => $output{'uniqueid'},
                'did' => $did,
                'number_dialed' => $number_dialed,
                'count' => '0'
        };
         my $tablename = 'sunlight_call';
         my $value = 1;
         my $number = $mem_obj->{'number_dialed'};
         my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","amit1234");
         my $query = "update $tablename set status ='ANSWERED' where callerid = '$number'";
         my $sth = $dbh->prepare($query);
         $sth->execute();
         if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();

	my $function = "__welcome";
	my $loop = 1;
	do {
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
          		$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
        
       return -1;

}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        my $tablename = 'sunlight_call';
        my $callerid;
        my $prompt_id;
        my $unique_id;
        my $contactno = $mem_obj->{'number_dialed'};
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","amit1234");
        my $query = "select callerid,prompt_id,unique_id from $tablename where callerid = '$contactno' ";
        my $sth = $dbh->prepare($query) ;
        my $ret =$sth->execute();
        while(my @row = $sth->fetchrow_array()){
        $callerid         =      $row[0];
        $prompt_id        =      $row[1];
        $unique_id         =      $row[2];
        }
        $sth->finish();  #24/08/16
        $dbh->disconnect();
        $mem_obj->{'prompt_id'} = $prompt_id;
        $mem_obj->{'unique_id'} = $unique_id;
        my $AGI = new Asterisk::AGI;	
        my $asterisk_uniqueid = $AGI->get_variable('CDR(uniqueid)'); 
        $url ="http://172.20.120.105/13/sunlight/api/vday_response.php?callerid = $mem_obj->{'number_dialed'}&uniqueid= $mem_obj->{'unique_id'}&asterisk_uniqueid = $asterisk_uniqueid";
        $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        $ua = LWP::UserAgent->new();
        $response = $ua->request($request);
        $config->{_cti_obj}->exec("Playback","$prompt_id");
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/valentine/Prompt_8");
        $config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/valentine/songs");
        
}

main();
exit;
