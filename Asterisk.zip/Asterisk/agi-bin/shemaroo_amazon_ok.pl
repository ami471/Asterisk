#!/usr/bin/perl -w

BEGIN {
        unshift(@INC,'/uc/lib/modules/','/uc/lib/perl/');
#        print "@INC \n";
};

use Ivr::DialPlanApi;
use Asterisk::AGI;
use Config::INI::Reader;
use DBI;
use HTTP::Request;
use LWP::UserAgent;

sub main {

	my ($number_dialed) = @ARGV;
	my $AGI = new Asterisk::AGI;
	my (%output) = $AGI->ReadParse();
	my $config = {
		'_cti_obj' => $AGI,
		'_db' => 1
	};
		
	my %value_hash;
	my $file_name = "/uc/config/ini/shadi.conf";
	read_ini_file($file_name,\%value_hash);

	my $default_values = {
		'timeout' => '4000',
		'timeout_count' => '2',
		'timeout_file' => undef,
		'timeout_max' => undef,
		'invalid_count' => '2',
		'invalid_file' => undef,
		'invalid_max' => undef
                
	};
        my $mem_obj = {
		'callerid' => $output{'callerid'},
		'session_id' => $output{'uniqueid'},
		'number_dialed' => $number_dialed,
		'count' => '0',
		'dial_group' => "$value_hash{shadi}->{dial_group}",
		'dial_channel' => "$value_hash{shadi}->{dial_channel}",
		'dial_timeout' => "$value_hash{shadi}->{dial_timeout}",
		'callerid_out_1' => "$value_hash{shadi}->{escalate_number}",
                'callerid_out_2' => "$value_hash{shadi}->{escalate_number_2}",
                'callerid_out_3' => "$value_hash{shadi}->{escalate_number_3}",
		'dial_group_sec' => "$value_hash{shadi}->{dial_group_sec}"
	};
	
	my $tablename = 'shemaroo_amazon';
        my $value = 1;
        my $number = $mem_obj->{'number_dialed'};
	#===================Changes for 10 digit number====
	my $mobileno_length = length($mem_obj->{'number_dialed'});
        if ($mobileno_length > 10)
        {
                my $n = 2;
                $mem_obj->{'number_dialed'} = substr( "$mem_obj->{'number_dialed'}",$n);

        }
	#========================================================
        my $dbh = DBI->connect("dbi:mysql:database=asterisk;host=localhost","root","mys\@r0ja");
	my $query = "update $tablename set status ='ANSWERED' where callerid = '$number' order by callerid_count desc limit 1";
        my $sth = $dbh->prepare($query);
        $sth->execute();
        if ($sth->rows()) {

                $value =  0;

        }
        $sth->finish();
        $dbh->disconnect();

	my $dial_group = $mem_obj->{'dial_group'};
	my $dial_channel = $mem_obj->{'dial_channel'};
	my $timeout = $mem_obj->{'dial_timeout'};		
	my $function = "__language_selection";
	my $loop = 1;
	do {
		
		my ($next_action) = &{$function}($config,$default_values,$mem_obj);
		$AGI->exec("NoOP","Previous=$function===Next==$next_action");
		if ($next_action eq "exit") {
			$loop = 0;
		}
		$function = $next_action;

	} while ($loop);
	return -1;
}

sub read_ini_file {
		my ($filename,$hashref) = @_;
		my $tmphashref;
		$tmphashref = Config::INI::Reader->read_file($filename); 
		%{$hashref} = %{$tmphashref};
}

sub __language_selection{

        my ($config,$default_values,$mem_obj) = @_;
        my $lang = "ivr/ThinkWalnut/Shemaroo_amazon";
        $config->{_cti_obj}->exec("Set","CHANNEL(language)=$lang");
        return ("__welcome");

}


sub __welcome
{
	my ($config,$default_values,$mem_obj) = @_;
        my $callerid;
        my $coupon_code;

	my $contact_no = $mem_obj->{'number_dialed'};
#	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/Shemaroo_amazon/shemaoo");
#	my $url ="http://172.20.120.105/13/api/twd_get_misscall.php?c=$called_no&m=$contact_no";
        my $url ="http://180.179.103.253/13/shm/ivr_call.php?mdn=$contact_no";
        my $request = new HTTP::Request(POST => $url  );
        $request->content_type('application/x-www-form-urlencoded');
        my $ua = LWP::UserAgent->new();
        my $response = $ua->request($request);
        my ($sec,$min,$hour,$date,$mon,$year,$wday,undef,undef) = localtime();
        my $current_time = sprintf("%02d%02d%02d",$hour,$min,$sec);
        if ($response->is_success)
        {
                my $filename = '/var/log/asterisk/shemaroo_amazon.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is sucessful for $url and time is $current_time \n";
                close $fh;
	#	 return 1;

        }  else {

                my $status_lin = $response->status_code;
                my $filename = '/var/log/asterisk/shemaroo_amazon.txt';
                open(my $fh, '>>', $filename) or die "Could not open file '$filename' $!";
                print $fh "Response is unsucessful for $url and time is $current_time\n";
                close $fh;

         #        return -1;
        }

	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/Shemaroo_amazon/shemaoo");
	return "exit";
	
}

sub __play_again
{
	my ($config,$default_values,$mem_obj) = @_;
	my $coupon_code = $mem_obj->{'coupon_code'};
	$config->{_cti_obj}->exec("Playback","ivr/ThinkWalnut/H2H/H2H_Code");
	$config->{_cti_obj}->exec("SayDigits","$coupon_code");
	return "exit";
}




#=======================
main();
exit;
