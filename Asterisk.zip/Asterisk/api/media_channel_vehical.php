<?php 

$media_vehical_array = array();
$media_channel_of_vehical_array = array();

$media_vehical_array['AMARUJALA_NORTH_PRINT'] = 'Amar Ujala';
$media_vehical_array['BL_CO_CAMPAIGNS'] = 'BUSINESS LOAN';
$media_vehical_array['BTL_GL_IVR'] = 'BTL GOLD LOAN';
$media_vehical_array['BTL_GOLDLOAN'] = 'BTL GOLD LOAN';
$media_vehical_array['BTL_SOUTH1'] = 'BTL South1';
$media_vehical_array['BTL_SOUTH2'] = 'BTL South2';
$media_vehical_array['BTL_SOUTH3'] = 'BTL South3';
$media_vehical_array['DailyThanti_South2_Print'] = 'Daily Thanti';
$media_vehical_array['DAINIKBHASKARJABALPUR_WEST1_PR'] = 'DAINIK BHASKAR JABALPUR WEST1';
$media_vehical_array['DAINIKBHASKARJABALPUR_WEST2_PR'] = 'DAINIK BHASKAR JABALPUR WEST2';
$media_vehical_array['DAINIKBHASKAR_NORTH_PRINT'] = 'DAINIK BHASKAR(NORTH)';
$media_vehical_array['DAINIKBHASKAR_WEST2_PRINT'] = 'DAINIK BHASKAR(WEST2)';
$media_vehical_array['DAINIKJAGRAN_NORTH_PRINT'] = 'DAINIK JAGARAN';
$media_vehical_array['DAINIKJAGRAN_WEST2_PRINT'] = 'DAINIK JAGARAN';
$media_vehical_array['DIGITAL_SOUTH1'] = 'Digital_South1';
$media_vehical_array['DIGITAL_SOUTH2'] = 'Digital_South2';
$media_vehical_array['DIGITAL_SOUTH3'] = 'Digital_South3';
$media_vehical_array['DINAKARAN_SOUTH2_PRINT'] = 'DINAKARAN';
$media_vehical_array['DIVYABHASKAR_CENTRAL_PRINT'] = 'DIVYA BHASKAR';
$media_vehical_array['DIVYAMARATHI_WEST1_PRINT'] = 'DIVYA MARATHI';
$media_vehical_array['EENADU_PRINT'] = 'EENADU';
$media_vehical_array['GL_CO_CAMPAIGNS'] = 'GL Campaign-North';
$media_vehical_array['Single Interface'] = 'Single Interface';
$media_vehical_array['INSURANCE'] = 'INSURANCE';
$media_vehical_array['KalNirnay'] = 'KAALNIRNAY';
$media_vehical_array['LOKMAT_WEST1_PRINT'] = 'LOKMAT';
$media_vehical_array['Single Interface'] = 'Single Interface';
$media_vehical_array['NUKKAD'] = 'NUKKAD NAATAK ACTIVITY';
$media_vehical_array['OUTDOOR'] = 'OUTDOOR';
$media_vehical_array['OUTDOOR_SOUTH1'] = 'OUTDOOR SOUTH1';
$media_vehical_array['OUTDOOR_SOUTH3'] = 'OUTDOOR SOUTH3';
$media_vehical_array['PL_CO_CAMPAIGNS'] = 'PERSONAL LOAN';
$media_vehical_array['RADIO_SOUTH1'] = 'RADIO SOUTH1';
$media_vehical_array['RADIO_SOUTH3'] = 'RADIO SOUTH3';
$media_vehical_array['RAJASTHANPATRIKA_NORTH_PRINT'] = 'Rajasthan Patrika North';
$media_vehical_array['RAJASTHANPATRIKA_WEST2_PRINT'] = 'Rajasthan Patrika West2';
$media_vehical_array['SAKAL_WEST1_PRINT'] = 'SAKAL';
$media_vehical_array['SANDESH_CENTRAL_PRINT'] = 'SANDESH';
$media_vehical_array['SIP'] = 'SIP';
$media_vehical_array['TV_GOLDLOAN'] = 'TV Gold Loan';
$media_vehical_array['VIJAYAWANI_SOUTH1_PRINT'] = 'VIJAYVANI';
$media_vehical_array['VIJAYKARNATAKA_SOUTH1_PRINT'] = 'VIJAY KARNATAKA';
$media_vehical_array['GOLD LOAN WIN BACK'] = 'GOLD LOAN WIN BACK';

$media_channel_of_vehical_array['Amar Ujala'] = 'PRINT';
$media_channel_of_vehical_array['BUSINESS LOAN'] = 'BUSINESS LOAN';
$media_channel_of_vehical_array['BTL GOLD LOAN'] = 'BTL';
$media_channel_of_vehical_array['BTL GOLD LOAN'] = 'BTL';
$media_channel_of_vehical_array['BTL South1'] = 'BTL';
$media_channel_of_vehical_array['BTL South2'] = 'BTL';
$media_channel_of_vehical_array['BTL South3'] = 'BTL';
$media_channel_of_vehical_array['Daily Thanti'] = 'PRINT';
$media_channel_of_vehical_array['DAINIK BHASKAR JABALPUR WEST1'] = 'PRINT';
$media_channel_of_vehical_array['DAINIK BHASKAR JABALPUR WEST2'] = 'PRINT';
$media_channel_of_vehical_array['DAINIK BHASKAR(NORTH)'] = 'PRINT';
$media_channel_of_vehical_array['DAINIK BHASKAR(WEST2)'] = 'PRINT';
$media_channel_of_vehical_array['DAINIK JAGARAN'] = 'PRINT';
$media_channel_of_vehical_array['DAINIK JAGARAN'] = 'PRINT';
$media_channel_of_vehical_array['Digital_South1'] = 'DIGITAL';
$media_channel_of_vehical_array['Digital_South2'] = 'DIGITAL';
$media_channel_of_vehical_array['Digital_South3'] = 'DIGITAL';
$media_channel_of_vehical_array['DINAKARAN'] = 'PRINT';
$media_channel_of_vehical_array['DIVYA BHASKAR'] = 'PRINT';
$media_channel_of_vehical_array['DIVYA MARATHI'] = 'PRINT';
$media_channel_of_vehical_array['EENADU'] = 'PRINT';
$media_channel_of_vehical_array['GL Campaign-North'] = 'BTL';
$media_channel_of_vehical_array['INSURANCE'] = 'INSURANCE';
$media_channel_of_vehical_array['KAALNIRNAY'] = 'BTL';
$media_channel_of_vehical_array['LOKMAT'] = 'PRINT';
$media_channel_of_vehical_array['Single Interface'] = 'LOCAL SEO';
$media_channel_of_vehical_array['NUKKAD NAATAK ACTIVITY'] = 'BTL';
$media_channel_of_vehical_array['OUTDOOR'] = 'OUTDOOR';
$media_channel_of_vehical_array['OUTDOOR SOUTH1'] = 'OUTDOOR';
$media_channel_of_vehical_array['OUTDOOR SOUTH3'] = 'OUTDOOR';
$media_channel_of_vehical_array['PERSONAL LOAN'] = 'PERSONAL LOAN';
$media_channel_of_vehical_array['RADIO SOUTH1'] = 'RADIO';
$media_channel_of_vehical_array['RADIO SOUTH3'] = 'RADIO';
$media_channel_of_vehical_array['Rajasthan Patrika North'] = 'PRINT';
$media_channel_of_vehical_array['Rajasthan Patrika West2'] = 'PRINT';
$media_channel_of_vehical_array['SAKAL'] = 'PRINT';
$media_channel_of_vehical_array['SANDESH'] = 'PRINT';
$media_channel_of_vehical_array['SIP'] = 'SIP';
$media_channel_of_vehical_array['TV Gold Loan'] = 'TELEVISION';
$media_channel_of_vehical_array['VIJAYVANI'] = 'PRINT';
$media_channel_of_vehical_array['VIJAY KARNATAKA'] = 'PRINT';
$media_channel_of_vehical_array['GOLD LOAN WIN BACK'] = 'GOLD LOAN';

foreach ($media_vehical_array as $key => $value) {
	unset($media_vehical_array[$key]);
	$media_vehical_array[strtolower($key)] = strtolower($value);
}

foreach ($media_channel_of_vehical_array as $key => $value) {
	unset($media_channel_of_vehical_array[$key]);
	$media_channel_of_vehical_array[strtolower($key)] = strtolower($value);
}

?>
