<?php  
//include('../../ast_db.php');
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
include('../db.php');

$data['log'] = date('Y-m-d H:i:s');
$data['request_data'] = $_REQUEST;
$handle = fopen("log/missedCallApiCall.txt","a");
fwrite($handle,json_encode($data)."\n");
fclose($handle);

//function to send msg
function msgSend($msg,$mobileNo){
	/*
	//SENDING MSG HERE
	// Account details
	//$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	// Message details
	$numbers = urlencode($mobileNo);
	//$sender = urlencode('TXTLCL');
	$sender = urlencode('IIFLRA');
	$msg = urldecode($msg);
	$message = rawurlencode($msg); 
	// Prepare data for POST request
	//$data = 'apikey='.$apiKey.'&numbers='.$numbers."&sender=".$sender."&message=".$message;

	// Send the GET request with cURL
	//$ch = curl_init('https://api.textlocal.in/send/?'.$data);
	$api = "http://roundsms.com/api/sendhttp.php?authkey=ZTIzMTRjZmM3MzN&mobiles=$numbers&message=$message&sender=$sender&type=1&route=2";
	
	$ch = curl_init($api);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responce = curl_exec($ch);
	curl_close($ch);	
	*/
	
	$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	$numbers = array($mobileNo);
	$sender = urlencode('IIFLRA');
	$message = rawurlencode($msg); 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responce = curl_exec($ch);
	curl_close($ch);
	
	$log = date('Y-m-d H:i:s')."|".$msg."|".$mobileNo.'|'.trim($responce)."\n";
	$handle = fopen("log/msgSendLog.txt","a");
	fwrite($handle,$log);
	fclose($handle);
	
}//msgSend end 

function msgSendText($msg,$mobileNo){
	/*
	$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	//Message details
	$numbers = urlencode($mobileNo);
	//$sender = urlencode('TXTLCL');
	$sender = urlencode('IIFLRA');
	$msg = urldecode($msg);
	$message = rawurlencode($msg); 
	//Prepare data for POST request
	$data = 'apikey='.$apiKey.'&numbers='.$numbers."&sender=".$sender."&message=".$message;

	// Send the GET request with cURL
	$ch = curl_init('https://api.textlocal.in/send/?'.$data);
	//$api = "http://roundsms.com/api/sendhttp.php?authkey=ZTIzMTRjZmM3MzN&mobiles=$numbers&message=$message&sender=$sender&type=1&route=2";
	$ch = curl_init($api);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	$responce = curl_exec($ch);
	curl_close($ch);	
	*/
	
	$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	$numbers = array($mobileNo);
	$sender = urlencode('IIFLRA');
	$message = rawurlencode($msg); 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responce = curl_exec($ch);
	curl_close($ch);
	
	//wrting log here
	$log = date('Y-m-d H:i:s')."|".$msg."|".$mobileNo.'|'.trim($responce)."\n";
	$handle = fopen("log/msgSendLog.txt","a");
	fwrite($handle,$log);
	fclose($handle);
	//log end here
	//return $responce;
}//msgSend end

$mdn = urldecode($_REQUEST['caller_id']);
if (strlen($mdn)>10) {
	$mdn = substr($mdn,-10,strlen($mdn));
}

if ($mdn!='' && strlen($mdn)==10) {
	//$did = '8468008000';
	$did = urldecode($_REQUEST['dispnumber']);
	$did = substr($did,-10,strlen($did));
	$type = 1;
	if ($did=='8929136921' || $did=='8929136922')
	{
		$media_channel = 'MILAN FEEDBACK';
		$media_vehical = 'IIFL MILAN';
		$campaign = 'IIFL MILAN';
		$type = 2;
	}
	if ($did=='6364878224')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Vijay_Karnataka_South1';
		$campaign = 'Vijay_Karnataka_South1';
	}
	if ($did=='6364878225')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'VVijayawani_South1';
		$campaign = 'VVijayawani_South1';
	}
	if ($did=='6364878226')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Sakshi_South1';
		$campaign = 'Sakshi_South1';
	}
	if ($did=='6364878227')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Divya_Marathi_West1';
		$campaign = 'Divya_Marathi_West1';
	}
	if ($did=='6364878228')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Lokmat';
		$campaign = 'Lokmat';
	}
	if ($did=='6364878232')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Sakal_West1';
		$campaign = 'Sakal_West1';
	}
	if ($did=='6364878233')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Dainik_BhaskarJabalpur_West1';
		$campaign = 'Dainik_BhaskarJabalpur_West1';
	}
	if ($did=='6364878242')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Dainik_Bhaskar_West2';
		$campaign = 'Dainik_Bhaskar_West2';
	}
	if ($did=='6364878244')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Rajasthan_Patrika_West2';
		$campaign = 'Rajasthan_Patrika_West2';
	}
	if ($did=='6364878248')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Dainik_Bhaskar_Jabalpur_West2';
		$campaign = 'Dainik_Bhaskar_Jabalpur_West2';
	}
	if ($did=='6364878255')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'Dainik_Jagran_West2';
		$campaign = 'Dainik_Jagran_West2';
	}
	//2019-03-29
	if ($did=='8108103888')
	{
		$media_channel = 'Radio';
		$media_vehical = 'RADIO';
		$campaign = 'IIFL';
	}
	if ($did=='8108102888')
	{
		$media_channel = 'Television';
		$media_vehical = 'TELIVISION';
		$campaign = 'IIFL';
	}
	if ($did=='8108102555')
	{
		$media_channel = 'Print Newspaper';
		$media_vehical = 'PRINT';
		$campaign = 'IIFL';
	}
	if ($did=='8108105222')
	{
		$media_channel = 'IIFL Bonds 2020';
		$media_vehical = 'Tranche II';
		$campaign = 'Tranche II';
	}
	if ($did=='6391119111')
	{
		$media_channel = 'BTL';
		$media_vehical = 'BTL_MISSED';
		$campaign = 'IIFL';
	}
	if ($did=='8691911111')
	{
		$media_channel = 'Outdoor';
		$media_vehical = 'OUTDOOR_MISSED';
		$campaign = 'IIFL';
	}
	if ($did=='8652433344')
	{
		$media_channel = 'MISSED_EMAIL_SMS';
		$media_vehical = 'PL_CO_Campaigns';
		$campaign = 'IIFL';
		$type = 3;
	}
	if ($did=='8652407000')
	{
		$media_channel = 'MISSED_EMAIL_SMS';
		$media_vehical = 'BL_CO_Campaigns';
		$campaign = 'IIFL';
		$type = 4;
	}
	if ($did=='8652404000')
	{
		$media_channel = 'MISSED_EMAIL_SMS';
		$media_vehical = 'GL_CO_Campaigns';
		$campaign = 'IIFL';
		$type = 5;
	}
	if ($did=='8652433444')
	{
		$media_channel = 'MISSED_EMAIL_SMS';
		$media_vehical = 'Miscelleaneous_Co_Campaigns';
		$campaign = 'IIFL';
		$type = 6;
	}
	if ($did=='8828836111')
	{
		$media_channel = 'MISSED_EMAIL_SMS';
		$media_vehical = 'IIFL_EQUITY';
		$campaign = 'IIFL';
		$type = 7;
	}
	if ($did=='8828836333')
	{
		$media_channel = 'MISSED_EMAIL_SMS';
		$media_vehical = 'IIFL_MUTUALFUND';
		$campaign = 'IIFL';
		$type = 7;
	}
	if ($did=='9009070907')
	{
		$media_channel = 'KalNirnay';
		$media_vehical = 'KalNirnay';
		$campaign = 'IIFL';
		
	}
	
	if ($did=='7039001700')
	{
		$media_channel = 'IVR_EMAIL_SMS';
		$media_vehical = 'BL_CO_Campaigns';
		$campaign = 'IIFL';
		$type = 4;
	}
	
	//end
	$circle = urldecode($_REQUEST['circle_id']);
	$circle = strtoupper($circle);
	$datetime = urldecode($_REQUEST['end_time']);
	$date = date('Y-m-d',strtotime($datetime));
	$day = strtoupper(date('l',strtotime($date)));
	$timestamp = date('H:i:s',strtotime($datetime));
	$dayType_arr = array(0=>'WEEKOFF',1=>'WEEKDAY',2=>'WEEKDAY',3=>'WEEKDAY',4=>'WEEKDAY',5=>'WEEKDAY',6=>'WEEKOFF');
	$dayType = $dayType_arr[date('w',strtotime($date))];	

	$time = date("H",strtotime($datetime));
	$time_session = '';
	if ($time < "12") {
	    $time_session = "MORNING";
	} else if ($time >= "12" && $time < "17") {
	    $time_session = "AFTERNOON";
	} else if ($time >= "17" && $time < "19") {
	    $time_session = "EVENING";
	} else if ($time >= "19") {
	    $time_session = "NIGHT";
	}
	$did2 = "91$did";
	//echo "mdn=$mdn day =$day did=$did media_channel=$media_channel media_vehical=$media_vehical campaign=$campaign circle=$circle date=$date timestamp=$timestamp dayType=$dayType time_session=$time_session";
	$sql = "INSERT INTO mediamissed_calling(mobno,status,did,media_channel,media_vehicle,day,weekday,date,time,Time_Session,campaign,circle,type) VALUES('$mdn','NOANSWER','$did2','$media_channel','$media_vehical','$day','$dayType','$date','$timestamp','$time_session','$campaign','$circle','$type')";
	//exit();
	$res = mysqli_query($con,$sql);
	if ($res) {
		if ($did=='8929136921') {
			//$msg = urlencode("Thank you for attending IIFL Milan. We appreciate your feedback and support. We will come back with new themes/topics for the upcoming IIFL Milan.");
			$msg = "Thank you for attending IIFL Milan. We appreciate your feedback and support. We will come back with new themes/topics for the upcoming IIFL Milan.";
			//$msg = "Thank you for supporting 'NO SMOKING' campaign initiated by IIFL under it's Community connect program- IIFL Milan.";
		}
		if ($did=='8929136922') {
			//$msg = urlencode("Thank you for attending IIFL Milan. We appreciate your feedback. We will connect with you shortly to understand and improvise our upcoming IIFL Milan.");
			//$msg = "Thank you for attending IIFL Milan. We appreciate your feedback. We will connect with you shortly to understand and improvise our upcoming IIFL Milan.";
			$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		//added on 2019-03-01
		if ($did=='8108102888') {			
			$msg = "Thank you for your interest in IIFL Gold Loan. Our representative will call you back shortly. To know more about IIFL, visit iifl.com";
		}
		if ($did=='8108103888') {			
			$msg = "Thank you for your interest in IIFL Gold Loan. Our representative will call you back shortly. To know more about IIFL, visit iifl.com";
		}
		if ($did=='6391119111') {			
			$msg = "Thank you for your interest in IIFL Gold Loan. Our representative will call you back shortly. To know more about IIFL, visit iifl.com";
		}
		if ($did=='8108102555') {			
			$msg = "Thank you for your interest in IIFL Gold Loan. Our representative will call you back shortly. To know more about IIFL, visit iifl.com";
		}
		if ($did=='8691911111') {			
			$msg = "Thank you for your interest in IIFL Gold Loan. Our representative will call you back shortly. To know more about IIFL, visit iifl.com";
		}
		if ($did=='8652433344') {			
			$msg = "Thank you for your interest in IIFL Personal Loan. Our representative will contact shortly. To know more about IIFL, visit iifl.com";
		}
		if ($did=='8652407000') {			
			$msg = "Thank you for your interest in IIFL Business Loan. Our representative will contact shortly. To know more about IIFL, visit iifl.com";
		}
		if ($did=='7039001700') {			
			$msg = "Dear Customer, we acknowledge your request to opt out of Moratorium on your IIFL Loan A/C. Your bank account will shortly be debited against payment of your outstanding loan EMI. Maintain sufficient funds in your account to avoid additional charges, if any.";
		}
		if ($did=='8652404000') {			
		//	$msg = "Thank you for your interest in IIFL Gold Loan. Our representative will contact shortly. To know more about IIFL, visit iifl.com";
			$msg = "Thank you for your interest in IIFL products & services. Our expert will call you shortly. In case you wish to visit your nearest IIFL Branch, Click bit.ly/2A2ckXE to locate branch";
		}
		if ($did=='8652433444') {			
			//$msg = "Thank you for your interest in IIFL's products & services. Our representative will contact you shortly. Know more about IIFL at iifl.com";
			$msg = "Thank you for your interest in IIFL products & services. Our expert will call you shortly. In case you wish to visit your nearest IIFL Branch, Click bit.ly/2A2ckXE to locate branch";
		}
		if ($did=='8108105222'){			
			$msg = "Thank you for your interest in IIFL Bonds. Our investment expert will get in touch with you shortly. For more details on IIFL Bonds, visit www.iifl.com/bonds";
			//$msg = "Thank you for your interest in IIFL's products & services. Our representative will contact you shortly. Know more about IIFL at iifl.com";
		}

		if ($did=='6364878232') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878233') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}

		if ($did=='6364878242') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878244') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878248') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878255') {			
			//$msg = "Thank you for your interest in IIFL Bonds. Our investment expert will get in touch with you shortly. For more details on IIFL Bonds, visit www.iifl.com/bonds";
		}
		if ($did=='9730641180') {			
			$msg = "Hi This is Nancy. Plant digital Assistant. Welcome to ABB Hacksummit 2019. Thanks for visiting me.";
		}
		if($did=='8108102888' || $did=='8108103888' || $did=='6391119111' || $did=='8108102555' || $did=='8691911111')
		{
			//msgSendText($msg,$mdn);
			 msgSend($msg,$mdn);
		}
		if($did=='8652407000' || $did=='02261218635')
		{
			// msgSendText($msg,$mdn);
			 msgSend($msg,$mdn);
		}
		if($did=='8652433444' || $did=='8652404000'){
			msgSendText($msg,$mdn);
			// msgSend($msg,$mdn);
		}
		if ($did=='8108105222')
		{
			msgSend($msg,$mdn);
			//msgSendText($msg,$mdn);
		}
		if ($did=='7039001700')
		{
			msgSend($msg,$mdn);
			//msgSendText($msg,$mdn);
		}
		if($did=='8929136922' || $did=='8929136921'){
			//msgSendText($msg,$mdn);
			 msgSend($msg,$mdn);
			echo "successfull";
		}else{
			echo "Error : Unknown DID No.";
		}
 		$source = "Print%20Newspaper";
		//sending curl to iifl
		//$curlUrl = "https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=Rubic&ivr_nbr=91$did&Mobile=".$mdn."&call_time=".$date."&circle=".urlencode($circle)."&LeadSubSource=print&Campaign=".urlencode($campaign);
		

		$curlUrl = "https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=".urlencode($media_channel)."&ivr_nbr=91$did&Mobile=".$mdn."&call_time=".$date."&circle=".urlencode($circle);

		
		// $url = "https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=Rubic&ivr_nbr=916364878224&Mobile=9734581754&call_time=2018-05-02&circle=mumbai&leadowner=C154454&LeadStatus=FreshLead&Email=zaidabuhhijk@iifl.com&Campaign=Vijay_Karnataka_South1&LeadSubSource=Divya&BranchCode=BM123&ZipCode=400058&City=Mumbai&State=Maharashtra&Country=India&Address=Paaneri andheri west&Phone=23264534";
		$ch = curl_init($curlUrl);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$responce = curl_exec($ch);
		curl_close($ch);

		$hadle = fopen("log/iiflCurlSendLog.txt",'a');
		$iiflCurlSendLog = date('Y-m-d H:i:s')."|".$curlUrl."|".$responce."\n";
		fwrite($hadle,$iiflCurlSendLog);
		fclose($hadle);
		//sending curl iifl end here
	}
}else{
	echo "not valid mdn";
}
//going to insert data here

?>
