<?php  
	include('../db.php');

	if(!empty($_GET['st_dt']) && !empty($_GET['en_dt'])){
		$st_dt = $_GET['st_dt'];
		$en_dt = $_GET['en_dt'];
	}else{
		$st_dt = date('Y-m-01');
		$en_dt = date('Y-m-d');
	}
	
	$filter = " AND date(rcvd) between '".$st_dt."' and '".$en_dt."' ";

	$sql = "SELECT sender, keyword, content, rcvd FROM iifl_gold_loan_receive_msg WHERE 1=1 $filter ORDER BY rcvd DESC";
	$res = mysqli_query($con,$sql);

	$text = "CallerId,Key,Message Content,Received\n";
	while($row = mysqli_fetch_assoc($res)){
		$text.=$row['sender'].',';
		$text.=$row['keyword'].',';
		$text.=$row['content'].',';
		$text.=$row['rcvd']."\n";
	}

	$filename = 'receive_msg_'.$st_dt.'_to_'.$en_dt.'.csv';
	header('Content-Type: application/csv');
	header('Content-Disposition: attachment; filename='.$filename);
	header('Pragma: no-cache');
	echo $text;
?>