<?php 
ini_set('max_execution_time', '0'); // for infinite time of execution 
include('../db.php');
include('media_channel_vehical.php');

$i = 1;
$str = "SELECT id,media_channel,media_vehicle FROM `iifl_customer_detail`";
$raw = mysqli_query($con,$str);
while ($res = mysqli_fetch_assoc($raw)) {
	$id = $res['id'];
	$media_channel = trim($res['media_channel']);
	$media_vehicle = trim($res['media_vehicle']);
	$vehical = strtoupper($media_vehical_array[strtolower($media_vehicle)]);
	$channel = strtoupper($media_channel_of_vehical_array[strtolower($vehical)]);
	$update = "UPDATE iifl_customer_detail SET channel='".$channel."',vehical='".$vehical."' where id='".$id."'";
	$up_res = mysqli_query($con,$update);
	echo "$i | ";
	$i++;
	//echo "id = $id | media_channel = $media_channel | media_vehicle = $media_vehicle | channel = $channel | vehical = $vehical<br>";
}


?>