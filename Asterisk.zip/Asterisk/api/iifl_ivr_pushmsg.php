<?php 
date_default_timezone_set("Asia/Calcutta");
include('../db.php');
$data = $_SERVER['REQUEST_URI'];
$data_exp = explode("?",$data);
$data = $data_exp[1];

$type = $_REQUEST['type'];
$callerNo = $_REQUEST['callerNo'];
$time = $_REQUEST['time'];
$toSend = $_REQUEST['toSend'];
$spokenTo = $_REQUEST['spokenTo'];
$name = $_REQUEST['name'];
$pin  = $_REQUEST['pin'];
$timestamp = date('Y-m-d H:i:s');
$phoneno = "02268258310";
function msgSend($msg,$mobileNo){
	/*
	$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	// Message details
	$numbers = urlencode($mobileNo);
	//$sender = urlencode('TXTLCL');
	$sender = urlencode('IIFLRA');
	$msg = urldecode($msg);
	$message = rawurlencode($msg); 
	// Prepare data for POST request
	$data = 'apikey='.$apiKey.'&numbers='.$numbers."&sender=".$sender."&message=".$message;

	$ch = curl_init('https://api.textlocal.in/send/?'.$data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responce = curl_exec($ch);
	curl_close($ch);	
	*/

	$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	$numbers = array($mobileNo);
	$sender = urlencode('IIFLRA');
	$message = rawurlencode($msg); 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responce = curl_exec($ch);
	curl_close($ch);

	//wrting log here
	$log = date('Y-m-d H:i:s')."|".$msg."|".$mobileNo.'|'.$responce."\n\n";
	$handle = fopen("log/msgSendLog.txt","a");
	fwrite($handle,$log);
	fclose($handle);
	//log end here

	return $responce;
}

function createLog($log,$timestamp){
	//creating log here
	$handle = fopen("log/msgPushTypeLog.txt","a");
	fwrite($handle,$log);
	fclose($handle);
}

if ($type==1) {
	//$msg = "Product Gold Loan. Called at $time Not connected. Phone No.$callerNo. Please call back within 30 minutes";
	//$msg = "Product:Gold Loan. Called at $time. Not connected mobile no $callerNo. Please callback in 30 min. IIFL Finance";
        $msg = "Product: Gold Loan. Called at $time. Not connected. mobile no $callerNo. Please call back in 30 min. IIFL Finance";
 $responce = msgSend($msg,$toSend);	
	$log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
	createLog($log,$timestamp);
	//inserting into database 
	$sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
	mysqli_query($con,$sql);
	//if($res){
		echo "successfull";
	//}else{
	//	echo "failed";
	//}
	//inserting into database end 
}

if ($type==2) {
	$msg = "Sorry, we are not able to connect to an IIFL official at this moment.We shall call you back shortly. Thank you.";
	$responce = msgSend($msg,$toSend);	
	$log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
	createLog($log,$timestamp);
	//inserting into database 
	$sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
	$res = mysqli_query($con,$sql);
	//if($res){
		echo "successfull";
	//}else{
	//	echo "failed";
	//}
	//inserting into database end 
}

if ($type==3) {
	//$msg = "You just spoke to $name from IIFL at $spokenTo. Hopeyou had a satisfactory conversation.";
	$msg = "You just spoke to $name from IIFL at $spokenTo .Hope you had a satisfactory conversation.";
	$responce = msgSend($msg,$toSend);	
	$log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
	createLog($log,$timestamp);
	//inserting into database 
	$sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
	mysqli_query($con,$sql);
	//if($res){
		echo "successfull";
	//}else{
	//	echo "failed";
	//}
	//inserting into database end 
}

if ($type==4) {
	//$msg = "You just spoke to a Gold Loan prospect at $spokenTo. Hope you had a satisfactory conversation.";
	$msg = "You just spoke to a Gold Loan prospect at $spokenTo.Hope you had a satisfactory conversation.";
	$responce = msgSend($msg,$toSend);	
	$log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
	createLog($log,$timestamp);
	//inserting into database 
	$sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
	mysqli_query($con,$sql);
	//if($res){
		echo "successfull";
	///}else{
		//echo "failed";
	//}
	//inserting into database end 
}

if ($type==5) {
	//$msg = "You just spoke to a Gold Loan prospect at $spokenTo. Hope you had a satisfactory conversation.";
	$msg = "Sorry this pincode is not correct. You have exceeded your maximum attempts. Our representative will call you back shortly. Thank you.";
	$responce = msgSend($msg,$toSend);	
	$log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
	createLog($log,$timestamp);
	//inserting into database 
	$sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
	mysqli_query($con,$sql);
	//if($res){
		echo "successfull";
	///}else{
		//echo "failed";
	//}
	//inserting into database end 
}

if ($type==6) {
	//$msg = "You just spoke to a Gold Loan prospect at $spokenTo. Hope you had a satisfactory conversation.";
	$msg = "You just spoke to IIFL Gold Loan prospect. You can speak on $spokenTo for further requirements.";
	$responce = msgSend($msg,$toSend);	
	$log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
	createLog($log,$timestamp);
	//inserting into database 
	$sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
	mysqli_query($con,$sql);
	//if($res){
		echo "successfull";
	///}else{
		//echo "failed";
	//}
	//inserting into database end 
}

if ($type==7) {
	$msg = "Sorry, we are unable to connect your call right now. We shall call you back shortly. Or, you may call $name at $spokenTo . IIFL Finance";
	//$msg = "Sorry, we are not able to connect to an IIFL official at this moment. We shall call you back shortly. Thank you.";
	$responce = msgSend($msg,$toSend);	
	$log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
	createLog($log,$timestamp);
	//inserting into database 
	$sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
	mysqli_query($con,$sql);
	//if($res){
		echo "successfull";
	///}else{
		//echo "failed";
	//}
	//inserting into database end 
}

if ($type==8) {
   //  $msg = "You just spoke to $name from IIFL. You can speak on $spokenTo for further requirements.";
     $msg = "You just spoke to $name from IIFL Finance at $spokenTo . Hope you had a satisfactory conversation. IIFL Finance";
    $responce = msgSend($msg,$toSend);    
    $log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
    createLog($log,$timestamp);
    //inserting into database 
    $sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
    mysqli_query($con,$sql);
    //if($res){
        echo "successfull";
    ///}else{
        //echo "failed";
    //}
    //inserting into database end 
}

if ($type==9) {
     $msg = "Sorry, we are not able to connect to IIFL representative at this moment. We shall call you back shortly. Thank you.";
    $responce = msgSend($msg,$toSend);    
    $log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
    createLog($log,$timestamp);
    //inserting into database 
    $sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
    mysqli_query($con,$sql);
    //if($res){
        echo "successfull";
    ///}else{
        //echo "failed";
    //}
    //inserting into database end 
}

if ($type==10) {
     //$msg = "You just spoke to a Gold Loan prospect. You can speak with him on $spokenTo for further requirements.";
     $msg = "You just spoke to a Gold Loan prospect. You can speak with him on $spokenTo for further requirements. IIFL Finance";
    $responce = msgSend($msg,$toSend);    
    $log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
    createLog($log,$timestamp);
    //inserting into database 
    $sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
    mysqli_query($con,$sql);
    //if($res){
        echo "successfull";
    ///}else{
        //echo "failed";
    //}
    //inserting into database end 
}

if ($type==11) {
     $msg = "Thank you for your interest in IIFL products & services. Our expert will call you shortly. In case you wish to visit your nearest IIFL Branch, Click bit.ly/2A2ckXE to locate branch";
    $responce = msgSend($msg,$toSend);    
    $log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
    createLog($log,$timestamp);
    //inserting into database 
    $sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
    mysqli_query($con,$sql);
    //if($res){
        echo "successfull";
    ///}else{
        //echo "failed";
    //}
    //inserting into database end 
}

if ($type==12) {
	//$msg = "Product Gold Loan. Called at $time Not connected. Phone No.$callerNo. Please call back within 30 minutes";
	$msg = "You have missed the call from our customer.Please callback at $phoneno PIN: $pin within 30 min.";
	$responce = msgSend($msg,$toSend);	
	$log = $type.'|'.$toSend.'|'.$callerNo.'|'.$time.'|'.$msg.'|'.$data.'|'.$responce.'|'.$timestamp."\n";
	createLog($log,$timestamp);
	//inserting into database 
	$sql = "INSERT INTO `iifl_ivr_msg_master`(`type`, `to_send_no`, `caller_no`, `timestamp`, `msg`, `data_reached`, `responce`, `created_on`) VALUES ('$type','$toSend','$callerNo','$time','$msg','$data','$responce','$timestamp')";
	mysqli_query($con,$sql);
	//if($res){
		echo "successfull";
	//}else{
	//	echo "failed";
	//}
	//inserting into database end 
}

?>
