<?php  
//include('../../ast_db.php');
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
include('../db.php');
//function to send msg
function msgSend($msg,$mobileNo){
	//SENDING MSG HERE
	// Account details
	//$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	// Message details
	$numbers = urlencode($mobileNo);
	//$sender = urlencode('TXTLCL');
	$sender = urlencode('IIFLRA');
	$msg = urldecode($msg);
	$message = rawurlencode($msg); 
	// Prepare data for POST request
	//$data = 'apikey='.$apiKey.'&numbers='.$numbers."&sender=".$sender."&message=".$message;

	// Send the GET request with cURL
	//$ch = curl_init('https://api.textlocal.in/send/?'.$data);
	$api = "http://roundsms.com/api/sendhttp.php?authkey=ZTIzMTRjZmM3MzN&mobiles=$numbers&message=$message&sender=$sender&type=1&route=2";
	$ch = curl_init($api);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responce = curl_exec($ch);
	curl_close($ch);	
	//Process your response here
	//SENDING MSG END HERE

	//wrting log here
	$log = date('Y-m-d H:i:s')."|".$msg."|".$mobileNo.'|'.trim($responce)."\n";
	$handle = fopen("log/msgSendLog.txt","a");
	fwrite($handle,$log);
	fclose($handle);
	//log end here
	//return $responce;
}//msgSend end 

function msgSendText($msg,$mobileNo){
	$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	//Message details
	$numbers = urlencode($mobileNo);
	//$sender = urlencode('TXTLCL');
	$sender = urlencode('IIFLRA');
	$msg = urldecode($msg);
	$message = rawurlencode($msg); 
	//Prepare data for POST request
	$data = 'apikey='.$apiKey.'&numbers='.$numbers."&sender=".$sender."&message=".$message;

	// Send the GET request with cURL
	$ch = curl_init('https://api.textlocal.in/send/?'.$data);
	//$api = "http://roundsms.com/api/sendhttp.php?authkey=ZTIzMTRjZmM3MzN&mobiles=$numbers&message=$message&sender=$sender&type=1&route=2";
	//$ch = curl_init($api);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$responce = curl_exec($ch);
	curl_close($ch);	
	//Process your response here
	//SENDING MSG END HERE

	//wrting log here
	$log = date('Y-m-d H:i:s')."|".$msg."|".$mobileNo.'|'.trim($responce)."\n";
	$handle = fopen("log/msgSendLog.txt","a");
	fwrite($handle,$log);
	fclose($handle);
	//log end here
	//return $responce;
}//msgSend end

$mdn = urldecode($_REQUEST['caller_id']);
if (strlen($mdn)>10) {
	$mdn = substr($mdn,-10,strlen($mdn));
}

if ($mdn!='' && strlen($mdn)==10) {
	//$did = '8468008000';
	$did = urldecode($_REQUEST['dispnumber']);
	$did = substr($did,-10,strlen($did));
	$media_channel = 'MILAN FEEDBACK';
	$media_vehical = 'IIFL MILAN';
	$campaign = 'IIFL MILAN';
	$circle = urldecode($_REQUEST['circle_id']);
	$circle = strtoupper($circle);
	$datetime = urldecode($_REQUEST['end_time']);
	$date = date('Y-m-d',strtotime($datetime));
	$day = strtoupper(date('l',strtotime($date)));
	$timestamp = date('H:i:s',strtotime($datetime));
	$dayType_arr = array(0=>'WEEKOFF',1=>'WEEKDAY',2=>'WEEKDAY',3=>'WEEKDAY',4=>'WEEKDAY',5=>'WEEKDAY',6=>'WEEKOFF');
	$dayType = $dayType_arr[date('w',strtotime($date))];	

	$time = date("H",strtotime($datetime));
	$time_session = '';
	if ($time < "12") {
	    $time_session = "MORNING";
	} else if ($time >= "12" && $time < "17") {
	    $time_session = "AFTERNOON";
	} else if ($time >= "17" && $time < "19") {
	    $time_session = "EVENING";
	} else if ($time >= "19") {
	    $time_session = "NIGHT";
	}
	$did2 = "91$did";
	//echo "mdn=$mdn day =$day did=$did media_channel=$media_channel media_vehical=$media_vehical campaign=$campaign circle=$circle date=$date timestamp=$timestamp dayType=$dayType time_session=$time_session";
	$sql = "INSERT INTO mediamissed_calling(mobno,status,did,media_channel,media_vehicle,day,weekday,date,time,Time_Session,campaign,circle) VALUES('$mdn','NOANSWER','$did2','$media_channel','$media_vehical','$day','$dayType','$date','$timestamp','$time_session','$campaign','$circle')";
	//exit();
	$res = mysqli_query($con,$sql);
	if ($res) {
		if ($did=='8929136921') {
			//$msg = urlencode("Thank you for attending IIFL Milan. We appreciate your feedback and support. We will come back with new themes/topics for the upcoming IIFL Milan.");
			$msg = "Thank you for attending IIFL Milan. We appreciate your feedback and support. We will come back with new themes/topics for the upcoming IIFL Milan.";
		}
		if ($did=='8929136922') {
			//$msg = urlencode("Thank you for attending IIFL Milan. We appreciate your feedback. We will connect with you shortly to understand and improvise our upcoming IIFL Milan.");
			//$msg = "Thank you for attending IIFL Milan. We appreciate your feedback. We will connect with you shortly to understand and improvise our upcoming IIFL Milan.";
			$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		//added on 2019-03-01
		if ($did=='6364878224') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878225') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878226') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878227') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878228') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878232') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878233') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}

		if ($did=='6364878242') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878244') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878248') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}
		if ($did=='6364878255') {			
			//$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
		}

		if($did=='8929136922' || $did=='8929136921' || $did=="6364878224" || $did=="6364878225" || $did=="6364878226" || $did=="6364878227" || $did=="6364878228" || $did=="6364878232" || $did=="6364878233" || $did=="6364878242" || $did=="6364878244" || $did=="6364878248" || $did=="6364878255"){
			msgSendText($msg,$mdn);
			echo "successfull";
		}else{
			echo "Error : Unknown DID No.";
		}

		//sending curl to iifl
		$curlUrl = "https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/SourceMethod?source=ncd&ivr_nbr=91$did&Mobile=".$mdn."&call_time=".$date."&circle=".urlencode($circle);		
		$ch = curl_init($curlUrl);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$responce = curl_exec($ch);
		curl_close($ch);

		$hadle = fopen("log/iiflCurlSendLog.txt",'a');
		$iiflCurlSendLog = date('Y-m-d H:i:s')."|".$curlUrl."|".$responce."\n";
		fwrite($hadle,$iiflCurlSendLog);
		fclose($hadle);
		//sending curl iifl end here
	}
}else{
	echo "not valid mdn";
}
//going to insert data here

?>
