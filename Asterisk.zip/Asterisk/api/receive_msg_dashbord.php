<?php
	include('../db.php');

	if(!empty($_POST['st_dt']) && !empty($_POST['en_dt'])){
		$st_dt = $_POST['st_dt'];
		$en_dt = $_POST['en_dt'];
	}else{
		$st_dt = date('Y-m-01');
		$en_dt = date('Y-m-d');
	}
	
	$filter = " AND date(rcvd) between '".$st_dt."' and '".$en_dt."' ";

	$sql = "SELECT sender, keyword, content, rcvd FROM iifl_gold_loan_receive_msg WHERE 1=1 $filter ORDER BY rcvd DESC";
	$res = mysqli_query($con,$sql);
	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>IIFL GOLd LOAN RECEIVE MESSAGE</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<style type="text/css">
	thead{
		background-color: darkgrey;
    	color: white;
	}
</style>
<body>
	<div class="container">
		<form action="" method="post">
			<div class="row">
				<div class="col-sm-6">
					<h3>Gold Loan Receive Message Dashboard</h3>
				</div>
				<div class="col-sm-2">
					<!-- <h3> -->
						<label>Start Date:</label>
						<input class="form-control" type="text" name="st_dt" id="st_dt" value="<?php echo $st_dt; ?>">			
					<!-- </h3>				 -->
				</div>
				<div class="col-sm-2">
					<!-- <h3> -->
						<label>End Date:</label>
						<input class="form-control" type="text" name="en_dt" id="en_dt" value="<?php echo $en_dt; ?>">								
					<!-- </h3>				 -->
				</div>
				<div class="col-sm-2">
					<h3>
						<input type="submit" name="submit" class="btn btn-primary" value="filter">					
					</h3>
				</div>
			</div>
		</form>		
		
		<br>
		<table class="table table-bodered">
			<thead>
				<tr>
					<th colspan="4"><a href="receive_msg_dashboard_csv.php?st_dt=<?php echo $st_dt; ?>&en_dt=<?php echo $en_dt; ?>" class="btn btn-primary btn-sm">Download</a></th>
				</tr>
				<tr>
					<th>CallerId</th>
					<th>Key</th>
					<th>Message Content</th>
					<th>Received</th>
				</tr>
			</thead>
			<tbody>
				<?php
				while($row = mysqli_fetch_assoc($res)){
				?>
				<tr>
					<td><?php echo $row['sender']; ?></td>
					<td><?php echo $row['keyword']; ?></td>
					<td><?php echo $row['content']; ?></td>
					<td><?php echo $row['rcvd']; ?></td>
				</tr>
				<?php
				}				
				?>
				
			</tbody>
		</table>
	</div>
<script type="text/javascript">
  $( function() {
    $( "#st_dt" ).datepicker({
	  dateFormat: "yy-mm-dd"
	});
    $( "#en_dt" ).datepicker({
	  dateFormat: "yy-mm-dd"
	});
  } );
</script>	
</body>
</html>