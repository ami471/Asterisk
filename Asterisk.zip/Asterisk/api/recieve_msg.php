<?php
error_reporting(0);
ini_set('max_execution_time', '30');
date_default_timezone_set("Asia/Calcutta");
include('../db.php');
//Find first name mobile and phone here

// $post_data = json_decode('{"sender":"918369854211","content":"Refer Anand 9370517503","inNumber":"919220592205","submit":"Submit","network":"","email":"none","keyword":"REFER","comments":"Anand 9370517503","credits":"39263","msgId":"8060965094","rcvd":"2021-05-22 16:10:35","firstname":"","lastname":"","custom1":"","custom2":"","custom3":""}',true);

$post_data = $_POST;
$conuntry_code = '91';
$phone = $post_data['sender'];
$content = strtolower($post_data['content']);
if(strlen($phone)==12){
	$phone = substr($phone,2,10);
}

$valid = 0;
$valid = empty($content)?1:0;
$valid = !preg_match( '/refer/',$content)?1:0;
$invalid_reason = !preg_match( '/refer/',$content)?'Refer not contains':'';

//Find name and mobile number
$mobile = '';
$firstname = '';
$content = trim(str_replace("refer",'',$content));
if(preg_match( '/ /',$content)){
	$content_arr = explode(" ",$content);
	//Added on 2021/06/03 | RANG
	$name_concat = '';

	foreach ($content_arr as $key => $value) {
		if(is_numeric($value)){
			$mobile = $value;
		}else{
			$name_concat.=$value.' ';
		}	
	}
	$firstname = rtrim($name_concat,' ');
	//End of 2021-06-03
	
	// if(is_numeric($content_arr[0])){
	// 	$mobile = $content_arr[0];
	// 	$firstname = $content_arr[1];
	// }else{
	// 	$mobile = $content_arr[1];
	// 	$firstname = $content_arr[0];
	// }
}else{
	$phone_2 = substr($content,0,11);
	$phone_1 = substr($content,0,10);
	$phone_3 = substr($content,(strlen($content))-10,10);
	$phone_4 = substr($content,(strlen($content))-11,11);
	
	// echo "$phone_1 | $phone_2 | $phone_3 | $phone_4";exit;
	if(is_numeric($phone_2)){
		$mobile = $phone_2;
		$firstname = substr($content,11);
	}elseif(is_numeric($phone_1)){
		$mobile = $phone_1;
		$firstname = substr($content,10);
	}elseif(is_numeric($phone_4)){
		$mobile = $phone_4;
		$firstname = substr($content,0,(strlen($content))-11);
	}elseif(is_numeric($phone_3)){
		$mobile = $phone_3;
		$firstname = substr($content,0,(strlen($content))-10);
	}else{
		$valid = 1;
		$invalid_reason = 'Invalid Mobile number found';
	}

	if(strlen($mobile)==11){
		$phone_first = substr($mobile,0,1);
		if($phone_first!=0){
			$valid = 1;
			$invalid_reason = 'Invalid Mobile number found | First digit should be zero if number is 11 digits';
		}
	}

	if(preg_match( '/^\d+/',$firstname)){
		$valid = 1;
		$invalid_reason = 'Invalid firstname | firstname should be string only';
	}

	$firstname = ucfirst($firstname);
}
// echo "$firstname | refer - $mobile | sender-$phone";exit;
//Find mobile number and firstnameend here

$log = array();
$log['timestamp'] = date('Y_m_d_h_i_s');
$log['request_data'] = $post_data;
$log['is_valid_data'] = $valid==1?false:true;
$log['invalid_reason'] = $invalid_reason;
$handle_1 = fopen("log/gold_loan_request_log_".date('Y_m').".txt", 'a');
fwrite($handle_1,json_encode($log)."\n");
fclose($handle_1);

//insert into db
$content = $log;
$sql = "INSERT INTO `iifl_gold_loan_receive_msg`( `sender`, `content`, `inNumber`, `keyword`, `comments`, `rcvd`,`invalid_reason`, `is_valid_data`) VALUES ('".$phone."','".$content['request_data']['content']."','".$content['request_data']['inNumber']."','".$content['request_data']['keyword']."','".$content['request_data']['comments']."','".$content['request_data']['rcvd']."','".$content['request_data']['invalid_reason']."','".$content['is_valid_data']."')";
mysqli_query($con,$sql);
//db end
if($valid!=0){
	exit;
}
//End of first name mobile and phone here

//get Token
	// $token_url = 'https://ttavatar.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/Token';//UAT
	$token_url = 'https://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/Token';//Production
	$data = array('UserID' => '8A58D57E1A9E43A5');

	$postdata = json_encode($data);

	$ch = curl_init($token_url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	$result = curl_exec($ch);
	curl_close($ch);
	
	//Store into log file.
	$log = array();
	$log['timestamp'] = date('Y_m_d_h_i_s');
	$log['send_data'] = $data;
	$log['recieved_data'] = json_decode($result,true);
	$handle_2 = fopen("log/gold_loan_request_token_log_".date('Y_m').".txt", 'a');
	fwrite($handle_2,json_encode($log)."\n");
	fclose($handle_2);
	//End of log

	$result = json_decode($result,true);
	$token = $result['Body']['Token'];

//End of get Token

//Save Lead
	// $lead_save_url = 'http://ttavatar.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/Save';//UAT
	$lead_save_url = 'http://crm.iifl.in/ZohoCRMAPI/api/ZohoCRMWebAPI/Save';//Production

	// $firstName = 'ZaidizTest';
	// $mobile = '9852456352';
	// $phone = '9852456354';
	$firstName =  $firstname;
	
	// $mobile = $phone;
	// $phone = $mobile;

	$data_to_save = array();
	$data_to_save['Token']= $token;
	$data_to_save['ObjectName']= 'Lead';
	$data_to_save['Parameters']['FirstName']= $firstName;
	$data_to_save['Parameters']['LastName']= 'LName';
	$data_to_save['Parameters']['LeadProduct']= 'Gold Loan';
	$data_to_save['Parameters']['LeadSource']= 'Online Referral';
	$data_to_save['Parameters']['LeadSubSource']= 'SMS';
	$data_to_save['Parameters']['Mobile']= $mobile;
	$data_to_save['Parameters']['Phone']= $phone;

	$save_postdata = json_encode($data_to_save);

	$save_ch = curl_init($lead_save_url);
	curl_setopt($save_ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($save_ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($save_ch, CURLOPT_POST, 1);
	curl_setopt($save_ch, CURLOPT_POSTFIELDS, $save_postdata);
	curl_setopt($save_ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($save_ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($save_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	$save_result = curl_exec($save_ch);
	curl_close($save_ch);
	//Save result into log file

	//Store into log file.
	$log = array();
	$log['timestamp'] = date('Y_m_d_h_i_s');
	$log['send_data'] = $data_to_save;
	$log['recieved_data'] = json_decode($save_result,true);
	$handle_3 = fopen("log/gold_loan_request_save_lead_log_".date('Y_m').".txt", 'a');
	fwrite($handle_3,json_encode($log)."\n");
	fclose($handle_3);
	//End of log

	echo json_encode(array('status'=>'success'));
//End of Save Lead
?>
