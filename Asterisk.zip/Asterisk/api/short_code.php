<?php
date_default_timezone_set("Asia/Calcutta");
include('../db.php');
$method = $_REQUEST["method"];
$mobile_no   = $_REQUEST['mobile'];
$circle      = $_REQUEST['circle'];
//$message     = url_decode($_REQUEST['keyword']);
$message     = $_REQUEST['keyword'];
$time_stamp  = date('Y-m-d H:i:s');
if(count($message) <= 160){		
if ($mobile_no!='') {
		//insert data here
		$sql = "insert into short_code(mobile_no,circle,message,sms_date) values('$mobile_no','$circle','$message','$time_stamp')";
		$result = mysqli_query($con,$sql);
		
		//wrting log here
		$log = date('Y-m-d H:i:s')."|".json_encode($_REQUEST)."\n";
		$handle = fopen("log/shortCodeLog.txt","a");
		fwrite($handle,$log);
		fclose($handle);
		//log end here

		if($result==1){
			echo "Thank you for setting your goal. Our representative will get back to you soon";
			//return("Thank you for setting your goal. Our representative will get back to you soon");
			return("Thank you for setting your goal. Our representative will get back to you soon");
		}else{
			return("");
		}

		}
	}

?>
