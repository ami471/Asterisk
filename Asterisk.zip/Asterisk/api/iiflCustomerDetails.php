<?php 
date_default_timezone_set("Asia/Calcutta");
include('../db.php');
include('media_channel_vehical.php');

$mobile_no = $_REQUEST['mobile_no'];
$location = $_REQUEST['location'];
$date = $_REQUEST['date'];
$time     = $_REQUEST['time'];
$day      = $_REQUEST['day'];
$Time_Session     = $_REQUEST['Time_Session'];
$zone     = $_REQUEST['zone'];
$pincode  = $_REQUEST['pincode'];
$campaign         = $_REQUEST['campaign'];
$weekday  = $_REQUEST['weekday'];
$media_channel    = $_REQUEST['media_channel'];
$media_vehicle    = $_REQUEST['media_vehicle'];
$status   = $_REQUEST['status'];
$languagekey = $_REQUEST['languagekey'];
$type = $_REQUEST['type'];
$state = $_REQUEST['state'];
$did = $_REQUEST['did'];

$callEnterTime = $_REQUEST['callEnterTime'];
$callAgentStartTime = $_REQUEST['callAgentStartTime'];
$endTimestamp = $_REQUEST['endTimestamp'];

$vehical = strtoupper($media_vehical_array[strtolower($media_vehicle)]);
$channel = strtoupper($media_channel_of_vehical_array[strtolower($vehical)]);

if ($did=='7039001800' || $did=='917039001800') {
	$vehical = 'GOLD LOAN WIN BACK';
	$channel = 'GOLD LOAN';
	
	$media_vehicle = 'GOLD LOAN WIN BACK';
	$media_channel = 'GOLD LOAN';
}

if (strtolower($pincode)=='invalid pincode') {
	$location = 'INVALID PINCODE';
	$pincode = "INVALID PINCODE";
	$status = "INVALID PINCODE";
}

if ($mobile_no!='') {
	//insert data here
	$sql = "insert into iifl_customer_detail(mobile_no,location,date,time,day,Time_Session,zone,pincode,campaign,weekday,media_channel,media_vehicle,status,languagekey,type,state,did,callEnterTime,callAgentStartTime,endTimestamp,channel,vehical) values('$mobile_no','$location','$date','$time','$day','$Time_Session','$zone','$pincode','$campaign','$weekday','$media_channel','$media_vehicle','$status','$languagekey','$type','$state','$did','$callEnterTime','$callAgentStartTime','$endTimestamp','$channel','$vehical')";
	mysqli_query($con,$sql);

	//wrting log here
	$log = date('Y-m-d H:i:s')."|".implode(",",$_REQUEST)."\n";
	$handle = fopen("log/iiflCustomerDetails.txt","a");
	fwrite($handle,$log);
	fclose($handle);
	//log end here

	echo "success";
}else{
	echo "invalid data";
}
?>
