<?php  
	$msg = "Thank you for attending IIFL Milan and we appreciate your feedback. We will connect with you shortly to understand your feedback.";
	$mobileNo = '7798416543';
	$apiKey = urlencode('ba3jbBGw0T4-VphT3QpclFLA1VhuXfZsAFIAxLaXqW');	
	$numbers = array($mobileNo);
	$sender = urlencode('IIFLRA');
	$message = rawurlencode($msg); 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	echo $responce = curl_exec($ch);
	curl_close($ch);
?>