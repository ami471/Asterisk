<?php
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
include('../db.php');

$mdn = $_REQUEST['mobno'];
$did = $_REQUEST['did'];
$media_channel = $_REQUEST['media_channel'];
$media_vehical = $_REQUEST['media_vehicle'];
$day = $_REQUEST['day'];
$dayType = $_REQUEST['weekday'];
$date = $_REQUEST['date'];
$timestamp = $_REQUEST['time'];
$time_session = $_REQUEST['Time_Session'];
$campaign = $_REQUEST['campaign'];
$circle = $_REQUEST['circle'];

//wrting log here
$log = date('Y-m-d H:i:s')."|".implode(",",$_REQUEST)."\n";
$handle = fopen("log/pushAmitMissedcallDataLog.txt","a");
fwrite($handle,$log);
fclose($handle);
//log end here

//$sql = "INSERT INTO mediamissed_calling(mobno,status,did,media_channel,media_vehicle,day,weekday,date,time,Time_Session,campaign,circle) VALUES('$mdn','NOANSWER','$did','$media_channel','$media_vehical','$day','$dayType','$date','$timestamp','$time_session','$campaign','$circle')";
//$res = mysqli_query($con,$sql);

?>