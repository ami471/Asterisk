<?php 
	$con = new mysqli('localhost','dasienin_asroot','dasien1234!@','dasienin_analytics','3306');
	//$con = mysqli_connect("127.0.0.1", "dasienin_asroot", "dasien1234!@", "dasienin_analytics","3306");
?>