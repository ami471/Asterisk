#!/usr/bin/perl
#use strict;

package Ivr::DialPlanApi;

#** @file DialplanAppsApi module.
#** @brief 
#	
#** @details	
#	
#** @ingroup Ivr
#** @author Amit Anand amit@thinkwalnut.com
#** @date 12/10/2015


#** @function apps_background
#** @brief 	
#** @details 
#   Recursively  plays the 'sound_file' and wait for number of inputs specified 
#   in 'maxdigits' till 'response' time expire and also verify the no 
#   input case and allow user for input till number of tries specified.
#  
#** @param $AGI = Object of the AGI method
#** @param $bg_sound_file = sound file to be played
#** @param $max_allowed_digit = the maximum digits allowed to press at one time
#** @param $timeout_time = the maximum time the channel can wait with out any operation
#** @param $max_timeout_count = the maximum number of repeate after every timeout_time overs
#** @param $reg_timeout_file = the sound file which will play after timeout_time overs
#** @param $max_timeout_file = the sound file which will play after max_timeout_count overs
#** @return response 
#   On Success DTMF(Option pressed) , 
#   On Timeout -1 ,
#   On Invalid -1.

sub apps_background {

	my ($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time,$max_timeout_count,$reg_timeout_file,$max_timeout_file) = @_;

	my $i = 0;

	for ($i;$i<=$max_timeout_count;$i++){

		my $dtmf_value = apps_play_background($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time);

		return -1 if ($dtmf_value < 0);

		if( $dtmf_value eq undef ){

			$max_timeout_count--;

			if ($max_timeout_count eq ''){

				$AGI->exec("Playback","$max_timeout_file") if ( $max_timeout_file ne '' and  $max_timeout_file ne undef);
				return -2;

			}
			else {

				$AGI->exec("Playback","$reg_timeout_file") if ( $reg_timeout_file ne '' and $reg_timeout_file ne undef);

			} 

		}
		else {

			return $dtmf_value;

		}
	}

	return -1;

}

#** @function apps_background_hash
#** @brief 	
#** @details 
#	This function checks for the pressed dtmf value against the dtmf value stored in hash format 
#   only on success will Recursively  plays the 'sound_file' and wait for number of inputs specified 
#   in 'maxdigits' till 'response' time expire and also verify wrong input or no input case 
#   and allow user for input till number of tries specified.
#   
#** @param $AGI = Object of the AGI method
#** @param $AGI = Object of the AGI method
#** @param $bg_sound_file = sound file to be played
#** @param $max_allowed_digit = the maximum digits allowed to press at one time
#** @param $timeout_time = the maximum time the channel can wait with out any operation
#** @param $wrong_input_count = the maximum number of times user can punch a wrong dtmf value
#** @param $max_timeout_count = the maximum number of repeate after every timeout_time overs
#** @param $wrong_input_file = the sound file which will play when user enters wrong dtmf value
#** @param $reg_timeout_file = the sound file which will play after timeout_time overs
#** @param $max_timeout_file = the sound file which will play after max_timeout_count overs
#** @param $max_wrong_input_file = the sound file which will play after wrong_input_count overs 
#** @param $hash_table_ref = reference of the hash talbe of allowed dtmf value.
#** @return response 
#   On Success DTMF(Option pressed) , 
#   On Timeout -1 ,
#   On Invalid -1.   
   
sub apps_background_hash{
   
    my ($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time,$max_timeout_count,$reg_timeout_file,$max_timeout_file,$wrong_input_count,$wrong_input_file,$max_wrong_input_file,$hash_table_ref) = @_;  
       
	do {

		my $dtmf_value = apps_play_background($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time);
		return -1 if($dtmf_value < 0);

		my %hash_table = %{$hash_table_ref};

		if( $dtmf_value eq undef ){

			$max_timeout_count--;

			if ($max_timeout_count <= 0) {

				$AGI->exec("Playback","$max_timeout_file") if ( $max_timeout_file ne '' and  $max_timeout_file ne undef);
				return -2;

			} else {

				$AGI->exec("Playback","$reg_timeout_file") if ( $reg_timeout_file ne '' and $reg_timeout_file ne undef);

			}	 

		} elsif ($hash_table{$dtmf_value} eq undef) {

			$wrong_input_count--;

			if ($wrong_input_count <= 0) {

				$AGI->exec("Playback","$max_wrong_input_file") if ( $max_wrong_input_file ne '' and $max_wrong_input_file ne undef);
				return -3;
			} else {

				$AGI->exec("Playback","$wrong_input_file") if ( $wrong_input_file ne '' and  $wrong_input_file ne undef);

			}

		} else {
			return $dtmf_value;

		}
	}while($wrong_input_count && $max_timeout_count);

	return -1;
}
   
#** @function apps_background_length
#** @brief 	
#** @details 
#	 This function checks for wrong input using the lenght of the dtmf value against the 
#   maximum allowed ditis only on success will Recursively  plays the 'sound_file' and wait 
#   for number of inputs specified in 'maxdigits' till 'response' time expire and also verify
#   wrong input or no input case and allow user for input till number of tries specified.
#   
#** @param $AGI = Object of the AGI method
#    $AGI = Object of the AGI method
#    $bg_sound_file = sound file to be played
#    $max_allowed_digit = the maximum digits allowed to press at one time
#    $timeout_time = the maximum time the channel can wait with out any operation
#    $wrong_input_count = the maximum number of times user can punch a wrong dtmf value
#    $max_timeout_count = the maximum number of repeate after every timeout_time overs
#    $wrong_input_file = the sound file which will play when user enters wrong dtmf value
#    $reg_timeout_file = the sound file which will play after timeout_time overs
#    $max_timeout_file = the sound file which will play after max_timeout_count overs
#    $max_wrong_input_file = the sound file which will play after wrong_input_count overs. 
#** @return response 
#   On Success DTMF(Option pressed) , 
#   On Timeout -1 ,
#   On Invalid -1.     
   
   
             
sub apps_background_length {

	my ($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time,$max_timeout_count,$reg_timeout_file,$max_timeout_file,$wrong_input_count,$wrong_input_file,$max_wrong_input_file) = @_;  

	do	{

		my $dtmf_value= apps_play_background($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time);

		return -1 if ($dtmf_value < 0);

		if( $dtmf_value eq undef ){

			$max_timeout_count--;

			if ($max_timeout_count <= 0) {

				$AGI->exec("Playback","$max_timeout_file") if ( $max_timeout_file ne '' and  $max_timeout_file ne undef);
				return -2;

			} else {

				$AGI->exec("Playback","$reg_timeout_file") if ( $reg_timeout_file ne '' and $reg_timeout_file ne undef);
			}	 

		} elsif(length($dtmf_value) != $max_allowed_digit) {

			$wrong_input_count--;	

			if ($wrong_input_count <= 0) {

				$AGI->exec("Playback","$max_wrong_input_file")if ( $max_wrong_input_file ne '' and $max_wrong_input_file ne undef);
				return -3;
			} else {

				$AGI->exec("Playback","$wrong_input_file") if ( $wrong_input_file ne '' and  $wrong_input_file ne undef);
			}

		} else {
			return $dtmf_value;
		}
	} while($wrong_input_count && $max_timeout_count);		
}   
   

#** @function apps_bg_hash_stream
#** @brief 	
#** @details 
#
#
#** @param $AGI = Object of the AGI method
#** @param $bg_sound_file = sound file to be played
#** @param $wrong_input_count = the maximum number of times user can punch a wrong dtmf value
#** @param $max_timeout_count = the maximum number of repeate after every timeout_time overs
#** @param $wrong_input_file = the sound file which will play when user enters wrong dtmf value
#** @param $reg_timeout_file = the sound file which will play after timeout_time overs
#** @param $max_timeout_file = the sound file which will play after max_timeout_count overs
#** @param $max_wrong_input_file = the sound file which will play after wrong_input_count overs 
#** @param $hash_table_ref = reference of the hash talbe of allowed dtmf value.
#
#** @return response 
#   On Success DTMF(Option pressed) , 
#   On Timeout -1 ,
#   On Invalid -1.     
   
   
sub apps_bg_hash_stream {
	
	my ($AGI,$bg_sound_file,$max_timeout_count,$reg_timeout_file,$max_timeout_file,$wrong_input_count,$wrong_input_file,$max_wrong_input_file,$hash_table_ref) = @_;
		
	do{
		
		my $dtmf_value = apps_stream_background($AGI,$bg_sound_file);
		
		my %hash_table=%$hash_table_ref;
		
		if( $dtmf_value eq undef ){
				
			$max_timeout_count--;
			
 			if ($max_timeout_count eq '') {
		 			
	 			$AGI->exec("Playback","$max_timeout_file") if ( $max_timeout_file ne '' and  $max_timeout_file ne undef);
	 			
	 		} else {
	 			
	 			$AGI->exec("Playback","$reg_timeout_file") if ( $reg_timeout_file ne '' and $reg_timeout_file ne undef);
	 		
	 		}	 
	 					
		} elsif ($hash_table{$dtmf_value} eq undef) {
			
			$wrong_input_count--;
				
			if ($wrong_input_count eq '') {
	 			
	 			$AGI->exec("Playback","$max_wrong_input_file") if ( $max_wrong_input_file ne '' and $max_wrong_input_file ne undef);
	 
	 		} else {
	 			
	 			$AGI->exec("Playback","$wrong_input_file") if ( $wrong_input_file ne '' and  $wrong_input_file ne undef);
	 			
	 		}
		  		
		} else {
		
			return $dtmf_value;
		   
		}
	}while($max_timeout_count && $wrong_input_count);
	
	 return -1;

} 


#** @function background_valid_stream
#** @brief 	
#** @details 
#	Recursively  streams the 'sound_file' and checks the valid dtmf value  till 'response' 
#   time expire and also verify the no input case and allow user 
#   for input till number of tries specified.
#   
#** @param $AGI = Object of the AGI method
#** @param $bg_sound_file = sound file to be played
#** @param $max_timeout_count = the maximum number of repeate after every timeout_time overs
#** @param $reg_timeout_file = the sound file which will play after timeout_time overs
#** @param $max_timeout_file = the sound file which will play after max_timeout_count overs
#** @param $valie_dtmf = the dtmf values which should be pressed   
#
#** @return response 
#   On Success DTMF(Option pressed) , 
#   On Timeout -1 ,
#   On Invalid -1.   


sub background_valid_stream {
	
	my ($AGI,$bg_sound_file,$max_timeout_count,$reg_timeout_file,$max_timeout_file,$valid_dtmf) = @_;
	
	do{
		
		my $dtmf_value = apps_valid_background($AGI,$sound_file,$valid_dtmf);
		
		if( $dtmf_value eq undef ){
				
			$max_timeout_count--;
			
 			if ($max_timeout_count eq '') {
		 			
	 			$AGI->exec("Playback","$max_timeout_file") if ( $max_timeout_file ne '' and  $max_timeout_file ne undef);
	 			
	 			
	 		} else {
	 			
	 			$AGI->exec("Playback","$reg_timeout_file") if ( $reg_timeout_file ne '' and $reg_timeout_file ne undef);
	 		
	 		}	 
	 					
		} else  {
					
			return $dtmf_value;
		   
		}
	}while($max_timeout_count);
	
	 return -1;

}


#** @function apps_bg_leng_hash
#** @brief 	
#** @details 
#	 This function checks for the lenght of the pressed dtmf value against the length specified  
#    only on success will Recursively  Play the 'sound_file' and wait for number of inputs 
#    specified in 'maxdigits' till 'response' time expire and also verify wrong input
#    or no input case and allow user for input till number of tries specified.
#   
#** @param $AGI = Object of the AGI method 
#** @param $bg_sound_file = sound file to be played
#** @param $max_allowed_digit = the maximum digits allowed to press at one time
#** @param $timeout_time = the maximum time the channel can wait with out any operation
#** @param $wrong_input_count = the maximum number of times user can punch a wrong dtmf value
#** @param $max_timeout_count = the maximum number of repeate after every timeout_time overs
#** @param $wrong_input_file = the sound file which will play when user enters wrong dtmf value
#** @param $reg_timeout_file = the sound file which will play after timeout_time overs
#** @param $max_timeout_file = the sound file which will play after max_timeout_count overs
#** @param $max_wrong_input_file = the sound file which will play after wrong_input_count overs. 
#** @param $max_length = the allowed maximum length of the dtmf value.
#
#** @return response 
#   On Success DTMF(Option pressed) , 
#   On Timeout -1 ,
#   On Invalid -1.   


sub apps_bg_leng_hash {
		
		
	my ($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time,$max_timeout_count,$reg_timeout_file,$max_timeout_file,$wrong_input_count,$wrong_input_file,$max_wrong_input_file,$max_length) = @_;
    
   do{
			my $dtmf_value = apps_play_background($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time);
			
			
			my $length = length($dtmf_value);
			
			sleep 1;
			
			if( $dtmf_value eq undef ){
					
					$max_timeout_count--;
					
		 			if ($max_timeout_count eq '') {
				 			
			 			$AGI->exec("Playback","$max_timeout_file") if ( $max_timeout_file ne '' and  $max_timeout_file ne undef);
			 			
			 		} else {
			 			
			 			$AGI->exec("Playback","$reg_timeout_file") if ( $reg_timeout_file ne '' and $reg_timeout_file ne undef);
			 		
			 		}	 
		 					
			} elsif (exists $max_length->{$length}) {
						
					if(ref $max_length->{$length} eq "HASH" && $max_length->{$length}->{$dtmf_value}) {
							
								return $dtmf_value;	
								
					} elsif ( ref \$max_length->{$length} eq "SCALAR"){
								
								return $dtmf_value;
					
					} else {
						
								$wrong_input_count--;
							
					if ($wrong_input_count eq '') {
						 			
					 			$AGI->exec("Playback","$max_wrong_input_file") if ( $max_wrong_input_file ne (undef and ''));
							
					 			sleep 1;
							 			
					} else {
						 			
				   	 			$AGI->exec("Playback","$wrong_input_file") if ( $wrong_input_file ne (undef and ''));	
					}
		
                 		} 			  		
		
                	} else { 
			
					$wrong_input_count--;
								
					if ($wrong_input_count eq '') {
						 			
					 			$AGI->exec("Playback","$max_wrong_input_file") if ( $max_wrong_input_file ne (undef and ''));
						 			
					 			sleep 1;
						 			 			
					} else {
						 			
					 			$AGI->exec("Playback","$wrong_input_file") if ( $wrong_input_file ne (undef and ''));	
					}
			}
	}while($wrong_input_count && $max_timeout_count);
	
	 return -1;

}


#** @function set_ivr_path
#** @brief 	
#** @details 
#	This function is used to set ivr path using set variable function of the agi
#** @param $AGI = object of the AGI method
#** @param $path = the path what we want to set
   
sub set_ivr_path {
	
        my ($AGI,$path) = @_;
        my $ivrspath=$AGI->get_variable('ivrspath');
        $ivrspath .= "->".$path;
        $AGI->set_variable('ivrspath',$ivrspath);
}

#** @function apps_play_background
#** @brief 	
#** @details 
#   Plays the background 'sound_file' and wait for number of inputs specified in 'maxdigits' 
#   till 'response' time expire.
#** @param $AGI = Object of the AGI method
#** @param $bg_sound_file = sound file to be played
#** @param $max_allowed_digit = the maximum digits allowed to press at one time
#** @param $timeout_time = the maximum time the channel can wait with out any operation   
#** @return value pressed
#   On Success DTMF(Option pressed).


sub apps_play_background {
	
	my($AGI,$bg_sound_file,$max_allowed_digit,$timeout_time)=@_;
	

 	$bg_sound_file=~s/\n//;
 	
 	$bg_sound_file=~s/\0//;
 	
 	my $value_pressed=$AGI->get_data($bg_sound_file,$timeout_time,$max_allowed_digit);
     
	$value_pressed =~ s/ //g;
	
	
 	return $value_pressed;
 	
 	    
   } 
   
   
#** @function apps_stream_background
#** @brief 	
#** @details 
#   Streams the background 'sound_file' and checks pressed dtmf value in "1234567890*#"
#
#** @param $AGI = Object of the AGI method
#** @param $bg_sound_file = sound file to be played
#  
#** @return value pressed
#   On Success DTMF(Option pressed).

   
sub apps_stream_background{

  my ($AGI,$bg_sound_file) = @_;
  $bg_sound_file=~s/\n//;
  $bg_sound_file=~s/\0//;
  my $get_value=$AGI->stream_file($bg_sound_file,"1234567890*#");
  my $dtmf = chr($get_value);
  #$dtmf = "1";
  return $dtmf;
}  

#** @function apps_valid_background
#** @brief 	
#** @details 
#   Streams the background 'sound_file' and checks pressed dtmf value against the valid dtmf value
#   given to it by the user.
#
#** @param $AGI = Object of the AGI method
#** @param $bg_sound_file = sound file to be played
#** @param $valid_dtmf = the valid dtmf value which is to be pressed by the users
#  
#** @return value pressed
#   On Success DTMF(Option pressed).


  
sub apps_valid_background{
  
  my ($AGI,$bg_sound_file,$valid_dtmf)=@_;  
  
  $bg_sound_file=~s/\n//;
  
  $bg_sound_file=~s/\0//;
  
  my $get_value=$AGI->stream_file($bg_sound_file,$valid_dtmf);
  
  my $dtmf_value=chr($get_value);
  
  return $dtmf_value;	

}

#** @function agiarray_command
#** @brief 	
#   Example for this : \@variables = { "Playback","welcome"
#                                      "Background","options"
#                                      "Saydigits","123" };
#** @details 
#   By passing the AGI application and Data in a hash to this function ,it executes in a
#   continues loop fashion.
#
#** @param $AGI = Object of the AGI method
#** @param \@variables = the hash referrence of the agi application mathched with its files
#   

 
sub agiarray_command{
  
  my ($AGI,$var) = @_; 
  my @var_apps=@$var;
  my $i=0;
  my $j=0;
  my $apps="";
  my $values="";
  my $k=@var_apps;
   
  
  while ($i<$k){
  
  $apps=$var_apps[$i]; 
  $i++;
  $values=$var_apps[$i];
  $AGI->exec("$apps","$values");
  $i++;
  }
  return 0;
 }
 

#** @function fun_PlayNumbers
#** @brief 	
#** @details 
#   This function is used to play number in specified language and in specified currency.
#
#** @param $AGI = Object of the AGI method
#** @param $log = 
#** @param $digits = The digits to be played ex: 10,10,100 as 10 lakhs 10 thousand 100 rupees
#** @param $currency = The currency to be played in the end
#** @param $lang = The laguage in which the digits to be played.
#   
#  



sub fun_PlayNumbers {
	
	my ($AGI,$log,$digits,$currency,$lang) = @_;
	my @str_digt=split(/\./,$digits);
	$str_digt[0] = int($str_digt[0]);
	
	my $len=length($str_digt[0]);
	
	my $string = fun_say_number($log,$str_digt[0],$lang);
		
	my @digitarr = split(',',$string);
	
	foreach $digi (@digitarr) {

		$AGI->exec("playback","$digi");
	}
	
	$AGI->exec("Playback",$currency)if( $currency ne "");
	
	if ($str_digt[1] != 0 || $str_digt[1] ne ""){
	
	}
}
 
#** @function fun_two_digits
#** @brief 	
#** @details 
#   This function is used to split numbers according to their digits.
#
#** @param  $digits = The digits to be played ex: 10,10,100 as 10 lakhs 10 thousand 100 rupees
#** @param  $language = The laguage in which the digits to be played.
#  
#** @return value this function return the splited number in their respective digit format

 
sub fun_two_digits{
	 
   my $digits = shift;
	my $language = shift;
	$digits = int($digits);
	my $value = 0;
	my $dig1;
	my $dig2;

	if($digits){
		
        if($language !~ "english"){
        	
        	$value = $digits;
        	
        } elsif($digits<=20 || $digits==30 || $digits==40 || $digits==50 || $digits==60 || $digits==70 || $digits==80 || $digits==90) {
        	
        	$value = $digits;
        	
        } else {
        	
        	$dig1 = substr($digits,0,1);
         $dig2 = substr($digits,1);
         $value = $dig1."0,".$dig2;
        }
    }
    
    return $value;
}

#** @function fun_say_number
#** @brief 	
#** @details 
#   This function is used split numbers , add the decimal value as core ,lakh, thousand, hundred
#   and return them to fun_PlayNumbers for playing.
#
#** @param  $digits = The digits to be played ex: 10,10,100 as 10 lakhs 10 thousand 100 rupees
#** @param  $language = The laguage in which the digits to be played.
#** @param  $log      =
#  
#** @return value this function return the splited number in their respective digit format


sub fun_say_number {
	
	my $log       = shift;
	my $number    = shift;
	my $language  = shift;
	my $play;
	
	$number = int($number);
	if(!$number){
		return 0;
	}
	
	
	if(length($number) == 8 || length($number) == 9) {
		
		if(length($number) == 8){
			
			$digit = substr($number, 0, 1);
			$number = substr($number,1);
			
         } else {
         	
         	$digit = substr($number, 0, 2);
         	$number = substr($number,2);
         	$digit = fun_two_digits($digit,$language);
         	
         }
         
         $play = $digit.",crore";
         
	} elsif(length($number) == 6 || length($number) == 7) {

        if(length($number) == 6) {
        	
        	$digit = substr($number, 0, 1);
        	$number = substr($number,1);
        
        } else {
        	
        	$digit = substr($number, 0, 2);
        	$number = substr($number,2);
        	$digit = fun_two_digits($digit,$language);
        	
        }
        
        $play = $digit.",lakh";
        
	} elsif(length($number) == 4 || length($number) == 5 ) {
		
		if(length($number) == 4) {
			
			$digit = substr($number, 0, 1);
			$number = substr($number,1);
			
		} else {
			
			$digit = substr($number, 0, 2);
			$number = substr($number,2);
			$digit = fun_two_digits($digit,$language);
			
         }
         
         $play = $digit.",thousand";
         
	} elsif(length($number) == 3) {
		
		$digit = substr($number, 0, 1);
		$number = substr($number,1);
		$play = $digit.",hundred";
		
	} 
	

	if(length($number) > 2) {
		
		$number = fun_say_number($log,$number,$language);
		if($number){
			if($play){
				
				$play .= ",".$number;
					
			} else {
				
				$play = $number;
				
			}
		}
		return $play;
	
	} elsif(length($number) == 2) {
		
		$digit = fun_two_digits($number,$language);
		if($digit){
			if($play){
				
				$play .= ",".$digit;
					
			} else {
			
				$play = $digit;
			
			}
		}
		return $play;
	
	} elsif(length($number) == 1) {
		
		if($play) {
        
        	$play .= ",".$number;
		
		} else {
		
			$play = $number;
		}
		
        return $play;
     
	} else {

        return $play;
      
	}
}

sub apps_playdigit {
        my ($AGI,$number)= @_;
		$AGI->exec("NoOp","COMING===============$number");
        my @split_num = split(undef,$number);
        foreach $val (@split_num){
                $AGI->exec("Playback",$val);
        }
}

1;

  
     
   
   

                
                
    
    
