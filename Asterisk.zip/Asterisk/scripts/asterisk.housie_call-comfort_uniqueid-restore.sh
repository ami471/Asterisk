#!/bin/bash
# Created by Santosh on 2018-11-14
# housie_call & comfort_uniqueid tables from Asterisk db restore to 172.20.130.130 crayfish db

### Today + hour in 24h format ###
NOW=$(date +"%d-%m-%Y")
Yest=$(date +%d-%m-%Y -d "-1 day")

mysqldump -uroot -p'mys@r0ja' --skip-lock-tables --single-transaction --flush-logs --hex-blob asterisk housie_call > /backup/mysql_backup/asterisk.housie_call.$Yest.sql
echo "asterisk.housie_call.$Yest.sql created \n" > /tmp/housie_call_comfort_uniqueid_status.txt

mysql -h172.20.130.130 -ucrayfish -p'cr@yf!$h@123' crayfish < /backup/mysql_backup/asterisk.housie_call.$Yest.sql
echo "asterisk.housie_call.$Yest.sql restored in crayfish DB \n" >> /tmp/housie_call_comfort_uniqueid_status.txt

mysqldump -uroot -p'mys@r0ja' --skip-lock-tables --single-transaction --flush-logs --hex-blob asterisk comfort_uniqueid > /backup/mysql_backup/asterisk.comfort_uniqueid.$Yest.sql
echo "asterisk.comfort_uniqueid.$Yest.sql created \n" >> /tmp/housie_call_comfort_uniqueid_status.txt

mysql -h172.20.130.130 -ucrayfish -p'cr@yf!$h@123' crayfish < /backup/mysql_backup/asterisk.comfort_uniqueid.$Yest.sql
echo "asterisk.comfort_uniqueid.$Yest.sql tored in crayfish DB \n" >> /tmp/housie_call_comfort_uniqueid_status.txt

exit
