#!/bin/bash
## Created on 18Jan 2019
psswd=''        
#### This Upload and Download backup script must be run from asterisk-master 120.141 server with root access only ####
#### Author Raju 
#### The script will download the files and check of syntax errors, and if no error - file  will copy to destination.
## To pause this script for debug - Just write pause word to call this pause funtion ###
	clear

# Variables
cur_date=`date +%Y%m%d`
cur_month=`date +%b_%Y`
setfacl=`which setfacl`   #  to Add sticky bit to New files uploaded on 253 server DocumentRoot
base_path=/twd/www/html/
mkdir -p /var/log/uploaded_files_253/"$cur_month"/
total_uploaded_files_253=/var/log/uploaded_files_253/"$cur_month"/total_uploaded_files_253_srv_"$cur_month".txt

sendEmail=`which sendEmail`

# Time Out Function
timelimit=30
timeout()	{	
#out=10
        read -t $timelimit choice
if [ ! -z "$choice" ]		#### -z STRING    "True if string is empty."
then
	echo "Script Will Continue Now... \n"     > /dev/null 2>&1
else
clear
#	tput cup 10 35
#	echo -en "*** TIME OUT ***\n "
#	tput cup 12 15
#	echo -en "No Input from USER - EXTITING Now !!! \n"
#	tput cup 14 20
#	echo -en "EXTITING the script in 5 Sec !!!  \c"
#	sleep 5
#		if [ ! -z "$username" ]          #### -z STRING    "True if string is empty."
#		then
#                     	del_tmp_files
#                        tput cup 20 20
#                        echo -en "\n "
#                        exit
#		else
#                        tput cup 20 20
#                        echo -en "\n "
#                        exit
#		fi
#tput cup 20 20
#	echo -en "\n "
#	exit
        echo "Uploading with dev user..."
fi
		}

# To pause the script 
pause() {
	echo -en "Press any key to continue \n"
	read
	}

# To check and confirm files before uploading
check() {
        echo -en "Is Above List of files to be upload is OK - [Y/N] : \c"
        read option
		if [ "$option" = y ] || [ "$option" = Y ]
		then
			echo -en "							\n"
			echo -en "File's/Folder's Upload will Start Now..... 		\n"
			echo -en "							\n"
		elif [ "$option" = n ] || [ "$option" = N ]
		then
			echo -en "							\n"
			echo -en "On User Request File's / Folder's are not Uploaded....\n"
			echo -en "							\n"
			> /scripts/up_down_load/upload_download_file_list.txt
			exit
		else
			echo -en "						\n"
			echo -en "Press [Y/N] Only.... 				\n"
			echo -en "						\n"
			check
		fi
        }

# Start Progress Bar
SPB()   {
echo -en "Please Wait ####\c"
while true;do echo -n "#";sleep 1;done &
        }

# End Progress Bar
EPB()   {
kill $!; trap 'kill $!' SIGTERM
echo -en " done \n"
        }
			
already_running_check()	{
clear

# Set a foreground colour using ANSI escape
tput cup 6 25
tput setaf 5
echo -en "Think Walnut Digital Download Script                    \n"
tput cup 8 28
tput setaf 6
echo -en "Created by Raju Basutkar                              \n"
tput sgr0

                echo -en " \n"
/bin/ps ax | grep '[/]bin/bash /scripts/up_down_load/up_down_load.sh' | wc -l > /tmp/upload.sh_ps_count.txt
ps_count=`cat /tmp/upload.sh_ps_count.txt`
echo -en "\n"

		if [ $ps_count -gt 1 ]
           	then
                        if [ -f /tmp/upload_script_running.txt ]
                        then
				tput cup 12 20
	                 	echo -en "`tput setf 4``tput bold``tput smul``cat /tmp/upload_script_running.txt``tput rmul``tput sgr0` is using the script for Uploading \n"
        	       		echo -en " \n"
				tput cup 14 20
                  		echo -en "EXITING after 5sec!!!!  Try After Some Time..... \c"
				sleep 5
				tput cup 20 20
        	       		echo -en " \n"
                    		exit
			else
				echo -en "Uploding Script will Start NOW........\n"	> /dev/null 2>&1
#				echo -en "Process is Running but No /tmp/upload_script_running.txt file Uploding Script will Start NOW........\n"	
			fi
		else
			echo -en "Uploding Script will Start NOW................\n"	> /dev/null 2>&1
#			echo -en "No Uploding Script RUNNING - will Start NOW................\n"	
              	fi
			}

#clear
#echo -en "
#tput sgr0 . Turn off all attributes
#
#tput Color Capabilities:
#
#tput setab [1-7] . Set a background color using ANSI escape
#tput setb [1-7] . Set a background color
#tput setaf [1-7] . Set a foreground color using ANSI escape
#tput setf [1-7] . Set a foreground color
#____________________________________________________________
#tput Text Mode Capabilities:
#
#tput bold . Set bold mode
#tput dim . turn on half-bright mode
#tput smul . begin underline mode
#tput rmul . exit underline mode
#tput rev . Turn on reverse mode
#tput smso . Enter standout mode (bold on rxvt)
#tput rmso . Exit standout mode
#tput sgr0 . Turn off all attributes
#____________________________________________________________
#Color Code for tput:
#
#0 . Black
#1 . Blue
#2 . Green
#3 . Cyan
#4 . Red
#5 . Magenta
#6 . Yellow
#7 . White 
#____________________________________________________________ \n"  > /dev/null 2>&1

## Below Line will Empty Old File   OR  Create's New Empty FIle
rm .upload_download_file_list.txt.*   > /dev/null 2>&1
rm .upload_download_file_list.txt.swp   > /dev/null 2>&1

> /scripts/up_down_load/upload_download_file_list.txt 

#base_path=/twd/www/html/
#total_uploaded_files_253=/var/log/uploaded_files/total_uploaded_files_253_srv_`date +%Y%m%d`.txt
#echo -en "base_path=$base_path \n"
## Funtion will show status of output after script completion ##
output_format() {
                clear
                echo -en " \n"

                        if [ -f /tmp/new_file_or_wrong_path.txt ]
                        then
                echo -en " 								\n" >  /tmp/new_file_or_wrong_path.txt
                echo -en "Below files'(s) is/are Uploaded on 253 Server by : $username	\n" >> /tmp/new_file_or_wrong_path.txt
                echo -en " 								\n" >> /tmp/new_file_or_wrong_path.txt
                echo -en "If Not Uploaded - Check file Path :- 				\n" >> /tmp/new_file_or_wrong_path.txt
                echo -en "==================================== 				\n" >> /tmp/new_file_or_wrong_path.txt
                echo -en "`cat /tmp/new_file_or_wrong_path.txt` 			\n" >> /tmp/new_file_or_wrong_path.txt
                echo -en "--------------------------------------------------------------\n" >> /tmp/new_file_or_wrong_path.txt
	clear
		echo -en "`cat /tmp/new_file_or_wrong_path.txt` 			\n" >> $total_uploaded_files_253
		echo -en "`cat /tmp/new_file_or_wrong_path.txt`"
$sendEmail -f admin@almond.thinkwalnut.com -t $username@thinkwalnut.com -cc tsg@thinkwalnut.com, prabhat@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "New File OR Wrong Path on 253 Server - $username" -o message-file=/tmp/new_file_or_wrong_path.txt  > /dev/null 2>&1
#$sendEmail -f admin@almond.thinkwalnut.com -t $username@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "New File OR Wrong Path on 253 Server - $username" -o message-file=/tmp/new_file_or_wrong_path.txt  > /dev/null 2>&1
                echo -en " \n"
                        fi
                       if [ -f /tmp/Uploaded_files_on_253_server.txt ]
                        then
                echo -en "								\n" >  /tmp/sucessfully_uploaded_files.txt
		echo -en "Below file'(s) is/are Uploaded on 253 Server by : $username	\n" >> /tmp/sucessfully_uploaded_files.txt
		echo -en " 								\n" >> /tmp/sucessfully_uploaded_files.txt
                echo -en "Successfully Uploaded files :- 				\n" >> /tmp/sucessfully_uploaded_files.txt
                echo -en "============================== 				\n" >> /tmp/sucessfully_uploaded_files.txt
                echo -en "`cat /tmp/Uploaded_files_on_253_server.txt` 			\n" >> /tmp/sucessfully_uploaded_files.txt
                echo -en "--------------------------------------------------------------\n" >> /tmp/sucessfully_uploaded_files.txt
	clear
		echo -en "`cat /tmp/sucessfully_uploaded_files.txt`			\n" >> $total_uploaded_files_253
		echo -en "`cat /tmp/sucessfully_uploaded_files.txt`"
$sendEmail -f admin@almond.thinkwalnut.com -t $username@thinkwalnut.com -cc tsg@thinkwalnut.com, prabhat@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Successfully Uploaded files on 253 Server - $username" -o message-file=/tmp/sucessfully_uploaded_files.txt  > /dev/null 2>&1 
#$sendEmail -f admin@almond.thinkwalnut.com -t $username@thinkwalnut.com  -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Successfully Uploaded files on 253 Server - $username" -o message-file=/tmp/sucessfully_uploaded_files.txt  > /dev/null 2>&1 
                echo -en " \n"
                        fi

                       if [ -f /tmp/Uploaded_fldr_on_253_server.txt ]
                        then
                echo -en " 								\n" >  /tmp/sucessfully_uploaded_folders.txt
                echo -en "Below folder'(s) is/are Uploaded on 253 Server by : $username	\n" >> /tmp/sucessfully_uploaded_folders.txt
                echo -en " 								\n" >> /tmp/sucessfully_uploaded_folders.txt
                echo -en "Successfully Uploaded folders :- 				\n" >> /tmp/sucessfully_uploaded_folders.txt
                echo -en "================================ 				\n" >> /tmp/sucessfully_uploaded_folders.txt
                echo -en "`cat /tmp/Uploaded_fldr_on_253_server.txt` 			\n" >> /tmp/sucessfully_uploaded_folders.txt
                echo -en "--------------------------------------------------------------\n" >> /tmp/sucessfully_uploaded_folders.txt
	clear
		echo -en "`cat /tmp/sucessfully_uploaded_folders.txt`			\n" >> $total_uploaded_files_253
		echo -en "`cat /tmp/sucessfully_uploaded_folders.txt`"
$sendEmail -f admin@almond.thinkwalnut.com -t $username@thinkwalnut.com -cc tsg@thinkwalnut.com, prabhat@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Successfully Uploaded folders on 253 Server - $username" -o message-file=/tmp/sucessfully_uploaded_folders.txt  > /dev/null 2>&1
#$sendEmail -f admin@almond.thinkwalnut.com -t $username@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Successfully Uploaded folders on 253 Server - $username" -o message-file=/tmp/sucessfully_uploaded_folders.txt  > /dev/null 2>&1
                echo -en " \n"
                        fi	

                        if [ -f /tmp/files_with_syntax_error.txt ]
                        then
                echo -en " 								\n" >  /tmp/files_with_syntax_error.txt
                echo -en "Below files'(s) is/are Uploaded on 253 Server by : $username	\n" >> /tmp/files_with_syntax_error.txt
                echo -en " 								\n" >> /tmp/files_with_syntax_error.txt
                echo -en "File'(s) with Syntax Error Not Uploaded :- 			\n" >> /tmp/files_with_syntax_error.txt
                echo -en "========================================== 			\n" >> /tmp/files_with_syntax_error.txt
                echo -en "`cat /tmp/files_with_syntax_error.txt` 			\n" >> /tmp/files_with_syntax_error.txt
                echo -en "--------------------------------------------------------------\n" >> /tmp/files_with_syntax_error.txt
	clear
		echo -en "`cat /tmp/files_with_syntax_error.txt`			\n" >> $total_uploaded_files_253
		echo -en "`cat /tmp/files_with_syntax_error.txt`"
$sendEmail -f admin@almond.thinkwalnut.com -t $username@thinkwalnut.com -cc tsg@thinkwalnut.com, prabhat@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Files with Syntax Error Not Uploaded on 253 Server - $username" -o message-file=/tmp/files_with_syntax_error.txt  > /dev/null 2>&1
#$sendEmail -f admin@almond.thinkwalnut.com -t $username@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Files with Syntax Error Not Uploaded on 253 Server - $username" -o message-file=/tmp/files_with_syntax_error.txt  > /dev/null 2>&1
                echo -en " \n"
                        fi


			deleted_files=/tmp/deleted_files.txt
###### If required Old Deleted files info then uncoment  below if-then-if loop
#                        if [ -s $deleted_files ]
#                        then
#                echo -en " \n"
#                echo -en "Below Old File'(s) are Deleted :- \n"
#                echo -en "================================= \n"
#                echo -en "`cat /tmp/deleted_files.txt` \n"
#                echo -en "----------------------------------------------------------------------------\n"
#                        fi
	del_tmp_files
                }
## Function to Delete Temporary files used in sScript ##
del_tmp_files() {
        > /scripts/up_down_load/upload_download_file_list.txt
	rm -f /tmp/php_file_type.txt			> /dev/null 2>&1	
	rm -f /tmp/php_syntax_chk.txt			> /dev/null 2>&1
	rm -f /tmp/files_with_syntax_error.txt		> /dev/null 2>&1
	rm -f /tmp/Uploaded_files_on_253_server.txt	> /dev/null 2>&1
 	rm -f /tmp/Uploaded_fldr_on_253_server.txt	> /dev/null 2>&1
 	rm -f /tmp/new_file_or_wrong_path.txt		> /dev/null 2>&1
	rm -f /tmp/deleted_files.txt			> /dev/null 2>&1
        rm -f upload.sh_ps_count.txt			> /dev/null 2>&1
	rm -f /tmp/non-php_file.txt			> /dev/null 2>&1
	rm -f /tmp/sucessfully_uploaded_files.txt	> /dev/null 2>&1
	rm -f /tmp/sucessfully_uploaded_folders.txt	> /dev/null 2>&1
	rm -f /tmp/files_with_syntax_error.txt		> /dev/null 2>&1
	rm -f /tmp/upload_script_running.txt		> /dev/null 2>&1
	rm -f /tmp/upload.sh_ps_count.txt		> /dev/null 2>&1
                }
echo -en "							   \n"

# Set a foreground colour using ANSI escape
tput cup 6 25
tput setaf 5 
echo -en "Think Walnut Digital Upload Script			\n"
tput cup 8 28
tput setaf 6 
echo -en "Created by Raju Basutkar				\n"
tput sgr0

# Move cursor to screen location X,Y (top left is 0,0)
tput cup 10 15
echo -en "Below Write your username only in $timelimit sec - to email the status after upload .	\n"
tput cup 12 30
echo -en " Username  : \c"
timeout


## Add new user in below array and 
array[1]=neelam
array[2]=mahesh
array[3]=rajesh
array[4]=jilpa
array[5]=feroz
array[6]=prabhat
array[7]=lincoln
array[8]=mosin
array[9]=kaustubh
array[10]=aarti
array[11]=ranita
array[12]=rang
array[13]=rahul
array[14]=satish
#array[15]=username
#array[16]=username
#array[17]=username
#array[18]=username
#array[19]=username
#array[20]=raju

		username=$choice

		if [ -z $username ]
		then
		username=dev
		else
	## Below is checking for user name - should be matching with the Array
			if [[ "$username" = "${array[1]}" ]] || [[ "$username" = "${array[2]}" ]] || \
			   [[ "$username" = "${array[3]}" ]] || [[ "$username" = "${array[4]}" ]] || \
                           [[ "$username" = "${array[5]}" ]] || [[ "$username" = "${array[6]}" ]] || \
                           [[ "$username" = "${array[7]}" ]] || [[ "$username" = "${array[8]}" ]] || \
			   [[ "$username" = "${array[9]}" ]] || [[ "$username" = "${array[10]}" ]] || \
			   [[ "$username" = "${array[11]}" ]] || [[ "$username" = "${array[12]}" ]] || \
			   [[ "$username" = "${array[13]}" ]] || [[ "$username" = "${array[14]}" ]] || \
			   [[ "$username" = "${array[15]}" ]] || [[ "$username" = "${array[16]}" ]] || \
			   [[ "$username" = "${array[17]}" ]] || [[ "$username" = "${array[18]}" ]] || \
			   [[ "$username" = "${array[19]}" ]] || [[ "$username" = "${array[20]}" ]]
			then

already_running_check

				echo -en "	$username \n"	> /tmp/upload_script_running.txt
			else
				echo -en "					 \n"
				echo -en "Enter Proper user name from below list \n"
				echo -en "					 \n"
####echo -en " Usernames : \n" ========="\n" ${array[1]}"\n" ${array[2]}"\n" ${array[3]}"\n" ${array[4]}"\n" ${array[5]}"\n" ${array[6]}"\n" ${array[7]}"\n" ${array[8]}"\n" ${array[9]}"\n" ${array[10]}"\n" ${array[11]}"\n\n"
echo -en " Usernames : \n" ========="\n" ${array[1]}"\n" ${array[2]}"\n" ${array[3]}"\n" ${array[4]}"\n" ${array[5]}"\n" ${array[6]}"\n" ${array[7]}"\n" ${array[8]}"\n" ${array[9]}"\n" ${array[10]}"\n" ${array[11]}"\n" ${array[12]}"\n" ${array[13]}"\n" ${array[14]}"\n" ${array[15]}"\n" ${array[16]}"\n" ${array[17]}"\n" ${array[18]}"\n" ${array[19]}"\n" ${array[20]}"\n\n"
			exit
			fi
		fi

	#Below  MENU will be prompt to User  

MENU="
	U  Upload Files to 253 in Same Location    
	F  Folder upload to 253
	P  Upload file(s) from (Source) to 253 (Destination) if files(s) has different path 
	1  Copy file(s) from 11/ to 1/ folder on 253 server 
	==================================================================================="
while true; do
  clear
tput cup 5 35
# Set reverse video mode
tput rev
echo -en "M A I N - M E N U \n"
tput sgr0
  echo -en "$MENU \n"                     
  echo -en " \n"                     
  echo -en " \n"                     
# Set bold mode 
tput bold
tput cup 14 15
  echo -en "Please Enter your choice in $timelimit Sec. : \c" 	
tput sgr0
timeout

  case $choice in			#As per Input Case function will run
  u|U)            			# Upload function will run when u|U is press for Upload 
     clear
	date=`/bin/date +%Y%m%d%H%M%S`  #Todays date in Year-Month-Date-Hours-Minutes-Seconds format for backup
        echo -en " 									\n"
        echo -en " 									\n"
	echo -en "Press Enter to Copy path of files to be upload After /twd/www/html/: \c"
#        echo -en " 						:\c"
#	/scripts/up_down_load/upload_download_file_list.txt \n
	read
	vim /scripts/up_down_load/upload_download_file_list.txt
			       #Below prompt to enter Source IP Address Presently its 172.20.120.205 for upload to 253 svr
        echo -en " 								\n"
	echo -en "Files to be Uploaded are 					\n"
	echo -en "`cat /scripts/up_down_load/upload_download_file_list.txt` 	\n"
        echo -en "---------------------------------------------------------	\n"
        echo -en " \n"

check

#	echo -en "Enter Source IP (172..) :\c"
#	read S_IP
	S_IP=172.20.120.205

#### PHP Syntax Checking Funtion  ###
php_syntax_chk() {
        FILE_TYPE_RE=PHP
	/usr/bin/file $file | cut -d ' ' -f 2  > /tmp/php_file_type.txt
        FILE_TYPE_OP=`cat /tmp/php_file_type.txt`
#echo -en "FILE_TYPE_OP = $FILE_TYPE_OP \n"
        if [[ $FILE_TYPE_OP == $FILE_TYPE_RE ]]
        then
            PHP_SYNT_STATUS="No syntax errors detected"
         php -ln $file |cut -d ' ' -f 1,2,3,4  >  /tmp/php_syntax_chk.txt
            PHP_SYNT_OP=`cat /tmp/php_syntax_chk.txt`
#echo -en "PHP_SYNT_OP = $PHP_SYNT_OP \n"
                if [[ $PHP_SYNT_STATUS == $PHP_SYNT_OP ]]
                then
                upload
                else
                     echo -en "$a has Syntax error, file not uploaded \n"   > /dev/null  2>&1
                     echo -en "PHP Syntax Error in :\c"  >> /tmp/files_with_syntax_error.txt
                     echo -en " $a  - file not uploaded\n"   >> /tmp/files_with_syntax_error.txt
			php -ln $file | sed 's/.tmp//g' >> /tmp/files_with_syntax_error.txt
                        echo -en "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" >> /tmp/files_with_syntax_error.txt
                        echo -en " \n" >> /tmp/files_with_syntax_error.txt
			rm $file > /dev/null  2>&1 #Deleting .tmp file
                fi
        else
#            echo -en "$file : is NOT a PHP file \n" >> /tmp/non-php_file.txt
	org_file=`echo $file | sed -e 's/\.[^\.]*$//'`  ## /twd/www/html/raju/win.html.tmp will be /twd/www/html/raju/win.html
            echo -en "$org_file : is NOT a PHP file \n" >> /tmp/non-php_file.txt
                upload
        fi
                 }
#### PHP Syntax Checking Funtion Ends here  ##

## Upload Function ##
upload()        {
		mv -v $file $a  > /dev/null  2>&1
                chown -R apache:apache $a  > /dev/null  2>&1               #Change owner and group of the file to apache
		$setfacl -m g:docurootaccess:rwx -R $a
                ls -lrth $a |awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_files_on_253_server.txt
                echo -en " \n"   > /dev/null  2>&1                                 
        if [ -f $a ]
              then
#                echo -en "--------Below files are deleted----------------------\n" >> /tmp/deleted_files.txt
                find $a.* -mtime +1 -exec ls -l  {} \; >> /tmp/deleted_files.txt  #List all old backup files before deleting which are more than one day ago
#                echo -en " \n" >> /tmp/deleted_files.txt
                find $a.* -type f -mtime +1 -exec rm  {} \;              #More than one day old backup fils are deleted from server
#                echo -en "--------Above files are Deleted--------------------------\n"
#                echo -en "=========================================================\n" >> /tmp/deleted_files.txt
              else
        clear
                echo -en "$a is not a file....\n"
                ls -ld $a
        fi
                }
### Upload funtion completes here ###
#SPB

	for p in  `cat /scripts/up_down_load/upload_download_file_list.txt` #In this file copy and paste Absolute path from /twd till the filename 
	do
		a=$base_path$p
		echo $a     				
		if
			  [ ! -d $a ]
		then
			#	if [ ! -f $a ]
			#	then
			#		echo -en "New File Uploaded OR If not Uploaded Check the file Path \n" >> /tmp/new_file_or_wrong_path.txt
			#		echo -en "$a \n" >> /tmp/new_file_or_wrong_path.txt
			#	fi
			cp -v $a $a.$date  > /dev/null  2>&1 			#Takes backup of the file in date-time format  
	                tar --remove-files -zcf $a.$date.tar.gz $a.$date        > /dev/null 2>&1
# 			scp -rP 2345 twd@$S_IP:/jailroot$a $a.tmp   > /dev/null  2>&1
 			scp -rP 2345 twd@$S_IP:$a $a.tmp   > /dev/null  2>&1
	echo -en "`ls -lt $a*` \n"   > /dev/null  2>&1

			file=$a.tmp
			php_syntax_chk
		else
                        mv -v $a $a.$date  > /dev/null  2>&1
        	        tar --remove-files -zcf $a.$date.tar.gz $a.$date        > /dev/null 2>&1
	                scp -rP 2345 twd@$S_IP:$a  $a  > /dev/null  2>&1
			chown -R apache:apache $a   > /dev/null  2>&1
	                ls -ld $a | awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_fldr_on_253_server.txt
		fi
        done
#EPB
output_format
     exit
    ;;
  f|F)         
     clear
	date=`/bin/date +%Y%m%d%H%M%S`  #Todays date in Year-Month-Date-Hours-Minutes-Seconds format for backup
        echo -en " 												\n"
        echo -en " 												\n"
	echo -en "Press Enter to copy path of Folder to be upload (After /twd/www/html/ without last /) :\c"
#        echo -en " 						:\c"
#	/scripts/up_down_load/upload_download_file_list.txt \n
	read
	vim /scripts/up_down_load/upload_download_file_list.txt
			       #Below prompt to enter Source IP Address Presently its 172.20.120.205 for upload to 253 svr
        echo -en " 								\n"
	echo -en "Folder's to be Uploaded are 					\n"
	echo -en "`cat /scripts/up_down_load/upload_download_file_list.txt` 	\n"
        echo -en "---------------------------------------------------------	\n"
        echo -en " 								\n"

check

#	echo -en "Enter Source IP (172..) :\c"
#	read S_IP
	S_IP=172.20.120.205


## Upload Function ##
upload()        {
#                        scp -rP 2345 twd@$S_IP:$a  $Folder_Parent_PATH   > /dev/null  2>&1
                        scp -rP 2345 twd@$S_IP:$a  $Folder_Parent_PATH   > /dev/null  2>&1
                        chown -R apache:apache $a   > /dev/null  2>&1
	                $setfacl -m g:docurootaccess:rwx -R $a
		        echo -en "`ls -ld $a*` \n"   > /dev/null  2>&1
                        ls -ld $a | awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_fldr_on_253_server.txt

#                echo -en "--------Below files are deleted----------------------\n" >> /tmp/deleted_files.txt
#                find $a* -type d -mtime +1 -exec ls -ld  {} \; >> /tmp/deleted_folders.txt  #List all old backup files before deleting which are more than one day ago
#                find $a* -type d -mtime +1 -exec rm -r {} \;              #More than one day old backup fils are deleted from server
#		find $a.*.tar.gz -type f -mtime +1 -exec ls -ld  {} \; /tmp/deleted_folders.txt
		find $a.*.tar.gz -type f -mtime +1 -exec ls -ld  {} \;  > /tmp/deleted_folders.txt
		find $a.*.tar.gz -type f -mtime +1 -exec rm -r {} \;  > /dev/null  2>&1
#                echo -en "--------Above files are Deleted--------------------------\n"
#                echo -en "=========================================================\n" >> /tmp/deleted_files.txt
                }
### Upload funtion completes here ###
#SPB

	for p in  `cat /scripts/up_down_load/upload_download_file_list.txt` #In this file copy and paste Absolute path from /twd till the filename 
	do
		a=$base_path$p
                echo $a
	Folder_Parent_PATH=`echo "$a" | awk -F"/" '{ $NF = ""; print $0}' | sed -e 's@ @/@g'`
	echo -en "Folder_Parent_PATH = $Folder_Parent_PATH \n"
		if
			  [ ! -d $a ]
		then
			mkdir -p $a
		upload
		else
                        mv -v $a $a.$date  > /dev/null  2>&1
                tar --remove-files -zcf $a.$date.tar.gz $a.$date
			mkdir -p $a
		upload
		fi
        done
#EPB
output_format
     exit
    ;;
  1)            
     clear
	date=`/bin/date +%Y%m%d%H%M%S`  #Todays date in Year-Month-Date-Hours-Minutes-Seconds format for backup
        echo -en " 										  \n"
        echo -en " 										  \n"
	echo -en "Press Enter to copy path of files to be upload After /twd/www/html/11/: \c"
#	/scripts/up_down_load/upload_download_file_list.txt \n"
	read
	vim /scripts/up_down_load/upload_download_file_list.txt
			       #Below prompt to enter Source IP Address Presently its 172.20.120.205 for upload to 253 svr
        echo -en " 								\n"
	echo -en "Files to be Uploaded are 					\n"
	echo -en "`cat /scripts/up_down_load/upload_download_file_list.txt` 	\n"
        echo -en "---------------------------------------------------------	\n"
        echo -en " 								\n"

check

	s=/twd/www/html/11/
	d=/twd/www/html/1/
#	echo -en "Enter Source IP (172..) (253 Server IP):\c"
#	read S_IP

#### PHP Syntax Checking Funtion  ##
php_syntax_chk() {
	echo -en "php_syntax_chk function will start now.......... \n"
        FILE_TYPE_RE=PHP
        /usr/bin/file $file | cut -d ' ' -f 2  > /tmp/php_file_type.txt
        FILE_TYPE_OP=`cat /tmp/php_file_type.txt`
#echo -en "FILE_TYPE_OP = $FILE_TYPE_OP \n"

        if [[ $FILE_TYPE_OP == $FILE_TYPE_RE ]]
        then
            PHP_SYNT_STATUS="No syntax errors detected"
         php -ln $file |cut -d ' ' -f 1,2,3,4  >  /tmp/php_syntax_chk.txt
            PHP_SYNT_OP=`cat /tmp/php_syntax_chk.txt`
#echo -en "PHP_SYNT_OP = $PHP_SYNT_OP  \n"
                if [[ $PHP_SYNT_STATUS == $PHP_SYNT_OP ]]
                then
#                     echo -en "/jailroot$a : Uploading file without syntax error \n"
                     echo -en "$a : Uploading file without syntax error \n"
                upload
                else
# org_file=`echo $file | sed -e 's/\.[^\.]*$//'`  ## /twd/www/html/raju/win.html.tmp will be /twd/www/html/raju/win.html
                     echo -en "$file has Syntax error, file not uploaded \n"
                     echo -en "PHP Syntax Error in :\c"  >> /tmp/files_with_syntax_error.txt
                     echo -en " $file  - file not uploaded\n"   >> /tmp/files_with_syntax_error.txt
                        php -ln $file >> /tmp/files_with_syntax_error.txt
                        echo -en "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" >> /tmp/files_with_syntax_error.txt
                        echo -en " \n" >> /tmp/files_with_syntax_error.txt
			echo -en "Deleting tmp file - $file \n"
			rm $file
                fi
        else
#            echo -en "$file : is NOT a PHP file \n"
#            echo -en " Uploading Non PHP file : $a \n"
                upload
        fi
                 }
#### PHP Syntax Checking Funtion Ends here  ##

## Upload Function ##
upload()        {
	echo -en "Uploading function will start now..... \n"
               cp -v $file $d_file
                chown -R apache:apache $d_file               #Change owner and group of the file to apache
                $setfacl -m g:docurootaccess:rwx -R $d_file
                ls -lrth $d_file |awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_files_on_253_server.txt
                echo -en " \n"                                  
        if [ -f $d_file ]
        then
                echo -en "--------Below files will be deleted----------------------\n"
                find $d_file* -mtime +1 -exec ls -l  {} \;           #List all old backup files before deleting which are more than one day ago
                echo -en " \n"
                find $d_file* -type f -mtime +1 -exec rm  {} \;              #More than one day old backup fils are deleted from server
                echo -en "--------Above files are Deleted--------------------------\n"
                echo -en "=========================================================\n"
        else
        	clear
                echo -en "$d_file is not a file....\n"
                ls -ld $d_file
        fi
                }
## Upload Function Ends here ##
#SPB
	for a in  `cat /scripts/up_down_load/upload_download_file_list.txt` #In this file copy and paste Absolute path from /twd till the filename 
	do
                echo $a
		file=$s$a
		d_file=$d$a    				
                	if
                        	[ ! -d $file ]
	                then
#				echo -en "Taking backup on 253 server.... pls wait \n"
        	                cp  $d_file $d_file.$date                       #Takes backup of the file in date-time format
			        echo -en "`ls -l $d_file*` \n"
	                        php_syntax_chk
	                else
                        	mv  $d_file $d_file.$date
    		                cp -r  $file $d_file
				chown -R apache:apache $d_file
	                	$setfacl -m g:docurootaccess:rwx -R $d_file
                	        ls -ld $d_file  | awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_fldr_on_253_server.txt
        	        fi
        done
#EPB
output_format
     exit
    ;;
  d|D)								# Download function will run when d|D is press for Download 
     clear     
	 echo -en " 							\n"
         echo -en " 							\n"
	 echo -en "	For Downloading file from 253 to 250 		\n"
	 echo -en " Login into 250 server and use download command 	\n"
         echo -en " 							\n"
	 echo -en " 	  Script will exit in 10 Sec.... \c		 	  "
	    sleep 10
		clear
         echo -en " 							\n"
         echo -en " 							\n"
	exit
	  #Below enter Destination IP Address Presently its 172.20.120.205 for download to 250 server
         echo -en "Press Enter and Copy Absolute path (from /twd ) of files to be download in \n"
#        /scripts/up_down_load/upload_download_file_list.txt \n"
        read
        vim /scripts/up_down_load/upload_download_file_list.txt
                               #Below prompt to enter Source IP Address Presently its 172.20.120.205 for upload to 253 svr
        echo -en " \n"
        echo -en "Files to be Downloaded are \n"
	echo -en "`cat /scripts/up_down_load/upload_download_file_list.txt` \n"
        echo -en "---------------------------------------------------------\n"
        echo -en " \n"
	echo -en "Enter Destination IP (172..) :\c"
	read D_IP
	for a in  `cat /scripts/up_down_load/upload_download_file_list.txt` 
	    do
		echo $a
#		scp -rP 2345 $a twd@$D_IP:/jailroot$a		#Download file from 253 to 250 server
		scp -rP 2345 $a twd@$D_IP:$a		#Download file from 253 to 250 server
		echo -en " \n"
                find $a* -mtime +1 -exec ls -l  {} \;      
                echo -en " \n"
                echo -en "---------------------------------------------------------\n"
                echo -en " \n"
	    done
		ls -lrth $a |awk '{ print $7,$6,$8,$9 }'
	> /scripts/up_down_load/upload_download_file_list.txt
     exit
    ;;
  p|P)        # Upload on 253 server if Source and Destination Paths are different with destination backup  on 253 serve

     clear
        echo -en " 										   	\n"
        echo -en "Press Enter and Copy Common path till file name (source and Destination files)    : 	\c"
#       /scripts/up_down_load/upload_download_file_list.txt \n
        read
        vim /scripts/up_down_load/upload_download_file_list.txt
        echo -en " 											\n"
	echo -en "Write Remaining Source Directory Path After /twd/www/html/\c"
		read sd_path
        echo -en " 									\n"
        echo -en "Write Remaining Destination Directory Path After /twd/www/html/\c"
        	read dd_path
        echo -en " 									\n"
                               #Below prompt to enter Source IP Address Presently its 172.20.120.205 for upload to 253 svr
        echo -en " \n"
    	echo -en "`cat /scripts/up_down_load/upload_download_file_list.txt` \n"
        echo -en "---------------------------------------------------------\n"
        echo -en " \n"
        echo -en "Enter Source IP (172..) : - \c"
        read S_IP

check

## Copy local files function starts here ##
copy_local_files()	{
	clear
echo -en " copy_local_files function will start now....\n"
	source_dest_files
for p in `cat /scripts/up_down_load/upload_download_file_list.txt`   #In this file copy and paste Absolute path from /twd till the filename
do
                d=$base_path$p
                echo $d
			d_file=$dd_path$d
			s_file=$sd_path$d
#               	 echo $d_file  
		if 
			[ ! -d $d_file ]	
		then
			cp -v $d_file $d_file.$date                      #Takes backup of the file in date-time format
			cp -v $s_file $d_file.tmp
			file=$d_file.tmp
#echo -en " tmp file = $file \n"
    php_syntax_chk
		else
			mv -v $d_file  $d_file.$date
                  	cp -rv $s_file $d_file
			chown -R apache:apache $d_file
			ls -ld $d_file  | awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_fldr_on_253_server.txt
		fi
done
			}
## Copy local files function Ends here #

## Upload Function Starts here ##
upload()        {
                cp -r $d_file $d_file.$date                      #Takes backup of the file in date-time format
#                scp -rP $port twd@$S_IP:$s_file $d_file           #Upload file from 250 to 253 server
		mv $d_file.tmp $d_file
                chown -R apache:apache $d_file                               #Change owner and group of the file to apache
	       	$setfacl -m g:docurootaccess:rwx -R $d_file
                ls -lrth $d_file |awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_files_on_253_server.txt
                echo -en " \n"                                  
           file=$d_file
        if [ -f $file ]
              then
                echo -en "--------Below files will be deleted----------------------\n"
                find $file* -mtime +1 -exec ls -l  {} \;           #List all old backup files before deleting which are more than one day ago
                echo -en " \n"
                find $file* -type f -mtime +1 -exec rm  {} \;              #More than one day old backup fils are deleted from server
                echo -en "--------Above files are Deleted--------------------------\n"
                echo -en "=========================================================\n"
              else
        clear
                echo -en "$file is not a file....\n"
                ls -ld $file
        fi
                }
## upload_local_files Function Ends here##

## Upload local files Function Starts here ##
upload_local_files()   {
                mv -v  $file  $d_file   #Upload file from 250 to 253 server
                chown -R apache:apache $d_file                               #Change owner and group of the file to apache
                ls -lrth $d_file |awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_files_on_253_server.txt
                echo -en " \n"                                  
        if [ -f $d_file ]
              then
                echo -en "--------Below files will be deleted----------------------\n"
                find $d_file* -mtime +1 -exec ls -l  {} \;           #List all old backup files before deleting which are more than one day ago
                echo -en " \n"
                find $d_file* -type f -mtime +1 -exec rm  {} \;              #More than one day old backup fils are deleted from server
                echo -en "--------Above files are Deleted--------------------------\n"
                echo -en "=========================================================\n"
#              else
#        clear
#                echo -en "$d_file is not a file....\n"
#                ls -ld $d_file
        fi
			}
## Upload local files Function Ends here ##

## PHP file Syntax checking Function ##
php_syntax_chk() {
        FILE_TYPE_RE=PHP
        /usr/bin/file $file | cut -d ' ' -f 2  > /tmp/php_file_type.txt
        FILE_TYPE_OP=`cat /tmp/php_file_type.txt`
        if [[ $FILE_TYPE_OP == $FILE_TYPE_RE ]]
        then
#echo -en "FILE_TYPE_OP = $FILE_TYPE_OP  \n"
echo -en "File is a PHP file - Syntax error will be check now ....: \n"
            PHP_SYNT_STATUS="No syntax errors detected"
	        php -ln $file |cut -d ' ' -f 1,2,3,4  >  /tmp/php_syntax_chk.txt 
            PHP_SYNT_OP=`cat /tmp/php_syntax_chk.txt`
                if [[ $PHP_SYNT_STATUS == $PHP_SYNT_OP ]]
                then
#		     echo -en "PHP_SYNT_OP = $PHP_SYNT_OP \n"
                     echo -en "$s_file : Uploading without syntax error \n"
	if [ $S_IP = $LOCAL_IP ]
        then
                upload_local_files
        else 
		upload
        fi
                else
                     echo -en "$s_file has Syntax error, file not uploaded \n"
                     echo -en "PHP Syntax Error in file  :\c"  >> /tmp/files_with_syntax_error.txt
                     echo -en "$s_file \n"   >> /tmp/files_with_syntax_error.txt
                        php -ln $file >> /tmp/files_with_syntax_error.txt
                        echo -en "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" >> /tmp/files_with_syntax_error.txt
                        echo -en " \n" >> /tmp/files_with_syntax_error.txt
			echo -en "Deleting tmp file - $file \n"
			rm $file
                fi
        else
#            echo -en "FILE_TYPE_OP = $FILE_TYPE_OP  \n"
            echo -en "$s_file : is NOT a PHP file \n"
            echo -en " Uploading Non PHP file : $s_file \n"
		if [ $S_IP = $LOCAL_IP ]
		then
			upload_local_files
		else
                	upload
		fi
        fi
                 }
## PHP file Syntax checking Function ##

        date=`/bin/date +%Y%m%d%H%M%S`  #Todays date in Year-Month-Date-Hours-Minutes-Seconds format for backup

## Source Destination files Function starts here ##
source_dest_files()	{
clear
echo -en "source_dest_files function will start now.......\n"
echo -en "Files to be uploaded are \n"
for p in `cat /scripts/up_down_load/upload_download_file_list.txt`   #In this file copy and paste Absolute path from /twd till the filename
do
	       d=$base_path$p
                echo $d
                d_file=$dd_path$d
                s_file=$sd_path$d
		echo -en  "Source_file = $s_file \n"
		echo -en  "Destination_file = $d_file \n"
		echo -en "\n"
done
		echo -en "If above Source and Destination files are correct then press Enter to continue : \c"
read
			}
## Source Destination files Function Ends here #

        LOCAL_IP=172.20.120.105
        if [ $S_IP = $LOCAL_IP ]
        then
                copy_local_files
	output_format
	exit
        fi
        echo -en "Press Enter Port Number of Source Server : \c"
                read port
        echo -en " \n"
        echo -en "Upload will start now ......\n"
	source_dest_files

#SPB
        for p in `cat /scripts/up_down_load/upload_download_file_list.txt`   #In this file copy and paste Absolute path from /twd till the filename
        do
		d=$base_path$p
                echo $d
                        d_file=$dd_path$d
                        s_file=$sd_path$d
                if
                        [ ! -d $d_file ]
                then
                        cp -v $d_file $d_file.$date                      #Takes backup of the file in date-time format
                        scp -rP $port twd@$S_IP:$s_file $d_file.tmp
                        file=$d_file.tmp
    php_syntax_chk
                else
                        mv -v $d_file  $d_file.$date
                        scp -rP 2345 twd@$S_IP:$s_file $d_file
	                $setfacl -m g:docurootaccess:rwx -R $d_file
                        ls -ld $d_file  | awk '{ print $7,$6,$8,$9 }'   >> /tmp/Uploaded_fldr_on_253_server.txt
                fi
        done
#EPB
    output_format
     exit
    ;;
    *) 								# All other user input results in an usage message
    clear
WRONG_CHOICE_MENU="
 	        ###   `tput bold``tput rev`WRONG CHOICE Exiting`tput sgr0`   ####
		      ====================	
			$MENU 
  					"
		tput cup 5 35
  		echo -en "$WRONG_CHOICE_MENU \n"
		tput cup 18 20
		echo -en "Script Will EXIT in 10 Sec.... \c"
		sleep 10
		del_tmp_files
		clear
		tput cup 10 4
	exit 0
    ;;
 esac 
done
