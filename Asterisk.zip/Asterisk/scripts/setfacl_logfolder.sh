#!/bin/bash
# setfacl pemission on folders /var/log/asterisk
# Dated 18Aug 2017
# Created by Raju Basutkar
#
#echo -en "Enter the File/Folder  Complete Path which was access directly : \c"
#read FLDR
FLDR='/var/log/asterisk'
/bin/setfacl -m g:logfolderaccess:rwx -R $FLDR
/bin/chown -R root:root $FLDR >/dev/null 2>&1
exit
