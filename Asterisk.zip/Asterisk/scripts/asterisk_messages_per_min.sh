#! /bin/bash
# Created by Raju 
# Dated 24May 2017
#### Exporting variable for date format, backup file name ####

START_TIME="Script Start time : `date`"
END_TIME="Script End time : `date`"
echo START_TIME=$START_TIME

PATH=/sbin:/bin:/usr/sbin:/usr/bin
export PATH=$PATH
#
#MYSQL=`which mysql`
#DBUSER='root'
#DBPASS='mys\@r0ja'

DATE=`date +%Y%m%d -d "0 day ago"`
DAY=`date +%-d "-d 1 day ago"`
#DATE=`date +%Y%m%d -d "10 day ago"`
#DAY=`date +%-d "-d 11 day ago"`

#if [[ "$DAY" == [0-9] ]]; then echo "single digit" ;else echo "double digit"; fi
echo -en "START_TIME=$START_TIME : of single or double digit day loop  \n" >> /tmp/start_end_of_single_or_double_digit_day_loop_$DATE.txt
if [[ "$DAY" == [0-9] ]]
	then
	echo "single digit day"
#zgrep failed /var/log/asterisk/messages-"$DATE".gz | grep NOTICE | grep -v completed | awk -F' ' '{print $1"  "$2" "$3" "$4}' | sort -u  > /tmp/asterisk_notice_id.txt
grep failed /var/log/asterisk/messages | grep NOTICE | grep -v completed | awk -F' ' '{print $1"  "$2" "$3}' | sort -u  > /tmp/asterisk_notice_id_$DATE.txt
	else
	echo "double digit day"
#zgrep failed /var/log/asterisk/messages-"$DATE".gz | grep NOTICE | grep -v completed | awk -F' ' '{print $1" "$2" "$3" "$4}' | sort -u  > /tmp/asterisk_notice_id.txt
grep failed /var/log/asterisk/messages | grep NOTICE | grep -v completed | awk -F' ' '{print $1" "$2" "$3}' | sort -u  > /tmp/asterisk_notice_id_$DATE.txt
fi
echo -en "END_TIME=$END_TIME : of single or double digit day loop  \n" >> /tmp/start_end_of_single_or_double_digit_day_loop_$DATE.txt
echo -en "FAILED_DATE,FAILED_REASON,FAILED_MSISDN\n" > /tmp/asterisk_failed_sip_details_"$DATE".csv

while read "a"
do
echo -en "START_TIME=$START_TIME of $a :  fetching date, reason and msisdn  \n" >> /tmp/start_end_time_in_fetching_date_reason_msisdn_$DATE.txt
#zgrep "$a" /var/log/asterisk/messages-"$DATE".gz > /tmp/session_id.txt
FAILED_DATE=`grep -F "$a" /var/log/asterisk/messages | awk -F'[]]' '{ print $1 }' | awk -F'['  '{print $2}' | sort -u`
FAILED_REASON=`grep -F "$a" /var/log/asterisk/messages | grep reason | awk -F, '{print $2}'`
FAILED_MSISDN=`grep -F "$a" /var/log/asterisk/messages | grep SIP | awk -F'/' '{print $3}' | awk -F' ' '{print $1}'`
echo -en "END_TIME=$END_TIME of $a :  fetching date, reason and msisdn  \n" >> /tmp/start_end_time_in_fetching_date_reason_msisdn_$DATE.txt
# Insert FAILED_DATE,FAILED_REASON,FAILED_MSISDN in mysql 
MYSQL_INSERT_START_TIME="MYSQL INSERT START TIME : `date`"
MYSQL_INSERT_END_TIME="MYSQL INSERT START TIME : `date`"
echo -en "MYSQL_INSERT_START_TIME=$MYSQL_INSERT_START_TIME  : line in inserting in database \n" >> /tmp/start_end_time_in_inserting_in_asterisk_db_$DATE.txt
mysql -u root -pmys\@r0ja -D asterisk <<EOF
INSERT INTO calling_status (callerid,reasoncode,time,ModifiedTime) VALUES('$FAILED_MSISDN','$FAILED_REASON','$FAILED_DATE','$FAILED_DATE');
EOF
echo -en "$FAILED_DATE,$FAILED_REASON,$FAILED_MSISDN\n" >> /tmp/asterisk_failed_sip_details_"$DATE".csv
echo -en "MYSQL_INSERT_END_TIME=$MYSQL_INSERT_END_TIME  : line in inserting in database \n" >> /tmp/start_end_time_in_inserting_in_asterisk_db_$DATE.txt
done < /tmp/asterisk_notice_id.txt
clear

scp -P2345 /tmp/asterisk_failed_sip_details_"$DATE".csv root@172.20.120.205:/twd/www/html/asterisk_active_calls/asterisk_csv_files/


echo -en "PFA Asterisk Failed SIP Details.csv file \n" > /tmp/asterisk_messages_script_email_msg.txt
echo -en "START_TIME : $START_TIME \n" >>  /tmp/asterisk_messages_script_email_msg_$DATE.txt
echo -en "END_TIME   : $END_TIME \n"  >>  /tmp/asterisk_messages_script_email_msg_$DATE.txt

/sbin/sendEmail -f admin@altmond.thinkwalnut.com -t amit@thinkwalnut.com -cc raju@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Asterisk Failed SIP Details" -o message-file=/tmp/asterisk_messages_script_email_msg.txt  -a /tmp/asterisk_failed_sip_details_"$DATE".csv

echo END_TIME=$END_TIME

exit
