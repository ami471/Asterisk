#!/bin/bash
# Created by Raju Basutkar
# Asterisk script runs every second
# Dated 30 Jan 2017
#
clear
blank_line()    {
        echo  " "
                }

pause()         {
   read r
                }

#while sleep 1
#do
#echo "`date`"
#done

#for ((a=1; a <= 59 ; a++))
for ((a=1; a <= 60 ; a++))
do
	sleep 1
   echo "`date` ==> Welcome $a times."
done
