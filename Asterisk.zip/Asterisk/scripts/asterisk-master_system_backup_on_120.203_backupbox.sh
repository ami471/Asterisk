#!/bin/sh
# Created by Raju 
# Dated 15March 2017
#### Exporting variable for date format, backup file name ####
DATE_MONTH=`date +%d-%m-%Y-%a`
NOW=`date +%d-%b`
cur_file=`echo /TWD_ASTERISK_MASTER_backup/TWD_ASTERISK_MASTER_SYSTEM-$DATE_MONTH.tar.gz`
script_file=`echo /TWD_ASTERISK_MASTER_backup/TWD_ASTERISK_MASTER_SCRIPTS-$DATE_MONTH.tar.gz`

export PATH

mkdir /TWD_ASTERISK_MASTER_backup
clear

#### Tar process ####**
echo "Backup File name $cur_file. taking backup...."
tar -zcf $cur_file /etc/rc.local /etc/exports  /etc/httpd  /etc/fstab /etc/passwd /etc/shadow /etc/group /etc/vsftpd* /etc/php.ini /var/spool/cron/*   /etc/asterisk/*   > /dev/null 2>&1
tar -zcf  $script_file  /scripts/*  > /dev/null 2>&1

### local backup done.
echo "Transferring file to 200.203 OMV using FTP..."

#### FTP on 172.20.200.203 OMV  Storage Server ####
#REMOTE_FILE_1=`echo /dcbackup/asterisk_master/system_files/TWD_ASTERISK_MASTER-$DATE_MONTH.tar.gz`
#SCRIPT_REMOTE_FILE=`echo /dcbackup/asterisk_master/system_files/TWD_ASTERISK_MASTER_SCRIPTS-$DATE_MONTH.tar.gz`
#HOST='172.20.200.203'
#USER='dcbackup'
#PASSWD='D(B@Ckup'
#FILE=`echo $cur_file`
#SCRIPT_LOCAL_FILE=`echo $script_file`
#ftp -n $HOST <<END_SCRIPT
#quote USER $USER
#quote PASS $PASSWD
#bi
#put $FILE $REMOTE_FILE_1
#put $SCRIPT_LOCAL_FILE $SCRIPT_REMOTE_FILE
#quit
#END_SCRIPT
###### 

scp -P2345 $cur_file  $script_file twd@172.20.120.203:/asterisk-master/scripts_system_files/
#scp -P2345 $script_file twd@172.20.120.203:/asterisk-master/scripts/
#echo "FTP Done"
echo "TWD ASTERISK MASTER Backup Successfully taken on $DATE_MONTH" > /TWD_ASTERISK_MASTER_backup/BACKUP_STATUS_$DATE_MONTH.txt

### Garbage Control

rm -rf /TWD_ASTERISK_MASTER_backup/TWD_ASTERISK_MASTER-`date +%d-%m-%Y-%a --date="3 days ago"`.txt
rm -r /TWD_ASTERISK_MASTER_backup/BACKUP_STATUS_`date +%d-%m-%Y-%a --date="3 days ago"`.txt

#### Mail for backup done to tsg team ####
#mail -s "Backup Status for 252" tsg@thinkwalnut.com < /backup/BACKUP_STATUS_$DATE_MONTH
sendEmail -f admin@almond.thinkwalnut.com -t tsg@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for 252" -o message-file=/backup/BACKUP_STATUS_$DATE_MONTH.txt
#sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for ASTERISK MASTER System" -o message-file=/backup/BACKUP_STATUS_$DATE_MONTH.txt
