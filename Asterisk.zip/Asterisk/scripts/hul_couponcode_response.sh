# !/bin/bash
clear
blank_line()    {
        echo  " "
                }

pause()		{		
   read r
		}

PATH=$PATH
export PATH
echo $PATH

echo `date` > /tmp/hul_couponcode_script_time.txt
MYSQL=`which mysql`
CURL=`which curl`
DBUSER='root'
DBPASS='mys\@r0ja'

#select src from cdr
DB='asterisk'
TBL='hul_couponcode'

# Below is working command
current_date_time=`date "+%Y-%m-%d %H:%M:%S" -d "60 sec ago"`
current_date_time_60sec_ago=`date "+%Y-%m-%d %H:%M:%S" -d "120 sec ago"`
echo "current_date_time=$current_date_time"
echo "current_date_time_60sec_ago=$current_date_time_60sec_ago"
mysql -sND asterisk -u root -pmys\@r0ja -e "select callerid from hul_couponcode where  start_time between '$current_date_time_60sec_ago' AND '$current_date_time' and status = 'NOANSWER' and attempt >= 3;" > /tmp/hul_couponcode_response.txt
for call in `cat /tmp/hul_couponcode_response.txt`
do
COUPON_CODE=`mysql -sND asterisk -u root -pmys\@r0ja -e "select coupon_code from hul_couponcode where callerid = $call and status = 'NOANSWER' and attempt >= 3  order by callerid_count desc limit 1 ;"`
SENDSMSURL="http://172.20.120.105/13/api/obd_response.php?msisdn=$call&code=$COUPON_CODE&status=NOANSWER&duration=0&timestamp=$current_date_time_60sec_ago"
echo $SENDSMSURL >> /tmp/hul_couponcode_response_sendsmsurl.txt
$CURL $SENDSMSURL
done
exit
