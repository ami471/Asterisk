#!/bin/bash
# Created by Raju Basutkar
# Dated 25 July 2017
#tree -ifdF /var/log/httpd/ | grep httpd | grep -v /var/log/httpd/4 | grep -v 2bdelete > /scripts/httpd_logrotate
#echo -en "/twd/www/html/1/sms/app/logs
#/twd/www/html/1/m/6/sam/logs
#/twd/www/html/1/m/logs/wap_logs
#/twd/www/html/13/hamam/plant
#/twd/www/html/13/sms_panel/dump\n" >> /scripts/httpd_logrotate
#sed -i -e 's/$/\/*log/g' /scripts/httpd_logrotate
# sed  -i -e '1i ##Created by Raju Basutkar # from /scripts/httpd_logrotate_creation.sh script ######################################' /scripts/httpd_logrotate
#echo -en "{\n su apache apache \n daily \n missingok \n copytruncate \n rotate 365000 \n compress \n dateext \n }" >> /scripts/httpd_logrotate
exit
