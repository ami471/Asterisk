#!/bin/bash
# Created By Raju Basutkar
# Created Date 04 Dec 2014
# Delete zero size log file's which remains in system after logrotation
# Copied from 253 server on 29March 2017
# Modified on 08 Jan 2015 added /var/log/crontab_root/ directory 

clear

# Required Variables
cur_date=`date +%Y%m%d`
var_log_dir=`echo "/var/log/sms/
/var/log/crontab_root/"`

DEST_DIR=/home/deleted_zero_size_log_file

# find /var/log/httpd/ -size 0 -print` | awk '{print $9}'
# find /var/log/crontab_root/ -size 0 -print` | awk '{print $9}'

for i in $var_log_dir
do
#ls -l `find $i -size 0 -print` | awk '{print $9}'  > /tmp/var_log_zero_size_file.txt
#find /var/log/httpd/ -type f -empty >
find $i -type f -empty > /tmp/var_log_zero_size_file.txt
	for a in `cat /tmp/var_log_zero_size_file.txt`
	do
	mkdir -p $DEST_DIR/$cur_date
	mv -v $a $DEST_DIR/$cur_date/
	echo -en "-----------------------------\n"
	done
done

exit
