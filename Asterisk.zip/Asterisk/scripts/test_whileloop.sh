#!/bin/bash
#OLD_IFS=$IFS
#IFS=$'\n'
while read line
do
    echo "$line"
done < /tmp/asterisk_notice_id.txt
#done < /tmp/forr_loop_test_content.txt
#IFS=$OLD_IFS

