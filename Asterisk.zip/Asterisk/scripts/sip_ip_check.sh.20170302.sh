#! /bin/bash
# Created by Raju Basutkar
# Dated 08 Feb 2017

clear
blank_line()    {
        echo  " "
                }

pause()         {
   read r
                }


#if [ "$#" = "0" ];
#then
#echo "Usage: $0 "
#exit 1
#fi

#echo DATE=`date`
#echo OPATH=$PATH
#PATH=$PATH:/bin/sh:/sbin/sh:/sbin/sendEmail
PATH=$PATH:/bin:/sbin/
export PATH
#echo NPATH=$PATH

host=10.0.93.2

if ping -c 4 $host > /tmp/sip_ip_ping_status.txt
then
ping_result="OK" 
echo -en "Ping OK\n"
else
ping_result="NOT Pinging"
#echo -en "\n"  >> /tmp/sip_ip_ping_status.txt
echo "SIP IP $host Ping Status : $ping_result" >> /tmp/sip_ip_ping_fail_status.txt
### SIP IP PING STATUS MAIL ####
#sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com, amit@thinkwalnut.com, imran@thinkwalnut.com  -cc sourava@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "SIP IP Ping Status" -o message-file=/tmp/sip_ip_ping_status.txt
/sbin/sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "SIP IP FAIL" -o message-file=/tmp/sip_ip_ping_status.txt
fi

exit
