#!/bin/sh
# Created by Raju 
# Dated 15March 2017
#### Exporting variable for date format, backup file name ####
DATE_MONTH=`date +%d-%m-%Y-%a`

clear

#### Tar process ####**
 > /tmp/lifebouy_obd_log.txt
/usr/bin/find /var/log/asterisk -mtime -1 -type f \( -iname "*.gz" \) | grep lifebouy_obd  >> /tmp/lifebouy_obd_log.txt
 sed -i s@/var/log/asterisk/lifebouy_obd/@@g  /tmp/lifebouy_obd_log.txt

echo "Transferring file to 200.203 OMV using FTP..."

HOST='172.20.200.203'
USER='dcbackup'
PASSWD='D(B@Ckup'

for log in `cat /tmp/lifebouy_obd_log.txt`
do
#### FTP on 172.20.200.203 OMV  Storage Server ####
LOCAL_FILE=`echo $log`
REMOTE_FILE=/dcbackup/asterisk_master/varlogs/lifebouy_obd_log_backup/$log 
ftp -n $HOST <<END_SCRIPT
quote USER $USER
quote PASS $PASSWD
bi
hash
put $LOCAL_FILE  $REMOTE_FILE
quit
END_SCRIPT
###### 

echo "FTP Done"
done

echo "TWD ASTERISK MASTER Backup Successfully taken on $DATE_MONTH" > /tmp/BACKUP_STATUS_asterisk_lifebouy_obd_log_$DATE_MONTH.txt

### Garbage Control
> /tmp/lifebouy_obd_log.txt
#rm -rf /TWD_ASTERISK_MASTER_logbackup/TWD_ASTERISK_MASTER_logbackup-`date +%d-%m-%Y-%a --date="3 days ago"`.txt
rm -r /tmp/BACKUP_STATUS_asterisk_lifebouy_obd_log_`date +%d-%m-%Y-%a --date="3 days ago"`.txt

#### Mail for backup done to tsg team ####
#mail -s "Backup Status for 252" tsg@thinkwalnut.com < /backup/BACKUP_STATUS_asterisk_log_$DATE_MONTH
#sendEmail -f admin@almond.thinkwalnut.com -t tsg@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for 252" -o message-file=/backup/BACKUP_STATUS_asterisk_log_$DATE_MONTH.txt
#sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for ASTERISK MASTER Lifebouy Logs" -o message-file=/backup/BACKUP_STATUS_asterisk_lifebouy_obd_log_$DATE_MONTH.txt
