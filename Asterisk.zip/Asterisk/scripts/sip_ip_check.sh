#! /bin/bash
# Created by Raju Basutkar
# Copied from Old Asterisk Server  Dated 15 March 2017
# New Date 26 March 2019
#

clear
blank_line()    {
        echo  " "
                }

pause()         {
   read r
                }


#if [ "$#" = "0" ];
#then
#echo "Usage: $0 "
#exit 1
#fi

#echo DATE=`date`
#echo OPATH=$PATH
#PATH=$PATH:/bin/sh:/sbin/sh:/sbin/sendEmail
PATH=$PATH:/bin:/sbin/
export PATH
#echo NPATH=$PATH

sip_ip=10.50.146.210
#MDN username : Raju Amit Amit Sourav 
MDN='7738154618 09730641180 9967999427'
SEND_MSG_OK='SIP+IP+10.50.146.210+is+OK'
SEND_MSG_NOT_OK='SIP+IP+10.50.146.210+NOT+Pinging+from+both+servers+Pls+Call+TSG+on+7738154618'
# echo `date` | grep IST > /tmp/sip_ip_ping_status.txt ; ping -c 2 $sip_ip || ssh -p2345 root@172.20.120.53 ping -c 2 $sip_ip  >> /tmp/sip_ip_ping_status.txt
echo `date` | grep IST > /tmp/sip_ip_ping_status.txt
if ping -c 2 $sip_ip >> /tmp/sip_ip_ping_status.txt || ssh -p2345 root@172.20.120.143 ping -c 2 $sip_ip  >> /tmp/sip_ip_ping_status.txt
then
ping_result="OK" 
# for a in $MDN  
# do 
#	curl "http://172.20.120.110:11087/cgi-bin/sendsms?username=twdsmsc&password=twdknn31&from=HULwin&to=$a&text=$SEND_MSG_OK" 
# done
#sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u  "SIP IP Ping Status : Pinging from Master Asterisk server" -o message-file=/tmp/sip_ip_ping_status.txt
else
ping_result="SIP IP NOT Pinging from Both server's"  >> /tmp/sip_ip_ping_status.txt
 for a in $MDN  
 do 
 echo $a
#	curl "http://172.20.120.110:11087/cgi-bin/sendsms?username=twdsmsc&password=twdknn31&from=HULwin&to=$a&text=$SEND_MSG_NOT_OK" 

### SIP IP PING STATUS MAIL ####
#sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com, imran@thinkwalnut.com, amit@thinkwalnut.com -cc sourava@thinkwalnut.com  -s 172.20.120.202:2625 -xu email -xp @lm0nD -u  "SIP IP Ping Status from Master Asterisk Server : SIP IP NOT Pinging from Both server's" -o message-file=/tmp/sip_ip_ping_status.txt
#sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com -cc imran@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "SIP IP NOT Pinging from Both server's" -o message-file=/tmp/sip_ip_ping_status.txt
 done
fi
exit
