#!/bin/sh
# Created by Raju 
# Dated 15March 2017
#### Exporting variable for date format, backup file name ####
DATE_MONTH=`date +%d-%m-%Y-%a`
NOW=`date +%d-%b`
cur_file=`echo /TWD_ASTERISK_MASTER_logbackup/TWD_ASTERISK_MASTER-$DATE_MONTH.tar.gz`
DATE=`date +%d%m%Y -d "0 days ago"`
DATE_1=`date +%d%m%Y -d "1 days ago"`

#mkdir /TWD_ASTERISK_MASTER_lifebouy_logbackup
clear

#### Tar process ####**
cd /var/log/asterisk/lifebouy
#cd /home/raju/
tar -zcvf lifebouy_"$DATE_1".tar.gz  "$DATE_1"
### Tar Process Complete on Local Server ###

echo "Transferring file to 200.203 OMV using FTP..."

#### FTP on 172.20.200.203 OMV  Storage Server ####
HOST='172.20.200.203'
USER='dcbackup'
PASSWD='D(B@Ckup'
FILE=lifebouy_"$DATE_1".tar.gz
ftp -n $HOST <<END_SCRIPT
quote USER $USER
quote PASS $PASSWD
bi
hash
cd /dcbackup/asterisk_master/varlogs/lifebouy_log_backup
put $FILE 
quit
END_SCRIPT
###### 

echo "FTP Done"
echo "TWD ASTERISK MASTER Bfebouy_log_backup Successfully taken on $DATE_MONTH" > /tmp/BACKUP_STATUS_asterisk_lifebouy_log_$DATE_MONTH.txt

#ssh -p2345 root@172.20.200.203 du -sh /databackup/servers/DC/asterisk_master/varlogs/lifebouy_log_backup/$FILE >>  /tmp/BACKUP_STATUS_asterisk_lifebouy_log_$DATE_MONTH.txt
ssh -p2345 root@172.20.200.203 tar -ztvf /databackup/servers/DC/asterisk_master/varlogs/lifebouy_log_backup/$FILE >>  /tmp/BACKUP_STATUS_asterisk_lifebouy_log_$DATE_MONTH.txt

#### Mail for backup done to tsg team ####
#mail -s "Backup Status for 252" tsg@thinkwalnut.com < /backup/BACKUP_STATUS_asterisk_log_$DATE_MONTH
#sendEmail -f admin@almond.thinkwalnut.com -t tsg@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for 252" -o message-file=/backup/BACKUP_STATUS_asterisk_log_$DATE_MONTH.txt
sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com -cc amit@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "lifebouy_log_backup Status for ASTERISK MASTER Lifebouy Logs" -o message-file=/tmp/BACKUP_STATUS_asterisk_lifebouy_log_$DATE_MONTH.txt
