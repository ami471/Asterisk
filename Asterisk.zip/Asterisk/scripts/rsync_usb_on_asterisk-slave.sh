#!/bin/bash
# rsync 10TB  /usb/ on asterisk slave on /usb 
# Dated 06 June 2021
# Created by Raju Basutkar
#
/bin/rsync  -azPvr /usb/ -e 'ssh -p 2345' twd@172.20.120.143:/usb/
exit
