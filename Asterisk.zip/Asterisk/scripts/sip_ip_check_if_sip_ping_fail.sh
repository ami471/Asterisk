#! /bin/bash
# Created by Raju Basutkar
# Dated 08 Feb 2017

clear
blank_line()    {
        echo  " "
                }

pause()         {
   read r
                }


#if [ "$#" = "0" ];
#then
#echo "Usage: $0 "
#exit 1
#fi

#echo DATE=`date`
#echo OPATH=$PATH
#PATH=$PATH:/bin/sh:/sbin/sh:/sbin/sendEmail
PATH=$PATH:/bin:/sbin/:/usr/sbin/
export PATH
#echo NPATH=$PATH

#host=10.0.93.2
master_sip_ip=10.1.1.1
slave_sip_ip=10.1.1.1
master_svr_ip=172.20.120.54
slave_svr_ip=172.20.120.53

if ping -c 4 $sip_ip > /tmp/sip_ip_ping_status.txt
then
ping_result="OK" 
		echo -en "ssh root@$slave_svr_ip -p2345 ifdown eno2 ## Down eno2 on Slave  \n"
exit
else
ping_result="NOT Pinging"
#echo -en "\n"  >> /tmp/sip_ip_ping_status.txt
echo "SIP IP $sip_ip Not Pinging from Master \n"
echo -en "checking slave servers \n"
#ping 172.20.120.53


if ping -c 4 $slave_svr_ip 
then
slave_svr_ping_result="OK"
# Slave IP $slave_svr_ip is rechable, checking ping of sip IP from slave
	if 
	then
		ssh root@$slave_svr_ip -p2345 ping -c 2 $slave_sip_ip
		echo -en "SIP is pinging from Slave\n"
		# As SIP IP is not pinging from Master and pinging from slave starting $slave_sip_ip  from slave
		mv /home/raju/slave_sip_ip_switch_test.txt /home/raju/slave_sip_ip_switch_test_1.txt #moving master sip ip to /root
		ssh root@$slave_svr_ip -p2345 cp -vf /home/raju/slave_sip_ip_switch_test.txt /home/raju/slave_sip_ip_switch_test_1.txt #ssh on slave and copy slave IP eno2 from /root 
		ssh root@$slave_svr_ip -p2345 systemctl status network # restart Network on Slave
		echo -en "SIP is now active from Slave server \n"
	fi
else
	echo -en "Slave Server is Not pinging \n"
	echo -en "ALERT Master SIP IP $master_sip_ip is not pinging - and Slave Server IP $slave_svr_ip is also not pinging from Master"
	echo -en "SIP and Slave is Down \n"

fi

### SIP IP PING STATUS MAIL ####
#sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com, amit@thinkwalnut.com, imran@thinkwalnut.com  -cc sourava@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "SIP IP Ping FAIL" -o message-file=/tmp/sip_ip_ping_status.txt
/sbin/sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "SIP IP Ping Status" -o message-file=/tmp/sip_ip_ping_status.txt
fi

exit
