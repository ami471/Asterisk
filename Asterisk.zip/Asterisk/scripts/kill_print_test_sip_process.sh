#!/bin/bash
## This script kills Amit's /home/amit/print_test.pl which is running more than 2minitues
## Set on Amit request
# Dated 15 Nov. 2019
# Created by raju Basutkar
#
clear
PROCESS_TIME=`ps ax | grep [p]rint_test_sip.pl | awk -F: '{print $1}' | awk -F' ' '{print $4}'`
KILL=`which kill`
#PROCESS_TIME=`ps ax | grep [p]rint_test.pl | awk -F: '{print $1}' | awk -F' ' '{print $4}'` ;  for a in $PROCESS_TIME ; do echo $a ; if [[ $a > 3 ]] ; then echo _$a ; PID=`ps ax | grep [p]rint_test.pl | grep $a | awk -F' ' '{print $1}'`; echo PID=$PID ; fi ; done


for a in $PROCESS_TIME 
do 
	if [ "$a" -gt "2" ] 
	then 
	echo "Process running more than 2 mins will be kill now : Process ID $a"
	PID=`ps ax | grep [p]rint_test_sip.pl | grep $a | awk -F' ' '{print $1}'`
	echo "/bin/kill -9 $PID"
	$KILL -9 $PID
	else
	PID=`ps ax | grep [p]rint_test_sip.pl | grep $a | awk -F' ' '{print $1}'`
	echo "Process ID is less than 2"
	echo "Not killing PID=$PID"
	fi  
done
