#!/bin/bash
# Created by Raju Basutkar
# Dated 06 Dec 2018
# This script created /scripts/httpd_logrotate for /var/log/httpd/ logs rotation 
# Run this script atleast 30mns before /scripts/httpd_logrotate script
tree -ifdF /var/log/httpd/ | grep httpd | grep -v 2bdelete > /scripts/httpd_logrotate
sed -i -e 's/$/\/*log/g' /scripts/httpd_logrotate
#split -d --number=l/4 /scripts/httpd_logrotate /scripts/httpd_logrotate_
sed  -i -e '1i ##Created by Raju Basutkar # from /scripts/httpd_logrotate_creation.sh script ######################################' /scripts/httpd_logrotate
echo -en "{\n su apache apache \n daily \n missingok \n notifempty \n copytruncate \n rotate 365000 \n compress \n dateext \n }" >> /scripts/httpd_logrotate
/bin/chmod -R 775 /var/log/httpd
exit
