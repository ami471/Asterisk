#! /bin/bash
# Created by Raju Basutkar
# Dated 08 Feb 2017

clear
blank_line()    {
        echo  " "
                }

pause()         {
   read r
                }


#if [ "$#" = "0" ];
#then
#echo "Usage: $0 "
#exit 1
#fi

#echo DATE=`date`
#echo OPATH=$PATH
#PATH=$PATH:/bin/sh:/sbin/sh:/sbin/sendEmail
PATH=$PATH:/bin:/sbin/:/usr/sbin/
export PATH
#echo NPATH=$PATH

#host=10.0.93.2
master_sip_ip=10.1.1.1
slave_sip_ip=10.1.1.1
master_svr_ip=172.20.120.54
slave_svr_ip=172.20.120.53

if ping -c 4 $sip_ip 
then
ping_result="OK" 
echo -en "SIP is Pinging from Slave, Check and switch back to Master \n"
echo -en "Alert by sms amd email \n"
else
ssh root@$master_svr_ip -p2345 ping -c 2 $master_sip_ip
ping_result="NOT PINGING" 
exit
