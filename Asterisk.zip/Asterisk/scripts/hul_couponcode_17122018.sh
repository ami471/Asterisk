# !/bin/bash
clear
blank_line()    {
        echo  " "
                }

pause()		{		
   read r
		}

PATH=$PATH
export PATH
echo $PATH

echo `date` > /tmp/hul_couponcode_script_time.txt
MYSQL=`which mysql`
CURL=`which curl`
DBUSER='root'
DBPASS='mys\@r0ja'

#select src from cdr
DB='asterisk'
TBL='hul_couponcode'

# Below is working command
mysql -D asterisk -u root -pmys\@r0ja -e 'delete from hul_couponcode where attempt > 4;'
mysql -D asterisk -u root -pmys\@r0ja -e 'select callerid from hul_couponcode where status = "NOANSWER" and attempt < 3 and ModifiedTime <= NOW()' > /tmp/hul_couponcode_test_1.txt
cat /tmp/hul_couponcode_test_1.txt | awk -F [^0-9] '{print $1}' | awk 'NF' > /tmp/hul_couponcode_test.txt

for call in `cat /tmp/hul_couponcode_test.txt`
do
echo call=$call
DATE=`date +%d%m%Y-%H%M`
FILENAME=Incoming-hul_couponcode_test-"$call".call
echo FILENAME=$FILENAME

echo "Channel: DAHDI/g0/$call" >> /tmp/$FILENAME
echo "MaxRetries: 0" >> /tmp/$FILENAME
echo "RetryTime: 60000" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo "Context: hindustan_unilever" >> /tmp/$FILENAME
echo "Extension: _x." >> /tmp/$FILENAME
echo "Priority: 1" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo debug_call =  $call
chmod 777 /tmp/$FILENAME

ls -lrth /tmp/$FILENAME
echo "ls -lrth /tmp/$FILENAME"

ATTEMPT_CALL_TEST=`mysql -sND asterisk -u root -pmys\@r0ja -e "select attempt from hul_couponcode where callerid = '$call' and status = 'NOANSWER' and attempt = 3 order by callerid_count desc limit 1 ;"`
echo "ATTEMPT_CALL_TEST=$ATTEMPT_CALL_TEST" 
echo "ATTEMPT_CALL_TEST=$ATTEMPT_CALL_TEST" > /tmp/attempt_call_test.txt
mv -v /tmp/$FILENAME /var/spool/asterisk/outgoing/
sleep 0
mysql -D asterisk -u root -pmys\@r0ja -e "update hul_couponcode set attempt = attempt +1 where callerid = '$call' order by callerid_count desc limit 1"
mysql -D asterisk -u root -pmys\@r0ja -e "UPDATE hul_couponcode SET ModifiedTime = DATE_ADD(ModifiedTime, INTERVAL 15 SECOND) WHERE callerid = '$call' and status = 'NOANSWER' and attempt < 2 order by callerid_count desc limit 1"

SEND_SMS=`mysql -D asterisk -u root -pmys\@r0ja -e "select coupon_code from hul_couponcode where callerid = $call and status = 'NOANSWER' and attempt >= 3  order by callerid_count desc limit 1 ;"`
echo "SEND_SMS=$SEND_SMS"
SEND_SMS_STATUS=`echo $SEND_SMS | awk -F' '  '{print $2}'`
echo "SEND_SMS_STATUS=$SEND_SMS_STATUS"

urlencode() {
    # urlencode <string>
    local length="${#1}"
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf "$c" ;;
            *) printf '%s' "$c" | xxd -p -c1 |
                   while read c; do printf '%%%s' "$c"; done ;;
        esac
    done
}

STATUS=`mysql -sND asterisk -u root -pmys\@r0ja -e "select status from hul_couponcode where callerid = $call and attempt = 3 order by callerid_count desc limit 1;"`
echo "ATTEMPT_CALL_TEST=$ATTEMPT_CALL_TEST"
echo "ATTEMPT_CALL_TEST=$ATTEMPT_CALL_TEST" > /tmp/ATTEMPT_CALL_TEST.txt

if [[ $ATTEMPT_CALL_TEST == 3 ]]
   then
 	current_date_time="`date "+%Y-%m-%d %H:%M:%S"`";
	echo $current_date_time;
	SEND_SMS_URL="http://172.20.120.105/13/api/obd_response.php?msisdn=$call&code=$SEND_SMS_STATUS&status=NOANSWER&duration=0&timestamp=$current_date_time"
       $CURL $SEND_SMS_URL
	echo "Success" > /tmp/success_status_test.txt
	echo "SEND_SMS_URL=$SEND_SMS_URL" >> /tmp/success_status_test.txt
	echo "SEND_SMS_URL=$SEND_SMS_URL"
else
	echo "Unsuccess" 
	echo "Unsuccess" > /tmp/success_status_test.txt
fi

done
rm /tmp/hul_couponcode_test_1.txt
rm /tmp/hul_couponcode_test.txt
echo `date` >> /tmp/hul_couponcode_script_time.txt
echo "==================================" >> /tmp/hul_couponcode_script_time.txt
exit
