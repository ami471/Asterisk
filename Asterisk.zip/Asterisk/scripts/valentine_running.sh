#! /bin/bash

clear
blank_line()    {
        echo  " "
                }

pause()		{		
   read r
		}

MYSQL=`which mysql`
CURL=`which curl`
DBUSER='root'
DBPASS='amit1234'
#PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin:/home/housie.sh
#export $PATH

#select src from cdr
DB='asterisk'
TBL='valentine_call'


# Below is working command
mysql -D asterisk -u root -pamit1234 -e 'select callerid from valentine_call where status = "NOANSWER" and attempt < 5 and ModifiedTime <= NOW()' > /tmp/call_1.txt
cat /tmp/call_1.txt | awk -F [^0-9] '{print $1}' | awk 'NF' > /tmp/call.txt

for call in `cat /tmp/call.txt`
do
echo call=$call
DATE=`date +%d%m%Y-%H%M`
FILENAME=Incoming-"$call".call
echo FILENAME=$FILENAME

echo "Channel:SIP/tatasip/$call" >> /tmp/$FILENAME
echo "CallerID: 62323200" >> /tmp/$FILENAME
echo "MaxRetries: 0" >> /tmp/$FILENAME
echo "RetryTime: 60000" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo "Context: valentine" >> /tmp/$FILENAME

echo "Extension: _x." >> /tmp/$FILENAME
echo "Priority: 1" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo debug_call =  $call
chmod 777 /tmp/$FILENAME

mv /tmp/$FILENAME /var/spool/asterisk/outgoing
sleep 0
mysql -D asterisk -u root -pamit1234 -e "update valentine_call set attempt = attempt +1 where callerid = '$call'" 
mysql -D asterisk -u root -pamit1234 -e "UPDATE valentine_call SET ModifiedTime = DATE_ADD(ModifiedTime, INTERVAL 15 SECOND) WHERE callerid = '$call' and status = 'NOANSWER' "
ATTEMPT=`mysql -D asterisk -u root -pamit1234 -e "select attempt from valentine_call where status = 'NOANSWER' and callerid = '$call';"`
ATTEMPT_COUNT=`echo  $ATTEMPT | awk -F' '  '{print $2}'`

if [[ $ATTEMPT_COUNT = 5 ]]
   then
	URL="http://172.20.120.105/13/sunlight/api/vday_response.php?callerid=$call&status='CONGESTION'"
	$CURL $URL
fi

#   if [[ $ATTEMPT_COUNT=5 ]]
#        then
#                echo "More than one process is running"
#           else
#               echo "only one process is running"
#  fi


done
rm /tmp/call_1.txt
rm /tmp/call.txt
exit
