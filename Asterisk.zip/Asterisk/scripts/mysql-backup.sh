#!/bin/bash
# Copied by Raju Basutkar from AWS Mysql Slave server on 03 Nov 2018
# System + MySQL backup script
# Copyright (c) 2008 Marchost
# This script is licensed under GNU GPL version 2.0 or above
# ---------------------------------------------------------------------

######TO BE MODIFIED#####

### System Setup ###
#BACKUP="/mysql-data/backup"
BACKUP="/backup/mysql_backup"
mkdir -p $BACKUP	# added on 01 Nov 2018

### MySQL Setup ###
MUSER="root"
MPASS="mys@r0ja"
MHOST="localhost"

######DO NOT MAKE MODIFICATION BELOW#####

### Binaries ###
TAR="$(which tar)"
GZIP="$(which gzip)"
MYSQL="$(which mysql)"
MYSQLDUMP="$(which mysqldump)"


### Today + hour in 24h format ###
NOW=$(date +"%d-%m-%Y")
OLD=$(date +%d-%m-%Y -d "-3 day")
OLD1=$(date +%d-%m-%Y -d "-6 day")

### Create daily dir ###
#mkdir $BACKUP/$NOW
mkdir -p $BACKUP/$NOW

### Get all databases name ###
DBS="$($MYSQL -u $MUSER -h $MHOST -p$MPASS -Bse 'show databases')"
for db in $DBS
do
    FILE=$BACKUP/$NOW/$db.sql.gz
    echo $db; $MYSQLDUMP --single-transaction --socket=/var/lib/mysql/mysql.sock -u $MUSER -h $MHOST -p$MPASS $db | $GZIP -9 > $FILE
done;

### Compress all tables in one nice file to upload ###
ARCHIVE=$BACKUP/$NOW.tar.gz
ARCHIVED=$BACKUP/$NOW

$TAR -czvf $ARCHIVE $ARCHIVED

#########################################################################################################
SCP="$(which scp)"
HOST='172.20.120.203'
#HOST='172.20.200.27'
PORT='2345'
USER='twd'
DEST_FOLDER='/asterisk-master/mysql_backup'
FILE=`echo $ARCHIVE`
$SCP -P$PORT $ARCHIVE $USER@$HOST:$DEST_FOLDER/asterisk-master_mysql_$NOW.tar.gz

#### FTP COMPLETED ####
echo "SCP Done on Backupbox 172.20.200.27 server"
echo "Backup Successfully taken on $nal" > $BACKUP/BACKUP_STATUS_$nal
###############
LOCAL_FILE_SIZE=`du -s /backup/mysql_backup/$NOW.tar.gz | awk -F' ' '{print $1}'`
#LOCAL_FILE_SIZE=`du -s /backup/mysql_backup/01-11-2018.tar.gz | awk -F' ' '{print $1}'`
#BACKUP_FILE_SIZE=`ssh -p2345 twd@172.20.200.27 du -s /asterisk-master/mysql_backup/asterisk-master_mysql_$NOW.tar.gz | awk -F' ' '{print $1}'`
BACKUP_FILE_SIZE=`ssh -p2345 twd@$HOST du -s /asterisk-master/mysql_backup/asterisk-master_mysql_$NOW.tar.gz | awk -F' ' '{print $1}'`
if [[ $LOCAL_FILE_SIZE == $BACKUP_FILE_SIZE ]]
then
        echo -en "Backup Successfully taken on $NOW \n BACKUP_FILE_SIZE is same as LOCAL_FILE_SIZE " > $BACKUP/BACKUP_STATUS_$nal
        #sendEmail -f admin@almond.thinkwalnut.com -t tsg@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for aws-mysql-slave 130_101 - Backup SUCCESS" -o message-file=$BACKUP/BACKUP_STATUS_$NOW.txt
## Deleting two day old backup from source
        rm -rf $ARCHIVED
        rm -v /backup/mysql_backup/$OLD.tar.gz
else
        echo -en "BACKUP_FILE_SIZE is differtend from LOCAL_FILE_SIZE \n"
        echo "Check Backup Fail Size differ taken on $NOW \n BACKUP_FILE_SIZE is different from LOCAL_FILE_SIZE" > /backup/mysql_backup/BACKUP_STATUS_$nal
        sendEmail -f admin@almond.thinkwalnut.com -t tsg@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for asterisk-master mysql 120_141 - Backup FAIL" -o message-file=$BACKUP/BACKUP_STATUS_$NOW.txt
fi
#################

exit
