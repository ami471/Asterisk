#!/bin/sh
# Created by Raju 
# Dated 31May 2017
#
DATE=`date +%Y%m%d`
asterisk=`which asterisk`
#$asterisk -rx 'core show channels' | tail -n 3 > /tmp/asterisk_calls.txt
/sbin/asterisk -rx 'core show channels' | tail -n 3 > /tmp/asterisk_calls.txt
scp -P2345 /tmp/asterisk_calls.txt  root@172.20.120.205:/twd/www/html/asterisk_active_calls/  


echo -en "Channel              Location             State   Application(Data)\n" > /tmp/dashboard.txt
/sbin/asterisk -rx 'core show channels' | grep DAHDI >> /tmp/dashboard.txt
scp -P2345 /tmp/dashboard.txt  root@172.20.120.205:/twd/www/html/asterisk_active_calls/

#cd /var/www/html/
#tree -ifF | grep wav  > /tmp/audios.txt 
#scp -P2345 /tmp/audios.txt  root@172.20.120.205:/twd/www/html/asterisk_active_calls/

cd /var/lib/asterisk/recordings/
> /tmp/audios.txt
tree -ifF | grep wav > /tmp/audios.txt 
scp -P2345 /tmp/audios.txt  root@172.20.120.205:/twd/www/html/asterisk_active_calls/
exit
