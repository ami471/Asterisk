#!/bin/sh
# Created by Raju 
# Dated 15March 2017
#### Exporting variable for date format, backup file name ####
DATE_MONTH=`date +%d-%m-%Y-%a`
NOW=`date +%d-%b`
cur_file=`echo /TWD_ASTERISK_MASTER_logbackup/TWD_ASTERISK_MASTER-$DATE_MONTH.tar.gz`
DEST_FOLDER=`date +%d%m%Y`

mkdir /TWD_ASTERISK_MASTER_lifebouy_obd_logbackup
clear

#### Tar process ####**
#echo "Backup File name $cur_file. taking backup...."
#tar -zcf $cur_file /etc/rc.local /etc/exports  /etc/httpd /etc/passwd /etc/shadow /etc/group /etc/vsftpd* /etc/php.ini /var/spool/cron/*   /etc/asterisk/* > /dev/null 2>&1

#SIZE=`du -sk $cur_file | awk -F " " '{print $1}'`
#echo "File Size $SIZE KB"
### local backup done.

/usr/bin/find /var/log/asterisk -mtime -1 -type f \( -iname "*.gz" \) | grep lifebouy_obd  >> /tmp/lifebouy_obd_log.txt
# /scripts/asterisk-master_varlog_lifebouy_obd_backup_on_omv.sh

echo "Transferring file to 200.203 OMV using FTP..."

for log in `cat /tmp/lifebouy_obd_log.txt`
do

#### FTP on 172.20.200.203 OMV  Storage Server ####
#REMOTE_FILE=`echo /dcbackup/asterisk_master/varlogs/TWD_ASTERISK_MASTER_logbackup-$DATE_MONTH.tar.gz`
#REMOTE_FILE=`echo /dcbackup/asterisk_master/varlogs/lifebouy_obd_log_backup/TWD_ASTERISK_MASTER_lifebouy_obd_logbackup-$DATE_MONTH.tar.gz`
DEST_FOLDER=`date +%d%m%Y`
#REMOTE_DIR='TWD_ASTERISK_MASTER_lifebouy_obd_logbackup_`date +%d%m%Y -d "1 day ago"`'
HOST='172.20.200.203'
USER='dcbackup'
PASSWD='D(B@Ckup'
FILE=`echo $log`
ftp -n $HOST <<END_SCRIPT
quote USER $USER
quote PASS $PASSWD
bi
hash
cd /databackup/servers/DC/asterisk_master/varlogs/lifebouy_obd_log_backup
put $FILE 
quit
END_SCRIPT
###### 

echo "FTP Done"
done

echo "TWD ASTERISK MASTER Backup Successfully taken on $DATE_MONTH" > /TWD_ASTERISK_MASTER_lifebouy_obd_logbackup/BACKUP_STATUS_asterisk_lifebouy_obd_log_$DATE_MONTH.txt

### Garbage Control
> /tmp/logfile.txt
#rm -rf /TWD_ASTERISK_MASTER_logbackup/TWD_ASTERISK_MASTER_logbackup-`date +%d-%m-%Y-%a --date="3 days ago"`.txt
rm -r /TWD_ASTERISK_MASTER_lifebouy_obd_logbackup/BACKUP_STATUS_asterisk_lifebouy_obd_log_`date +%d-%m-%Y-%a --date="3 days ago"`.txt

#### Mail for backup done to tsg team ####
#mail -s "Backup Status for 252" tsg@thinkwalnut.com < /backup/BACKUP_STATUS_asterisk_log_$DATE_MONTH
#sendEmail -f admin@almond.thinkwalnut.com -t tsg@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for 252" -o message-file=/backup/BACKUP_STATUS_asterisk_log_$DATE_MONTH.txt
sendEmail -f admin@almond.thinkwalnut.com -t raju@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for ASTERISK MASTER Lifebouy Logs" -o message-file=/backup/BACKUP_STATUS_asterisk_lifebouy_obd_log_$DATE_MONTH.txt
