#! /bin/bash

clear
blank_line()    {
        echo  " "
                }

pause()         {
   read r
                }
#for i in $(seq 59)
for i in $(seq 60)
do
  echo  "`date` ==> Welcome $i times"
	sleep 1
done
