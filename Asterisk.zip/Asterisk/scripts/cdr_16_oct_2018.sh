#! /bin/bash

clear
blank_line()    {
        echo  " "
                }

pause()		{		
	echo "please press enter : "
   read r
		}

MYSQL=`which mysql`
CURL=`which curl`
DBUSER='root'
DBPASS='mys\@r0ja'


#select src from cdr
DB='asterisk'
TBL='lifebuoy_call'


# Below is working command
mysql -D asterisk -u root -pmys\@r0ja -e 'select callerid from lifebuoy_call where status = "NOANSWER" and attempt < 5 and ModifiedTime <= NOW()' > /tmp/cdrcall_1.txt
cat /tmp/cdrcall_1.txt | awk -F [^0-9] '{print $1}' | awk 'NF' > /tmp/cdrcall.txt

for call in `cat /tmp/cdrcall.txt`
do
echo call=$call
DATE=`date +%d%m%Y-%H%M`
FILENAME=cdrIncoming-"$call".call
echo FILENAME=$FILENAME

echo "Channel: SIP/tatasip/$call" >> /tmp/$FILENAME
echo "CallerID: 62323200" >> /tmp/$FILENAME
echo "MaxRetries: 0" >> /tmp/$FILENAME
echo "RetryTime: 60000" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo "Context: lifebuoy" >> /tmp/$FILENAME

echo "Extension: _x." >> /tmp/$FILENAME
echo "Priority: 1" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo debug_call =  $call
chmod 777 /tmp/$FILENAME
ls -l  /tmp/$FILENAME > /tmp/check_script_is_running.txt
#pause 

#cdrIncoming_COUNT=`ls /tmp/cdrIncoming-* | wc -l`
cdrIncoming_COUNT=`ls /var/spool/asterisk/outgoing/cdrIncoming-* | wc -l`
	if [[ $cdrIncoming_COUNT -le 125 ]] 
	then
		echo -en "`date`\n"  >  /tmp/cdr_outgoing.txt
		echo -en "cdrIncoming_COUNT=$cdrIncoming_COUNT\n"  >>  /tmp/cdr_outgoing.txt
		echo "Less_than_130"  >>  /tmp/cdr_outgoing.txt
		mv  -v /tmp/$FILENAME /var/spool/asterisk/outgoing/
	else
		echo -en "`date`\n"    >  /tmp/cdr_outgoing.txt
		echo -en "cdrIncoming_COUNT=$cdrIncoming_COUNT\n"  >>  /tmp/cdr_outgoing.txt
		echo "greater_than_130" >>  /tmp/cdr_outgoing.txt
	fi
sleep 0
mysql -D asterisk -u root -pmys\@r0ja -e "update lifebuoy_call set attempt = attempt +1 where callerid = '$call' and attempt < 5" 
mysql -D asterisk -u root -pmys\@r0ja -e "UPDATE lifebuoy_call SET ModifiedTime = DATE_ADD(ModifiedTime, INTERVAL 17 SECOND) WHERE callerid = '$call' and status = 'NOANSWER' and attempt < 5"
#
# UNIQUE_ID=attempt unique_id 2 1_1_1_3
ATTEMPT_UNIQUEID=`mysql -D asterisk -u root -pmys\@r0ja -e "select attempt,unique_id from lifebuoy_call where status = 'NOANSWER' and callerid = '$call' and attempt <= 5;"`
ATTEMPT_COUNT=`echo  $ATTEMPT_UNIQUEID | awk -F' '  '{print $3}'`
UNIQUE_ID=`echo  $ATTEMPT_UNIQUEID | awk -F' '  '{print $4}'`
 
echo -en "ATTEMPT_COUNT=$ATTEMPT_COUNT \n" >> /tmp/check_script_is_running.txt
echo -en "UNIQUE_ID=$UNIQUE_ID \n" >> /tmp/check_script_is_running.txt
#pause

if [[ $ATTEMPT_COUNT = 5 ]]
	then
echo -en "will run url now \n" >> /tmp/check_script_is_running.txt
#pause
		URL="http://172.20.120.105/13/lifebuoy/md/api/obd_response.php?callerid=$call&unique_id=$UNIQUE_ID&status='CONGESTION'"
		$CURL $URL
	else
echo -en "Not run url now \n" >> /tmp/check_script_is_running.txt
#pause
fi
done
rm -v /tmp/cdrcall_1.txt >> /tmp/check_script_is_running.txt
rm -v /tmp/cdrcall.txt >> /tmp/check_script_is_running.txt
exit
