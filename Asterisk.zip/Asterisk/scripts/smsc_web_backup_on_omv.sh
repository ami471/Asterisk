#!/bin/sh
#### Exporting variable for date format, backup file name ####
nal=`date +%d-%m-%Y-%a`
NOW=`date +%d-%b`
cur_file=`echo /backup/TWD_SMSC_252-$nal.tar.gz`

clear

#### Tar process ####**
echo "Backup File name $cur_file. taking backup...."
tar -zcf $cur_file /etc/rc.local /etc/exports /etc/httpd /etc/passwd /etc/shadow /etc/group /etc/vsftpd* /etc/php.ini /var/spool/cron/* /twd/www/html /usr/local/kannel_svn > /dev/null 2>&1
echo $NOW > /backup/last-full-backup-date.txt

#### Comparing the size of backup ####**
if [ $? -ne "0" ]
then
echo "Backup was not taken on $nal" > /backup/BACKUP_STATUS_$nal
exit 100
else
SIZE=`du -sk $cur_file | awk -F " " '{print $1}'`
echo "File Size $SIZE KB"
if [ $SIZE -lt "1000" ]
then
echo "Backup size doesn't qualify on $nal" > /backup/BACKUP_STATUS_$nal
exit 100
else
### local backup done.

echo "Transferring file to 200.203 OMV using FTP..."

#### FTP on 172.20.200.203 OMV  Storage Server ####
REMOTE_FILE_1=`echo /dcbackup/252/252_system/TWD_SMSC_252-$nal.tar.gz`
HOST='172.20.200.203'
USER='dcbackup'
PASSWD='D(B@Ckup'
FILE=`echo $cur_file`
ftp -n $HOST <<END_SCRIPT
quote USER $USER
quote PASS $PASSWD
bi
put $FILE $REMOTE_FILE_1
quit
END_SCRIPT
###### 

###### FTP on Seagate Local NAS BOX 200.90 ######
#back_file=`echo $cur_file`
#echo "Transferring file to 200.90 using FTP..."
#REMOTE_FILE=`echo /ftp_shares/sea_local_nas/252/TWD_SMSC_252-$nal.tar.gz`
#HOST='172.20.200.90'
#USER='dataadmin'
#PASSWD='@dminD@ta'
#ftp -n $HOST <<END_SCRIPT
#quote USER $USER
#quote PASS $PASSWD
#bi
#put $back_file $REMOTE_FILE
#quit
#END_SCRIPT
#
###### 



echo "FTP Done"
echo "Backup Successfully taken on $nal" > /backup/BACKUP_STATUS_$nal
fi
fi

### Garbage Control

rm -rf /backup/TWD_SMSC_252-`date +%d-%m-%Y-%a --date="3 days ago"`.tar.gz

#### Mail for backup done to tsg team ####
#mail -s "Backup Status for 252" tsg@thinkwalnut.com < /backup/BACKUP_STATUS_$nal
sendEmail -f admin@almond.thinkwalnut.com -t tsg@thinkwalnut.com -s 172.20.120.202:2625 -xu email -xp @lm0nD -u "Backup Status for 252" -o message-file=/backup/BACKUP_STATUS_$nal
