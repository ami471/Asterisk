#! /bin/bash

clear
blank_line()    {
        echo  " "
                }

pause()		{		
   read r
		}

MYSQL=`which mysql`
CURL=`which curl`
DBUSER='root'
DBPASS='amit1234'


#select src from cdr
DB='asterisk'
TBL='sunlight_call'


# Below is working command
mysql -D asterisk -u root -pamit1234 -e 'select callerid from sunlight_call where status = "NOANSWER" and attempt < 5 and ModifiedTime <= NOW()' > /tmp/call_1.txt
cat /tmp/call_1.txt | awk -F [^0-9] '{print $1}' | awk 'NF' > /tmp/call.txt

for call in `cat /tmp/call.txt`
do
echo call=$call
DATE=`date +%d%m%Y-%H%M`
FILENAME=Incoming-"$call".call
echo FILENAME=$FILENAME

echo "Channel: SIP/tatasip/$call" >> /tmp/$FILENAME
echo "CallerID: 62323200" >> /tmp/$FILENAME
echo "MaxRetries: 0" >> /tmp/$FILENAME
echo "RetryTime: 60000" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo "Context: valentine_obd" >> /tmp/$FILENAME

echo "Extension: _x." >> /tmp/$FILENAME
echo "Priority: 1" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo debug_call =  $call
chmod 777 /tmp/$FILENAME

mv /tmp/$FILENAME /var/spool/asterisk/outgoing
sleep 0
mysql -D asterisk -u root -pamit1234 -e "update sunlight_call set attempt = attempt +1 where callerid = '$call'" 
mysql -D asterisk -u root -pamit1234 -e "update sunlight_call SET ModifiedTime = DATE_ADD(ModifiedTime, INTERVAL 17 SECOND) WHERE callerid = '$call' and status = 'NOANSWER' "
#
# UNIQUE_ID=attempt unique_id 2 1_1_1_3
ATTEMPT_UNIQUEID=`mysql -D asterisk -u root -pamit1234 -e "select attempt,unique_id from sunlight_call where status = 'NOANSWER' and callerid = '$call' and attempt <= 5;"`
ATTEMPT_COUNT=`echo  $ATTEMPT_UNIQUEID | awk -F' '  '{print $3}'`
UNIQUE_ID=`echo  $ATTEMPT_UNIQUEID | awk -F' '  '{print $4}'`
 
echo -en "ATTEMPT_COUNT=$ATTEMPT_COUNT \n"
echo -en "UNIQUE_ID=$UNIQUE_ID \n"
#pause

if [[ $ATTEMPT_COUNT = 5 ]]
	then
echo -en "will run url now \n"
#pause
		URL="http://172.20.120.105/13/sunlight/api/vday_response.php?callerid=$call&unique_id=$UNIQUE_ID&status='CONGESTION'"
		$CURL $URL
	else
echo -en "Not run url now \n"
#pause
fi
done
rm /tmp/call_1.txt
rm /tmp/call.txt
exit
