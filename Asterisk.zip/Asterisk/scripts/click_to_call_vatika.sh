#! /bin/bash

clear
blank_line()    {
        echo  " "
                }

pause()		{		
   read r
		}
echo `date` > /tmp/click_to_call_script_time.txt
MYSQL=`which mysql`
CURL=`which curl`
DBUSER='root'
DBPASS='mys\@r0ja'

#select src from cdr
DB='asterisk'
TBL='click_to_call'


# Below is working command
mysql -D asterisk -u root -pmys\@r0ja -e 'delete from click_to_call where attempt > 4;'
mysql -D asterisk -u root -pmys\@r0ja -e 'select callerid from click_to_call where status = "NOANSWER" and attempt < 2 and ModifiedTime <= NOW()' > /tmp/click_to_call_1.txt
cat /tmp/click_to_call_1.txt | awk -F [^0-9] '{print $1}' | awk 'NF' > /tmp/click_to_call.txt

for call in `cat /tmp/click_to_call.txt`
do
echo call=$call
DATE=`date +%d%m%Y-%H%M`
FILENAME=Incoming-clicktocall-"$call".call
echo FILENAME=$FILENAME

echo "Channel: DAHDI/g0/$call" >> /tmp/$FILENAME
echo "MaxRetries: 0" >> /tmp/$FILENAME
echo "RetryTime: 60000" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo "Context: dialnow" >> /tmp/$FILENAME
echo "Extension: _x." >> /tmp/$FILENAME
echo "Priority: 1" >> /tmp/$FILENAME
echo "Set: PassedInfo=$call-moreinfo-evenmoreinfo" >> /tmp/$FILENAME
echo debug_call =  $call
chmod 777 /tmp/$FILENAME

ATTEMPT_CALL=`mysql -sND asterisk -u root -pmys\@r0ja -e "select attempt from click_to_call where callerid = '$call' and status = 'NOANSWER' and attempt < 2 order by callerid_count desc limit 1 ;"`
#echo "ATTEMPT_CALL=$ATTEMPT_CALL" > /tmp/attempt_call.txt
if [[ $ATTEMPT_CALL < 1 ]]
   then
#echo ATTEMPT_CALL=$ATTEMPT_CALL > /tmp/click_to_call_outgoing.txt
mv /tmp/$FILENAME /var/spool/asterisk/outgoing
#cp -v /tmp/$FILENAME /var/spool/asterisk/outgoing  >> /tmp/click_to_call_outgoing.txt
fi
sleep 0
mysql -D asterisk -u root -pmys\@r0ja -e "update click_to_call set attempt = attempt +1 where callerid = '$call' order by callerid_count desc limit 1"
mysql -D asterisk -u root -pmys\@r0ja -e "UPDATE click_to_call SET ModifiedTime = DATE_ADD(ModifiedTime, INTERVAL 15 SECOND) WHERE callerid = '$call' and status = 'NOANSWER' and attempt < 2 order by callerid_count desc limit 1"

SEND_SMS=`mysql -D asterisk -u root -pmys\@r0ja -e "select attempt from click_to_call where callerid = $call and status = 'NOANSWER' and attempt = 2 and sms_send = 0 order by callerid_count desc limit 1 ;"`
SEND_SMS_STATUS=`echo $SEND_SMS | awk -F' '  '{print $2}'`

urlencode() {
    # urlencode <string>

    local length="${#1}"
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf "$c" ;;
            *) printf '%s' "$c" | xxd -p -c1 |
                   while read c; do printf '%%%s' "$c"; done ;;
        esac
    done
}

STATUS=`mysql -sND asterisk -u root -pmys\@r0ja -e "select status from click_to_call where callerid = $call and attempt = 2 order by callerid_count desc limit 1;"`
if [ $SEND_SMS_STATUS -eq 2 ] && [ "$STATUS" = "NOANSWER" ];
   then
CALLER_DETAILS=`mysql -D asterisk -u root -pmys\@r0ja -e "select name,amount,meter_no from vatika_maintainance where mobile_no = '$call';"`
NAME_1=`echo $CALLER_DETAILS | awk -F' '  '{print $4" "$5}'`
NAME=`urlencode "$NAME_1"`
AMOUNT=`echo $CALLER_DETAILS | awk -F' '  '{print $6}'`
METER=`echo $CALLER_DETAILS | awk -F' '  '{print $7}'`
       SEND_SMS_URL="http://172.20.120.105/13/api/vatika_sms_push.php?mdn=$call&name="$NAME"&amount=$AMOUNT&meter=$METER&type=3"
       $CURL $SEND_SMS_URL
mysql -D asterisk -u root -pmys\@r0ja -e "update click_to_call set sms_send = 1 where callerid = $call order by callerid_count desc limit 1;"
	echo "Success" > /tmp/success_status.txt
else
	echo "Unsuccess" > /tmp/success_status.txt
fi

done
rm /tmp/click_to_call_1.txt
rm /tmp/click_to_call.txt
echo `date` >> /tmp/click_to_call_script_time.txt
echo "==================================" >> /tmp/click_to_call_script_time.txt
exit
