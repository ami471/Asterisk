#!/bin/bash
OLD_IFS=$IFS
IFS=$'\n'
#for a in $(cat /tmp/forr_loop_test_content.txt)    
for a in $(cat /tmp/asterisk_notice_id.txt)
do
    echo "$a"
done
IFS=$OLD_IFS
